import 'package:file_picker/file_picker.dart';

import '../../domain/import/supported_formats.dart';

/// 图片选择器抽象：封装平台差异（Android 相册 / Windows 文件与文件夹对话框）。
///
/// 独立接口便于在 Widget 测试中注入假实现。
abstract class ImportPicker {
  /// 选择一张或多张图片，返回文件路径列表；用户取消返回空列表。
  Future<List<String>> pickImages();

  /// 选择文件夹，返回目录路径；用户取消返回 null。
  Future<String?> pickFolder();
}

/// 基于 file_picker 的默认实现。
class FilePickerImportPicker implements ImportPicker {
  @override
  Future<List<String>> pickImages() async {
    final result = await FilePicker.platform.pickFiles(
      type: FileType.custom,
      allowedExtensions: kSupportedExtensions.toList(),
      allowMultiple: true,
      dialogTitle: '选择照片',
    );
    if (result == null) return const [];
    return result.files
        .map((f) => f.path)
        .whereType<String>()
        .toList();
  }

  @override
  Future<String?> pickFolder() async {
    final path = await FilePicker.platform.getDirectoryPath(dialogTitle: '选择照片文件夹');
    return path;
  }
}
