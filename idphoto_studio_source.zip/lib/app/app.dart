import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

import '../state/settings_state.dart';
import '../ui/home/home_page.dart';
import '../ui/onboarding/onboarding_page.dart';
import 'theme.dart';

/// 引导标记文件名（应用文档目录下）。
const kOnboardedFileName = '.onboarded';

/// 应用根组件：主题、路由、首页（首次启动先显示新手引导）。
class IDPhotoApp extends ConsumerStatefulWidget {
  const IDPhotoApp({super.key});

  /// 是否已完成新手引导（供测试直接调用）。
  static Future<bool> hasOnboarded() async {
    try {
      final docs = await getApplicationDocumentsDirectory();
      return await File(p.join(docs.path, kOnboardedFileName)).exists();
    } catch (_) {
      return true;
    }
  }

  /// 写入引导完成标记（供测试直接调用）。
  static Future<void> markOnboarded() async {
    try {
      final docs = await getApplicationDocumentsDirectory();
      await File(p.join(docs.path, kOnboardedFileName)).writeAsString('1');
    } catch (_) {
      // 无法写入标记时，下次启动重新引导（不影响使用）。
    }
  }

  @override
  ConsumerState<IDPhotoApp> createState() => _IDPhotoAppState();
}

class _IDPhotoAppState extends ConsumerState<IDPhotoApp> {
  /// 初始视为已引导（读取极快，老用户无感；新用户待读取完成后切到引导）。
  bool _onboarded = true;

  @override
  void initState() {
    super.initState();
    _checkOnboarded();
  }

  Future<void> _checkOnboarded() async {
    final ok = await IDPhotoApp.hasOnboarded();
    if (mounted && ok != _onboarded) setState(() => _onboarded = ok);
  }

  Future<void> _finishOnboarding() async {
    // 立即切换界面，标记文件在后台写入。
    if (mounted) setState(() => _onboarded = true);
    await IDPhotoApp.markOnboarded();
  }

  @override
  Widget build(BuildContext context) {
    final themeMode = ref.watch(settingsStateProvider).themeMode;
    return MaterialApp(
      title: '证件照工坊',
      debugShowCheckedModeBanner: false,
      theme: buildLightTheme(),
      darkTheme: buildDarkTheme(),
      themeMode: themeMode,
      home: _onboarded
          ? const HomePage()
          : OnboardingPage(onFinish: _finishOnboarding),
    );
  }
}
