import 'package:flutter_riverpod/flutter_riverpod.dart';

/// 当前选中的照片 ID（全局）。
final selectedItemIdProvider = StateProvider<String?>((ref) => null);
