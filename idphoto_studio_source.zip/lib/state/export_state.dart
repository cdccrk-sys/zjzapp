import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/export/export_service.dart';

/// ---- 依赖注入 ----

final exportServiceProvider = Provider<ExportService>((ref) {
  return ExportService();
});

/// ---- 导出状态 ----

class ExportState {
  const ExportState({
    this.isExporting = false,
    this.results = const [],
    this.failures = const [],
    this.exportedAt,
  });

  final bool isExporting;
  final List<ExportResultItem> results;
  final List<String> failures;
  final DateTime? exportedAt;

  ExportState copyWith({
    bool? isExporting,
    List<ExportResultItem>? results,
    List<String>? failures,
    DateTime? exportedAt,
  }) {
    return ExportState(
      isExporting: isExporting ?? this.isExporting,
      results: results ?? this.results,
      failures: failures ?? this.failures,
      exportedAt: exportedAt ?? this.exportedAt,
    );
  }
}

class ExportNotifier extends StateNotifier<ExportState> {
  ExportNotifier(this._service) : super(const ExportState());

  final ExportService _service;

  Future<void> reset() async {
    state = const ExportState();
  }

  /// 设置导出结果。
  void setResults(
    List<ExportResultItem> results,
    List<String> failures,
    DateTime? exportedAt,
  ) {
    state = ExportState(
      results: results,
      failures: failures,
      exportedAt: exportedAt,
    );
  }

  /// 分享已导出文件。
  Future<void> shareAll({String? text}) async {
    if (state.results.isEmpty) return;
    try {
      await _service.share(state.results, text: text);
    } catch (_) {
      // 分享面板取消/失败不视为导出失败。
    }
  }
}

final exportStateProvider =
    StateNotifierProvider<ExportNotifier, ExportState>((ref) {
  return ExportNotifier(ref.watch(exportServiceProvider));
});
