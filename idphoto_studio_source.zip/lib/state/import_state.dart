import 'dart:async';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/import/heic_decoder_platform.dart';
import '../domain/import/import_service.dart';
import '../domain/import/import_service_impl.dart';
import '../domain/import/image_item.dart';
import '../platform/picker/import_picker.dart';

/// ---- 依赖注入 ----

final importServiceProvider = Provider<ImportService>((ref) {
  return LocalImportService(heicDecoder: createDefaultHeicDecoder());
});

final importPickerProvider = Provider<ImportPicker>((ref) {
  return FilePickerImportPicker();
});

/// ---- 导入状态 ----

class ImportState {
  const ImportState({
    this.isLoading = false,
    this.items = const [],
    this.failures = const [],
    this.totalImported = 0,
  });

  final bool isLoading;
  final List<ImageItem> items;
  final List<ImportFailure> failures;
  final int totalImported;

  ImportState copyWith({
    bool? isLoading,
    List<ImageItem>? items,
    List<ImportFailure>? failures,
    int? totalImported,
  }) {
    return ImportState(
      isLoading: isLoading ?? this.isLoading,
      items: items ?? this.items,
      failures: failures ?? this.failures,
      totalImported: totalImported ?? this.totalImported,
    );
  }
}

class ImportStateNotifier extends StateNotifier<ImportState> {
  ImportStateNotifier(this._service, this._picker) : super(const ImportState());

  final ImportService _service;
  final ImportPicker _picker;

  /// 导入指定文件路径列表。
  Future<void> importFiles(List<String> paths) async {
    if (paths.isEmpty || state.isLoading) return;
    state = state.copyWith(isLoading: true, failures: const []);
    final result = await _service.importFiles(paths);
    state = state.copyWith(
      isLoading: false,
      items: [...state.items, ...result.items],
      failures: result.failures,
      totalImported: state.totalImported + result.items.length,
    );
  }

  /// 打开系统选择器导入图片。
  Future<void> pickAndImport() async {
    final paths = await _picker.pickImages();
    await importFiles(paths);
  }

  /// 选择文件夹批量导入。
  Future<void> pickFolderAndImport() async {
    final path = await _picker.pickFolder();
    if (path == null) return;
    if (state.isLoading) return;
    state = state.copyWith(isLoading: true, failures: const []);
    final result = await _service.importDirectory(path);
    state = state.copyWith(
      isLoading: false,
      items: [...state.items, ...result.items],
      failures: result.failures,
      totalImported: state.totalImported + result.items.length,
    );
  }

  /// 移除单个导入项。
  void removeItem(String id) {
    state = state.copyWith(
      items: state.items.where((e) => e.id != id).toList(),
    );
  }

  /// 清空全部导入项。
  void clear() {
    state = const ImportState();
  }
}

final importStateProvider =
    StateNotifierProvider<ImportStateNotifier, ImportState>((ref) {
  return ImportStateNotifier(
    ref.watch(importServiceProvider),
    ref.watch(importPickerProvider),
  );
});

/// ---- 向导步骤状态 ----

/// 8 步流程：导入 → 矫正 → 抠图 → 换背景 → 裁剪 → 优化 → 排版 → 导出。
const List<String> kWizardSteps = [
  '导入',
  '矫正',
  '抠图',
  '换背景',
  '裁剪',
  '优化',
  '排版',
  '导出',
];

final wizardStepProvider = StateProvider<int>((ref) => 0);
