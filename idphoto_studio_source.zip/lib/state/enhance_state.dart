import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/dress/dress_service.dart';
import '../domain/enhance/enhance_service.dart';

final enhanceServiceProvider = Provider<ColorEnhanceService>((ref) {
  return const ColorEnhanceService();
});

final dressServiceProvider = Provider<DressService>((ref) {
  return const DressService();
});

/// 优化（色彩 + 换装）状态。
class EnhanceState {
  EnhanceState({
    this.preset = EnhancementPreset.natural,
    EnhancementParams? params,
    this.dress = DressTemplate.none,
  }) : params = params ?? EnhancementParams.ofPreset(EnhancementPreset.natural);

  final EnhancementPreset preset;
  final EnhancementParams params;
  final DressTemplate dress;

  EnhanceState copyWith({
    EnhancementPreset? preset,
    EnhancementParams? params,
    DressTemplate? dress,
  }) {
    return EnhanceState(
      preset: preset ?? this.preset,
      params: params ?? this.params,
      dress: dress ?? this.dress,
    );
  }
}

class EnhanceNotifier extends StateNotifier<EnhanceState> {
  EnhanceNotifier() : super(EnhanceState());

  /// 选择预设：参数重置为预设值。
  void setPreset(EnhancementPreset preset) {
    state = state.copyWith(
      preset: preset,
      params: EnhancementParams.ofPreset(preset),
    );
  }

  /// 单参数微调（保持其他参数）。
  void updateParam(EnhancementParams Function(EnhancementParams) fn) {
    state = state.copyWith(params: fn(state.params));
  }

  void setWhiteBalance(bool v) =>
      updateParam((p) => p.copyWith(whiteBalance: v));

  void setBrightness(int v) => updateParam((p) => p.copyWith(brightness: v));

  void setContrast(double v) => updateParam((p) => p.copyWith(contrast: v));

  void setSaturation(double v) =>
      updateParam((p) => p.copyWith(saturation: v));

  void setWarmth(int v) => updateParam((p) => p.copyWith(warmth: v));

  void setSharpen(double v) => updateParam((p) => p.copyWith(sharpen: v));

  void setSmooth(double v) => updateParam((p) => p.copyWith(smooth: v));

  void setDenoise(double v) => updateParam((p) => p.copyWith(denoise: v));

  void setDress(DressTemplate t) => state = state.copyWith(dress: t);

  void reset() {
    state = EnhanceState(
      preset: EnhancementPreset.natural,
      params: EnhancementParams.ofPreset(EnhancementPreset.natural),
      dress: DressTemplate.none,
    );
  }
}

final enhanceStateProvider =
    StateNotifierProvider<EnhanceNotifier, EnhanceState>(
  (ref) => EnhanceNotifier(),
);
