import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image/image.dart' as img;

import '../domain/import/image_item.dart';
import 'correction_state.dart';

/// 统一工作图：item.id → 经矫正后的工作图字节。
///
/// 后续步骤（抠图/裁剪/优化/排版/导出）统一从这里取图，
/// 优先使用矫正结果，没有则回退到原图 workingBytes。
class WorkingImageNotifier extends StateNotifier<Map<String, Uint8List>> {
  WorkingImageNotifier() : super(const {});

  /// 记录某张图的矫正结果。
  void set(String itemId, Uint8List bytes) {
    state = {...state, itemId: bytes};
  }

  void clear(String itemId) {
    if (!state.containsKey(itemId)) return;
    final next = Map<String, Uint8List>.from(state);
    next.remove(itemId);
    state = next;
  }
}

final workingImageProvider =
    StateNotifierProvider<WorkingImageNotifier, Map<String, Uint8List>>(
  (ref) => WorkingImageNotifier(),
);

/// 取某张照片的当前工作图字节（矫正后优先，否则原图）。
Uint8List workingBytesFor(WidgetRef ref, ImageItem item) {
  final corrected = ref.read(correctionStateProvider).results[item.id];
  if (corrected != null) return corrected.correctedBytes;
  return item.workingBytes;
}

/// 解码某张照片的当前工作图。
img.Image? decodeWorkingImage(WidgetRef ref, ImageItem item) {
  return img.decodeImage(workingBytesFor(ref, item));
}
