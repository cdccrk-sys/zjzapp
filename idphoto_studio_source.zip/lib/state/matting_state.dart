import 'package:flutter/foundation.dart';
import 'package:flutter/painting.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image/image.dart' as img;

import '../domain/import/image_item.dart';
import '../domain/matting/background.dart';
import '../domain/matting/matting_service.dart';
import '../domain/matting/segmenter.dart';
import '../infra/logger/app_logger.dart';

/// ---- 依赖注入 ----

/// 平台分割器：Android 用 BiRefNet ONNX Runtime（BiRefNet-portrait）；
/// 其他平台用几何兜底。
final segmenterProvider = Provider<Segmenter>((ref) {
  if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
    return NativeTfliteSegmenter();
  }
  return const GeometricFallbackSegmenter();
});

final mattingServiceProvider = Provider<MattingService>((ref) {
  return const MattingService();
});

/// ---- 抠图状态 ----

class MattingState {
  const MattingState({
    this.masks = const {},
    this.isProcessing = false,
    this.processingItemId,
    this.selectedBackground = const PhotoBackground(
      type: PhotoBackgroundType.solid,
      color: 0xFFFFFFFF,
    ),
    this.sources = const {},
    this.batchTotal = 0,
    this.batchDone = 0,
    this.batchSuccess = 0,
    this.lastError,
  });

  /// item.id → 前景蒙版（原图尺寸）。
  final Map<String, Uint8List> masks;

  /// item.id → 分割来源（tflite/geometric）。
  final Map<String, String> sources;

  final bool isProcessing;
  final String? processingItemId;

  /// 批量处理进度：已处理 / 总数 / 成功数。
  final int batchTotal;
  final int batchDone;
  final int batchSuccess;

  /// 最近一次分割失败原因（用于界面诊断显示）。
  final String? lastError;
  final PhotoBackground selectedBackground;

  MattingState copyWith({
    Map<String, Uint8List>? masks,
    Map<String, String>? sources,
    bool? isProcessing,
    String? processingItemId,
    PhotoBackground? selectedBackground,
    int? batchTotal,
    int? batchDone,
    int? batchSuccess,
    String? lastError,
  }) {
    return MattingState(
      masks: masks ?? this.masks,
      sources: sources ?? this.sources,
      isProcessing: isProcessing ?? this.isProcessing,
      processingItemId: processingItemId ?? this.processingItemId,
      selectedBackground: selectedBackground ?? this.selectedBackground,
      batchTotal: batchTotal ?? this.batchTotal,
      batchDone: batchDone ?? this.batchDone,
      batchSuccess: batchSuccess ?? this.batchSuccess,
      lastError: lastError ?? this.lastError,
    );
  }
}

class MattingNotifier extends StateNotifier<MattingState> {
  MattingNotifier(this._segmenter, this._service)
      : super(const MattingState());

  final Segmenter _segmenter;
  final MattingService _service;

  /// 对照片执行 AI 抠图。
  ///
  /// [sourceBytes] 可选：矫正后的工作图字节；不传则用 item.workingBytes。
  Future<bool> segment(ImageItem item, {Uint8List? sourceBytes}) async {
    if (state.isProcessing) return false;
    state = state.copyWith(isProcessing: true, processingItemId: item.id);
    try {
      final bytes = sourceBytes ?? item.workingBytes;
      // 释放预览图缓存，给 ONNX 推理腾出内存（3GB 手机上关键）。
      PaintingBinding.instance.imageCache
        ..clear()
        ..clearLiveImages();
      final decoded = img.decodeImage(bytes);
      if (decoded == null) {
        state = state.copyWith(isProcessing: false, processingItemId: null);
        return false;
      }
      return await _segmentDecoded(item, decoded);
    } catch (e) {
      AppLogger.instance.error('AI 抠图失败', e);
      state = state.copyWith(
        isProcessing: false,
        processingItemId: null,
        lastError: e.toString(),
      );
      return false;
    }
  }

  Future<bool> _segmentDecoded(ImageItem item, img.Image decoded) async {
    try {
      var result = await _segmenter.segment(decoded);
      final errors = <String>[];
      if (!result.succeeded && result.errorHint != null) {
        errors.add('AI:${result.errorHint}');
      }
      if (!result.succeeded) {
        AppLogger.instance.info('AI 分割失败，回退几何兜底');
        final g = await const GeometricFallbackSegmenter().segment(decoded);
        if (!g.succeeded) {
          errors.add('几何:${g.errorHint ?? '未知'}');
        }
        result = g;
      }
      if (errors.isNotEmpty) {
        state = state.copyWith(
          lastError: errors.join(' | '),
        );
      }
      if (result.succeeded) {
        // 蒙版边缘净化：1px 羽化让边界过渡自然，减少背景残留的突兀感。
        final refined = _featherMask(
          result.mask,
          result.width,
          result.height,
        );
        state = state.copyWith(
          masks: {...state.masks, item.id: refined},
          sources: {...state.sources, item.id: result.source},
          isProcessing: false,
          processingItemId: null,
        );
      } else {
        state = state.copyWith(isProcessing: false, processingItemId: null);
      }
      return result.succeeded;
    } catch (e) {
      AppLogger.instance.error('AI 抠图失败', e);
      state = state.copyWith(
        isProcessing: false,
        processingItemId: null,
        lastError: e.toString(),
      );
      return false;
    }
  }

  /// 蒙版后处理（目标：人物主体完整、背景干净、头发丝边缘自然）。
  ///
  /// 处理链：
  /// 1. 1/2 降采样，Otsu 找前景/背景分界；
  /// 2. 用"低阈值"（Otsu 的 0.7 倍）二值化，最大化人物区域，避免主体被误删；
  /// 3. 形态学闭运算（3×3 膨胀+腐蚀）填补人物内部空洞、连接断裂部分；
  /// 4. 连通域清理：保留最大主体与面积较大的块，删除孤立背景残留；
  /// 5. 放大回原尺寸，合成混合 alpha——主体实心、边缘保留软过渡（头发丝）；
  /// 6. 边缘 1px 羽化，避免换底锯齿。
  static Uint8List _featherMask(Uint8List mask, int w, int h) {
    if (w <= 0 || h <= 0) return mask;

    // 1/2 降采样（2×2 平均池化，保留软值）。
    final sw = (w / 2).ceil();
    final sh = (h / 2).ceil();
    final small = Uint8List(sw * sh);
    for (var y = 0; y < sh; y++) {
      final sy0 = (y * 2).clamp(0, h - 1);
      final sy1 = (y * 2 + 1).clamp(0, h - 1);
      for (var x = 0; x < sw; x++) {
        final sx0 = (x * 2).clamp(0, w - 1);
        final sx1 = (x * 2 + 1).clamp(0, w - 1);
        small[y * sw + x] = ((mask[sy0 * w + sx0] +
                mask[sy0 * w + sx1] +
                mask[sy1 * w + sx0] +
                mask[sy1 * w + sx1]) >>
            2);
      }
    }

    // Otsu + 低阈值二值化（最大化人物区域）。
    final otsu = _otsuThreshold(small);
    final lowT = (otsu * 0.7).round().clamp(40, 120);
    var bin = Uint8List(small.length);
    for (var i = 0; i < small.length; i++) {
      bin[i] = small[i] > lowT ? 255 : 0;
    }

    // 空洞填充：从图像四周边界的背景像素做 flood fill，
    // 所有与边界连通的像素是真背景；人物内部的洞（不与边界连通）
    // 自动填为前景——能填任意大小的内部空洞（下巴/脖子/衣服斑驳）。
    bin = _fillHoles(bin, sw, sh);

    // 连通域清理（在降采样图上）。
    var cleaned = _keepLargestSmall(bin, sw, sh);

    // 主体腐蚀 2 像素：削掉紧贴人物边缘的背景色残留（草地/光晕/蓝天），
    // 头发丝细节由后续混合 alpha 在主体内部保留。
    cleaned = _erode(cleaned, sw, sh);
    cleaned = _erode(cleaned, sw, sh);

    // 放大主体区域回原尺寸（双线性插值，消除最近邻导致的边缘偏移）。
    final body = Uint8List(mask.length);
    for (var y = 0; y < h; y++) {
      final fy = y / 2.0;
      final y0 = fy.floor().clamp(0, sh - 1);
      final y1 = (y0 + 1).clamp(0, sh - 1);
      final wy = fy - y0;
      for (var x = 0; x < w; x++) {
        final fx = x / 2.0;
        final x0 = fx.floor().clamp(0, sw - 1);
        final x1 = (x0 + 1).clamp(0, sw - 1);
        final wx = fx - x0;
        final v00 = cleaned[y0 * sw + x0].toDouble();
        final v01 = cleaned[y0 * sw + x1].toDouble();
        final v10 = cleaned[y1 * sw + x0].toDouble();
        final v11 = cleaned[y1 * sw + x1].toDouble();
        final v = v00 * (1 - wx) * (1 - wy) +
            v01 * wx * (1 - wy) +
            v10 * (1 - wx) * wy +
            v11 * wx * wy;
        body[y * w + x] = v > 127 ? 255 : 0;
      }
    }

    // 混合 alpha：
    // 主体外 → 0（背景全透明）；
    // 主体内 → 255（全部实心，不保留软值，避免半透明像素透出原背景色）；
    // 边缘自然过渡由后续 _featherEdges 羽化完成。
    final out = Uint8List(mask.length);
    for (var i = 0; i < mask.length; i++) {
      out[i] = body[i] == 0 ? 0 : 255;
    }
    return _featherEdges(out, w, h);
  }

  /// 空洞填充：从四周边界的背景像素 flood fill，标记所有与边界连通的
  /// 背景；未被标记的背景像素（人物内部的洞）填为前景。
  static Uint8List _fillHoles(Uint8List bin, int w, int h) {
    final visited = Uint8List(bin.length);
    final queue = <int>[];
    // 收集边界上的背景像素作为种子。
    for (var x = 0; x < w; x++) {
      if (bin[x] == 0 && visited[x] == 0) {
        visited[x] = 1;
        queue.add(x);
      }
      final bottom = (h - 1) * w + x;
      if (bin[bottom] == 0 && visited[bottom] == 0) {
        visited[bottom] = 1;
        queue.add(bottom);
      }
    }
    for (var y = 0; y < h; y++) {
      final left = y * w;
      if (bin[left] == 0 && visited[left] == 0) {
        visited[left] = 1;
        queue.add(left);
      }
      final right = y * w + w - 1;
      if (bin[right] == 0 && visited[right] == 0) {
        visited[right] = 1;
        queue.add(right);
      }
    }
    // BFS 标记所有与边界连通的背景。
    while (queue.isNotEmpty) {
      final p = queue.removeLast();
      final px = p % w;
      final py = p ~/ w;
      if (px > 0) {
        final q = p - 1;
        if (bin[q] == 0 && visited[q] == 0) {
          visited[q] = 1;
          queue.add(q);
        }
      }
      if (px < w - 1) {
        final q = p + 1;
        if (bin[q] == 0 && visited[q] == 0) {
          visited[q] = 1;
          queue.add(q);
        }
      }
      if (py > 0) {
        final q = p - w;
        if (bin[q] == 0 && visited[q] == 0) {
          visited[q] = 1;
          queue.add(q);
        }
      }
      if (py < h - 1) {
        final q = p + w;
        if (bin[q] == 0 && visited[q] == 0) {
          visited[q] = 1;
          queue.add(q);
        }
      }
    }
    // 原前景 + 内部洞（未被访问的背景）→ 前景；与边界连通的背景 → 0。
    final out = Uint8List(bin.length);
    for (var i = 0; i < bin.length; i++) {
      if (bin[i] > 0 || visited[i] == 0) {
        out[i] = 255;
      }
    }
    return out;
  }

  /// 3×3 八邻域腐蚀（图内邻域全部为前景才保留；图外邻域跳过，
  /// 避免贴着画面边缘的人物——头顶、肩膀——被误削）。
  static Uint8List _erode(Uint8List a, int w, int h) {
    final out = Uint8List(a.length);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        var v = 255;
        outer:
        for (var dy = -1; dy <= 1; dy++) {
          final ny = y + dy;
          if (ny < 0 || ny >= h) continue;
          for (var dx = -1; dx <= 1; dx++) {
            final nx = x + dx;
            if (nx < 0 || nx >= w) continue;
            if (a[ny * w + nx] == 0) {
              v = 0;
              break outer;
            }
          }
        }
        out[y * w + x] = v;
      }
    }
    return out;
  }

  /// 连通域清理（输入已是降采样二值图）：保留最大连通域，以及面积
  /// ≥总前景 1% 的块（避免误删与主体断开的手臂等），其余清 0。
  static Uint8List _keepLargestSmall(Uint8List bin, int w, int h) {
    final label = Int32List(bin.length);
    final areas = <int>[];
    var cur = 0;
    for (var start = 0; start < bin.length; start++) {
      if (bin[start] == 0 || label[start] != 0) continue;
      cur++;
      var area = 0;
      final queue = <int>[start];
      label[start] = cur;
      while (queue.isNotEmpty) {
        final p = queue.removeLast();
        area++;
        final px = p % w;
        final py = p ~/ w;
        if (px > 0) {
          final q = p - 1;
          if (bin[q] > 0 && label[q] == 0) {
            label[q] = cur;
            queue.add(q);
          }
        }
        if (px < w - 1) {
          final q = p + 1;
          if (bin[q] > 0 && label[q] == 0) {
            label[q] = cur;
            queue.add(q);
          }
        }
        if (py > 0) {
          final q = p - w;
          if (bin[q] > 0 && label[q] == 0) {
            label[q] = cur;
            queue.add(q);
          }
        }
        if (py < h - 1) {
          final q = p + w;
          if (bin[q] > 0 && label[q] == 0) {
            label[q] = cur;
            queue.add(q);
          }
        }
      }
      areas.add(area);
    }
    if (cur == 0) return bin;

    var maxArea = 0;
    var maxLabel = 0;
    var totalFg = 0;
    for (var i = 0; i < areas.length; i++) {
      totalFg += areas[i];
      if (areas[i] > maxArea) {
        maxArea = areas[i];
        maxLabel = i + 1;
      }
    }
    final keep = <int>{maxLabel};
    for (var i = 0; i < areas.length; i++) {
      if (areas[i] >= totalFg * 0.01) keep.add(i + 1);
    }
    final out = Uint8List(bin.length);
    for (var i = 0; i < bin.length; i++) {
      final l = label[i];
      if (l != 0 && keep.contains(l)) out[i] = 255;
    }
    return out;
  }

  /// 边缘羽化：分离式 3×3 高斯 [1,2,1]（水平 + 垂直两遍）。
  static Uint8List _featherEdges(Uint8List a, int w, int h) {
    final tmp = Uint8List(a.length);
    for (var y = 0; y < h; y++) {
      final row = y * w;
      for (var x = 0; x < w; x++) {
        final l = x > 0 ? a[row + x - 1] : a[row + x];
        final r = x < w - 1 ? a[row + x + 1] : a[row + x];
        tmp[row + x] = ((l + 2 * a[row + x] + r + 2) >> 2).clamp(0, 255);
      }
    }
    final out = Uint8List(a.length);
    for (var y = 0; y < h; y++) {
      final row = y * w;
      for (var x = 0; x < w; x++) {
        final u = y > 0 ? tmp[row - w + x] : tmp[row + x];
        final d = y < h - 1 ? tmp[row + w + x] : tmp[row + x];
        out[row + x] = ((u + 2 * tmp[row + x] + d + 2) >> 2).clamp(0, 255);
      }
    }
    return out;
  }

  /// Otsu 自适应阈值：按蒙版灰度直方图最大化类间方差。
  /// 常规照片人物蒙版 >0.5、背景 <0.2，Otsu 通常落在 0.3~0.5；
  /// 弱蒙版照片也能正确分离前景/背景。
  static int _otsuThreshold(Uint8List mask) {
    final hist = List<int>.filled(256, 0);
    for (var i = 0; i < mask.length; i++) {
      hist[mask[i]]++;
    }
    final total = mask.length;
    var sum = 0;
    for (var i = 0; i < 256; i++) {
      sum += i * hist[i];
    }
    var sumB = 0;
    var wB = 0;
    var maxVar = -1.0;
    var threshold = 127;
    for (var t = 0; t < 256; t++) {
      wB += hist[t];
      if (wB == 0) continue;
      final wF = total - wB;
      if (wF == 0) break;
      sumB += t * hist[t];
      final mB = sumB / wB;
      final mF = (sum - sumB) / wF;
      final v = wB * wF * (mB - mF) * (mB - mF);
      if (v > maxVar) {
        maxVar = v;
        threshold = t;
      }
    }
    if (threshold < 60) threshold = 60;
    return threshold;
  }
  /// 批量抠图：对全部照片依次执行分割。
  ///
  /// 返回成功数；跳过已有蒙版的可选参数 [skipDone]。
  Future<int> segmentAll(List<ImageItem> items, {bool skipDone = false}) async {
    if (state.isProcessing) return 0;
    var success = 0;
    var done = 0;
    for (final item in items) {
      if (skipDone && state.masks.containsKey(item.id)) {
        done++;
        state = state.copyWith(batchDone: done);
        continue;
      }
      final ok = await segment(item);
      done++;
      if (ok) success++;
      state = state.copyWith(
        batchTotal: items.length,
        batchDone: done,
        batchSuccess: success,
      );
    }
    state = state.copyWith(
      isProcessing: false,
      processingItemId: null,
      batchDone: 0,
      batchTotal: 0,
      batchSuccess: 0,
    );
    return success;
  }

  /// 手动画笔修补蒙版（坐标已在原图坐标系）。
  void repair(ImageItem item, int cx, int cy, int radius,
      {required bool add}) {
    final mask = state.masks[item.id];
    if (mask == null) return;
    final width = _imageWidthOf(item);
    final height = mask.length ~/ width;
    final updated = _service.repair(mask, width, height, cx, cy, radius,
        add: add);
    state = state.copyWith(
      masks: {...state.masks, item.id: updated},
    );
  }

  /// 重置蒙版。
  void reset(ImageItem item) {
    final masks = Map<String, Uint8List>.from(state.masks);
    final sources = Map<String, String>.from(state.sources);
    masks.remove(item.id);
    sources.remove(item.id);
    state = state.copyWith(masks: masks, sources: sources);
  }

  /// 选择背景。
  void setBackground(PhotoBackground background) {
    state = state.copyWith(selectedBackground: background);
  }

  /// 蒙版对应的原图宽（从导入项读取）。
  int _imageWidthOf(ImageItem item) {
    final decoded = img.decodeImage(item.workingBytes);
    return decoded?.width ?? 0;
  }
}

final mattingStateProvider =
    StateNotifierProvider<MattingNotifier, MattingState>((ref) {
  return MattingNotifier(
    ref.watch(segmenterProvider),
    ref.watch(mattingServiceProvider),
  );
});

/// 当前用于抠图步骤的照片。
final mattingSelectedItemProvider = StateProvider<ImageItem?>((ref) => null);

/// 当前画笔模式：true=前景笔（恢复），false=背景笔（擦除）。
final mattingBrushAddProvider = StateProvider<bool>((ref) => true);
