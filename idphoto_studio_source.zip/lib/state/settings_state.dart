import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

/// 应用设置状态。
class SettingsState {
  const SettingsState({
    this.themeMode = ThemeMode.system,
    this.checkUpdate = false,
  });

  final ThemeMode themeMode;

  /// 自动检查更新开关（默认关闭：离线版无更新通道）。
  final bool checkUpdate;

  SettingsState copyWith({ThemeMode? themeMode, bool? checkUpdate}) {
    return SettingsState(
      themeMode: themeMode ?? this.themeMode,
      checkUpdate: checkUpdate ?? this.checkUpdate,
    );
  }
}

class SettingsNotifier extends StateNotifier<SettingsState> {
  SettingsNotifier() : super(const SettingsState());

  void setThemeMode(ThemeMode mode) => state = state.copyWith(themeMode: mode);

  void setCheckUpdate(bool v) => state = state.copyWith(checkUpdate: v);
}

final settingsStateProvider =
    StateNotifierProvider<SettingsNotifier, SettingsState>(
  (ref) => SettingsNotifier(),
);
