import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image/image.dart' as img;

import '../domain/export/export_service.dart';
import '../domain/export/print_export_service.dart';
import '../domain/layout/print_layout.dart';
import '../domain/specs/idphoto_specs.dart';

final printExportServiceProvider = Provider<PrintExportService>((ref) {
  return PrintExportService();
});

/// 排版状态。
class PrintState {
  const PrintState({
    this.paperId = 'photo6',
    this.gapMm = 2,
    this.marginMm = 8,
    this.options = const PrintExportOptions(),
    this.layout,
    this.isExporting = false,
    this.results = const [],
    this.failures = const [],
  });

  final String paperId;
  final double gapMm;
  final double marginMm;
  final PrintExportOptions options;

  /// 排版结果（由 computeLayout 生成）。
  final PrintLayout? layout;

  final bool isExporting;
  final List<ExportResultItem> results;
  final List<String> failures;

  PaperSpec get paper => PaperSpec.byId(paperId) ?? PaperSpec.builtin.first;

  PrintState copyWith({
    String? paperId,
    double? gapMm,
    double? marginMm,
    PrintExportOptions? options,
    PrintLayout? layout,
    bool clearLayout = false,
    bool? isExporting,
    List<ExportResultItem>? results,
    List<String>? failures,
  }) {
    return PrintState(
      paperId: paperId ?? this.paperId,
      gapMm: gapMm ?? this.gapMm,
      marginMm: marginMm ?? this.marginMm,
      options: options ?? this.options,
      layout: clearLayout ? null : (layout ?? this.layout),
      isExporting: isExporting ?? this.isExporting,
      results: results ?? this.results,
      failures: failures ?? this.failures,
    );
  }
}

class PrintNotifier extends StateNotifier<PrintState> {
  PrintNotifier(this._service) : super(const PrintState());

  final PrintExportService _service;

  /// 根据规格重算排版（切换相纸/间距/边距后调用）。
  ///
  /// 默认只排满一页（每页可放张数），超出按张数自动分页。
  /// 单张照片场景下排版结果即为 1 页相纸，可直接打印。
  void computeLayout(IdPhotoSpec spec, {int? count}) {
    final probe = const LayoutService().layout(
      state.paper,
      spec.widthMm,
      spec.heightMm,
      count: 1,
      gapMm: state.gapMm,
      marginMm: state.marginMm,
    );
    final layout = const LayoutService().layout(
      state.paper,
      spec.widthMm,
      spec.heightMm,
      count: count ?? probe.perPage,
      gapMm: state.gapMm,
      marginMm: state.marginMm,
    );
    state = state.copyWith(layout: layout);
  }

  void setPaper(String paperId) {
    state = state.copyWith(paperId: paperId, clearLayout: true);
  }

  void setGap(double v) {
    state = state.copyWith(gapMm: v, clearLayout: true);
  }

  void setMargin(double v) {
    state = state.copyWith(marginMm: v, clearLayout: true);
  }

  void setOptions(PrintExportOptions options) {
    state = state.copyWith(options: options);
  }

  /// 导出排版图（JPG/PNG）。
  ///
  /// [photos] 非空时按格循环铺排（批量排版）。
  Future<void> exportSheet(
    img.Image photo,
    IdPhotoSpec spec, {
    List<img.Image> photos = const [],
    ExportFormat format = ExportFormat.jpg,
    int jpgQuality = 92,
  }) async {
    if (state.isExporting || state.layout == null) return;
    state = state.copyWith(isExporting: true, results: const [], failures: const []);
    try {
      final item = await _service.exportPrintSheet(
        photo,
        state.layout!,
        photos: photos,
        format: format,
        jpgQuality: jpgQuality,
        options: state.options,
      );
      state = state.copyWith(isExporting: false, results: [item]);
    } catch (e) {
      state = state.copyWith(
        isExporting: false,
        failures: ['导出失败: $e'],
      );
    }
  }

  /// 导出排版 PDF。
  Future<void> exportPdf(
    img.Image photo,
    IdPhotoSpec spec, {
    List<img.Image> photos = const [],
  }) async {
    if (state.isExporting || state.layout == null) return;
    state = state.copyWith(isExporting: true, results: const [], failures: const []);
    try {
      final item = await _service.exportPrintPdf(
        photo,
        state.layout!,
        photos: photos,
        options: state.options,
      );
      state = state.copyWith(isExporting: false, results: [item]);
    } catch (e) {
      state = state.copyWith(
        isExporting: false,
        failures: ['导出失败: $e'],
      );
    }
  }

  Future<void> reset() async {
    state = const PrintState();
  }
}

final printStateProvider = StateNotifierProvider<PrintNotifier, PrintState>(
  (ref) => PrintNotifier(ref.watch(printExportServiceProvider)),
);
