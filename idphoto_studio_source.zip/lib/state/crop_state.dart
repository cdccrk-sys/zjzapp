import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image/image.dart' as img;

import '../domain/crop/crop_service.dart';
import '../domain/face/face_models.dart';
import '../domain/import/image_item.dart';
import '../domain/specs/idphoto_specs.dart';

/// ---- 依赖注入 ----

final cropServiceProvider = Provider<CropService>((ref) {
  return const CropService();
});

/// ---- 裁剪状态 ----

class CropState {
  const CropState({
    this.rects = const {},
    this.selectedSpecId = 'inch1',
    this.rules = const {},
    this.isApplying = false,
  });

  /// item.id → 裁剪框（源图像素坐标）。
  final Map<String, CropRect> rects;

  /// 当前选中的规格 id。
  final String selectedSpecId;

  /// item.id → 使用的裁剪规则（记录来源）。
  final Map<String, CropRule> rules;

  final bool isApplying;

  CropState copyWith({
    Map<String, CropRect>? rects,
    String? selectedSpecId,
    Map<String, CropRule>? rules,
    bool? isApplying,
  }) {
    return CropState(
      rects: rects ?? this.rects,
      selectedSpecId: selectedSpecId ?? this.selectedSpecId,
      rules: rules ?? this.rules,
      isApplying: isApplying ?? this.isApplying,
    );
  }

  IdPhotoSpec get selectedSpec =>
      IdPhotoSpec.byId(selectedSpecId) ?? IdPhotoSpec.builtin.first;
}

class CropNotifier extends StateNotifier<CropState> {
  CropNotifier(this._service) : super(const CropState());

  final CropService _service;

  /// 选择规格：清空既有裁剪框（需重新自动裁剪）。
  void selectSpec(IdPhotoSpec spec) {
    state = state.copyWith(
      selectedSpecId: spec.id,
      rects: const {},
      rules: const {},
    );
  }

  /// 自动裁剪：基于人脸分析结果。
  Future<void> autoCrop(ImageItem item, FaceAnalysisResult? analysis,
      {Uint8List? sourceBytes}) async {
    if (state.isApplying) return;
    final decoded = img.decodeImage(sourceBytes ?? item.workingBytes);
    if (decoded == null) return;
    final spec = state.selectedSpec;
    state = state.copyWith(isApplying: true);

    CropRect rect;
    if (analysis != null &&
        analysis.hasFace &&
        analysis.primaryFace != null) {
      final r = _service.autoCrop(
        analysis.primaryFace!,
        spec,
        decoded.width,
        decoded.height,
      );
      rect = r.rect;
    } else {
      // 无分析结果：默认居中取最大满足比例的框。
      final H = decoded.height.toDouble();
      final W = H * spec.aspectRatio;
      final x = ((decoded.width - W) / 2).round().clamp(0, decoded.width);
      rect = CropRect(
        x: x,
        y: 0,
        width: W.round().clamp(1, decoded.width),
        height: decoded.height,
      );
    }
    state = state.copyWith(
      rects: {...state.rects, item.id: rect},
      isApplying: false,
    );
  }

  /// 手动平移。
  void shift(ImageItem item, int dx, int dy, {Uint8List? sourceBytes}) {
    final rect = state.rects[item.id];
    if (rect == null) return;
    final decoded = img.decodeImage(sourceBytes ?? item.workingBytes);
    if (decoded == null) return;
    final updated = _service.shift(rect, dx, dy, decoded.width, decoded.height);
    state = state.copyWith(rects: {...state.rects, item.id: updated});
  }

  /// 手动缩放（按规格比例锁定）。
  void zoom(ImageItem item, double factor, {Uint8List? sourceBytes}) {
    final rect = state.rects[item.id];
    if (rect == null) return;
    final decoded = img.decodeImage(sourceBytes ?? item.workingBytes);
    if (decoded == null) return;
    final updated =
        _service.zoom(rect, factor, decoded.width, decoded.height, state.selectedSpec);
    state = state.copyWith(rects: {...state.rects, item.id: updated});
  }
}

final cropStateProvider = StateNotifierProvider<CropNotifier, CropState>((ref) {
  return CropNotifier(ref.watch(cropServiceProvider));
});

/// 当前用于裁剪步骤的照片。
final cropSelectedItemProvider = StateProvider<ImageItem?>((ref) => null);
