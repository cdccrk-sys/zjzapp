import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../domain/artifacts/artifact_store.dart';
import '../domain/import/image_item.dart';

/// 产物状态：itemId → 已保存的产物种类集合 + 内存字节缓存 + 最近保存记录。
class ArtifactState {
  const ArtifactState({
    this.saved = const {},
    this.cache = const {},
    this.lastSaved = const {},
  });

  final Map<String, Set<ArtifactKind>> saved;
  final Map<String, Map<ArtifactKind, Uint8List>> cache;

  /// itemId → 最近一次保存的产物种类（用于「任意功能读最新产物」）。
  final Map<String, ArtifactKind> lastSaved;

  bool has(String itemId, ArtifactKind kind) =>
      saved[itemId]?.contains(kind) ?? false;

  Uint8List? bytesOf(String itemId, ArtifactKind kind) =>
      cache[itemId]?[kind];

  ArtifactState copyWith({
    Map<String, Set<ArtifactKind>>? saved,
    Map<String, Map<ArtifactKind, Uint8List>>? cache,
    Map<String, ArtifactKind>? lastSaved,
  }) {
    return ArtifactState(
      saved: saved ?? this.saved,
      cache: cache ?? this.cache,
      lastSaved: lastSaved ?? this.lastSaved,
    );
  }
}

/// 产物状态管理：保存时写文件 + 内存缓存 + 更新状态。
class ArtifactNotifier extends StateNotifier<ArtifactState> {
  ArtifactNotifier(this._store) : super(const ArtifactState()) {
    _refresh();
  }

  final ArtifactStore _store;

  /// 启动时扫描已保存的产物（跨会话保留）。
  Future<void> _refresh() async {
    try {
      final root = await _store.savedKindsAll();
      if (root.isEmpty) return;
      state = ArtifactState(saved: root);
    } catch (_) {}
  }

  /// 保存某功能产物（写文件 + 内存缓存 + 更新状态）。
  Future<void> save(
    String itemId,
    ArtifactKind kind,
    Uint8List bytes,
  ) async {
    await _store.save(itemId, kind, bytes);
    final saved = Map<String, Set<ArtifactKind>>.from(state.saved);
    final set = Set<ArtifactKind>.from(saved[itemId] ?? const {});
    set.add(kind);
    saved[itemId] = set;
    final cache = Map<String, Map<ArtifactKind, Uint8List>>.from(state.cache);
    final itemCache = Map<ArtifactKind, Uint8List>.from(cache[itemId] ?? {});
    itemCache[kind] = bytes;
    cache[itemId] = itemCache;
    final lastSaved = Map<String, ArtifactKind>.from(state.lastSaved);
    lastSaved[itemId] = kind;
    state = ArtifactState(saved: saved, cache: cache, lastSaved: lastSaved);
  }

  /// 删除某照片的全部产物。
  Future<void> clear(String itemId) async {
    await _store.deleteAll(itemId);
    final saved = Map<String, Set<ArtifactKind>>.from(state.saved);
    saved.remove(itemId);
    final cache = Map<String, Map<ArtifactKind, Uint8List>>.from(state.cache);
    cache.remove(itemId);
    final lastSaved = Map<String, ArtifactKind>.from(state.lastSaved);
    lastSaved.remove(itemId);
    state = ArtifactState(saved: saved, cache: cache, lastSaved: lastSaved);
  }

  bool has(String itemId, ArtifactKind kind) => state.has(itemId, kind);
}

final artifactStoreProvider = Provider<ArtifactStore>((ref) {
  return const ArtifactStore();
});

final artifactStateProvider =
    StateNotifierProvider<ArtifactNotifier, ArtifactState>((ref) {
  return ArtifactNotifier(ref.watch(artifactStoreProvider));
});

/// 取某照片的输入产物字节：
/// 按 [kinds] 优先级取第一个已保存的产物；都没有则回退 [fallback]。
Uint8List? artifactBytesFor(
  WidgetRef ref,
  String itemId,
  List<ArtifactKind> kinds, {
  Uint8List? fallback,
}) {
  final st = ref.read(artifactStateProvider);
  for (final kind in kinds) {
    final b = st.bytesOf(itemId, kind);
    if (b != null) return b;
  }
  return fallback;
}

/// 取某照片的输入产物字节（优先产物链，无则原图 workingBytes）。
Uint8List inputBytesFor(WidgetRef ref, ImageItem item, List<ArtifactKind> kinds) {
  return artifactBytesFor(ref, item.id, kinds, fallback: item.workingBytes) ??
      item.workingBytes;
}

/// 独立功能输入：功能完全独立、任意调用。
///
/// 优先级：该功能自己上次保存的产物 → 最近保存的任意产物 → 原图。
/// 这样「矫正后再点矫正」在上次矫正结果上继续，「换背景后再点换背景」
/// 也在上次换背景结果上继续，功能之间不再有固定顺序。
Uint8List independentInputFor(
  WidgetRef ref,
  ImageItem item,
  ArtifactKind selfKind,
) {
  final st = ref.read(artifactStateProvider);
  final self = st.bytesOf(item.id, selfKind);
  if (self != null) return self;
  final last = st.lastSaved[item.id];
  if (last != null) {
    final b = st.bytesOf(item.id, last);
    if (b != null) return b;
  }
  return item.workingBytes;
}
