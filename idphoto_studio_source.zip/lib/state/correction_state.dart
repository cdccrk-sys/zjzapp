import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image/image.dart' as img;

import '../domain/face/correction_service.dart';
import '../domain/face/face_analyzer.dart';
import '../domain/face/face_models.dart';
import '../domain/face/mediapipe_face_analyzer.dart';
import '../domain/import/image_item.dart';
import '../infra/logger/app_logger.dart';
import 'working_image_state.dart';

/// ---- 依赖注入 ----

final faceAnalyzerProvider = Provider<FaceAnalyzer>((ref) {
  return MediaPipeFaceAnalyzer();
});

final correctionServiceProvider = Provider<CorrectionService>((ref) {
  return const CorrectionService();
});

/// ---- 矫正状态 ----

class CorrectionState {
  const CorrectionState({
    this.analyses = const {},
    this.results = const {},
    this.isAnalyzing = false,
    this.analyzingItemId,
  });

  /// item.id → 分析结果。
  final Map<String, FaceAnalysisResult> analyses;

  /// item.id → 矫正结果（存在即表示该照片已矫正）。
  final Map<String, CorrectionResult> results;

  final bool isAnalyzing;
  final String? analyzingItemId;

  CorrectionState copyWith({
    Map<String, FaceAnalysisResult>? analyses,
    Map<String, CorrectionResult>? results,
    bool? isAnalyzing,
    String? analyzingItemId,
  }) {
    return CorrectionState(
      analyses: analyses ?? this.analyses,
      results: results ?? this.results,
      isAnalyzing: isAnalyzing ?? this.isAnalyzing,
      analyzingItemId: analyzingItemId ?? this.analyzingItemId,
    );
  }
}

class CorrectionNotifier extends StateNotifier<CorrectionState> {
  CorrectionNotifier(this._analyzer, this._service, this._ref)
      : super(const CorrectionState());

  final FaceAnalyzer _analyzer;
  final CorrectionService _service;
  final Ref _ref;

  /// 解码缓存：item.id[:source] → 已解码图像，避免重复 decodeImage。
  final Map<String, img.Image> _decodedCache = {};

  img.Image? _decoded(ImageItem item, {Uint8List? sourceBytes}) {
    final key = sourceBytes != null ? '${item.id}#src' : item.id;
    final cached = _decodedCache[key];
    if (cached != null) return cached;
    final decoded = img.decodeImage(sourceBytes ?? item.workingBytes);
    if (decoded != null) _decodedCache[key] = decoded;
    return decoded;
  }

  /// 对指定照片执行人脸分析（sourceBytes：在指定输入图上分析，默认原工作图）。
  Future<void> analyze(ImageItem item, {Uint8List? sourceBytes}) async {
    if (state.isAnalyzing) return;
    state = state.copyWith(isAnalyzing: true, analyzingItemId: item.id);
    try {
      final decoded = _decoded(item, sourceBytes: sourceBytes);
      if (decoded == null) {
        state = state.copyWith(isAnalyzing: false, analyzingItemId: null);
        return;
      }
      final analysis = await _analyzer.analyze(decoded);
      state = state.copyWith(
        analyses: {...state.analyses, item.id: analysis},
        isAnalyzing: false,
        analyzingItemId: null,
      );
    } catch (e) {
      AppLogger.instance.error('人脸分析失败', e);
      state = state.copyWith(isAnalyzing: false, analyzingItemId: null);
    }
  }

  /// 自动矫正：按眼睛水平旋转（在指定输入图上矫正，默认原工作图）。
  Future<void> applyAutoCorrection(ImageItem item,
      {Uint8List? sourceBytes}) async {
    final analysis = state.analyses[item.id];
    if (analysis == null || !analysis.hasFace || analysis.primaryFace == null) {
      return;
    }
    final decoded = _decoded(item, sourceBytes: sourceBytes);
    if (decoded == null) return;
    final result = _service.applyAutoCorrection(
      source: decoded,
      face: analysis.primaryFace!,
      analysis: analysis,
    );
    state = state.copyWith(
      results: {...state.results, item.id: result},
    );
    _ref.read(workingImageProvider.notifier).set(item.id, result.correctedBytes);
  }

  /// 手动旋转微调（在指定输入图上旋转，默认原工作图）。
  Future<void> setManualRotation(ImageItem item, double degrees,
      {Uint8List? sourceBytes}) async {
    final decoded = _decoded(item, sourceBytes: sourceBytes);
    if (decoded == null) return;
    final analysis = state.analyses[item.id];
    final result = _service.applyRotation(
      source: decoded,
      rotationDegrees: degrees,
      analysis: analysis,
    );
    state = state.copyWith(
      results: {...state.results, item.id: result},
    );
    _ref.read(workingImageProvider.notifier).set(item.id, result.correctedBytes);
  }

  /// 重置该照片的矫正结果。
  void reset(ImageItem item) {
    final analyses = Map<String, FaceAnalysisResult>.from(state.analyses);
    final results = Map<String, CorrectionResult>.from(state.results);
    analyses.remove(item.id);
    results.remove(item.id);
    state = state.copyWith(analyses: analyses, results: results);
    _ref.read(workingImageProvider.notifier).clear(item.id);
  }
}

final correctionStateProvider =
    StateNotifierProvider<CorrectionNotifier, CorrectionState>((ref) {
  return CorrectionNotifier(
    ref.watch(faceAnalyzerProvider),
    ref.watch(correctionServiceProvider),
    ref,
  );
});

/// 当前用于矫正步骤的照片：默认第一张导入的照片。
final correctionSelectedItemProvider = StateProvider<ImageItem?>((ref) => null);

/// 解码辅助。
Uint8List encodeWorking(img.Image image) =>
    Uint8List.fromList(img.encodeJpg(image, quality: 92));
