import 'package:flutter/foundation.dart';

/// 极简日志器：开发期打印 + 关键事件回调。
///
/// M4 里程碑将替换为文件轮转日志（不包含照片内容）。
class AppLogger {
  AppLogger._();

  static final AppLogger instance = AppLogger._();

  final ValueNotifier<List<String>> _buffer = ValueNotifier(const []);

  void debug(String message) {
    _log('DEBUG', message);
    debugPrint('[IDPhoto][DEBUG] $message');
  }

  void info(String message) {
    _log('INFO', message);
    debugPrint('[IDPhoto][INFO] $message');
  }

  void warn(String message) {
    _log('WARN', message);
    debugPrint('[IDPhoto][WARN] $message');
  }

  void error(String message, [Object? error, StackTrace? stack]) {
    _log('ERROR', '$message ${error ?? ''}');
    debugPrint('[IDPhoto][ERROR] $message ${error ?? ''}');
    if (stack != null) {
      debugPrint('$stack');
    }
  }

  void _log(String level, String message) {
    final line = '${DateTime.now().toIso8601String()} [$level] $message';
    final next = [..._buffer.value];
    next.add(line);
    if (next.length > 200) {
      next.removeRange(0, next.length - 200);
    }
    _buffer.value = next;
  }
}
