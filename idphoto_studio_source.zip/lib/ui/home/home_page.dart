import 'dart:async';

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/matting/segmenter.dart';

import '../../domain/artifacts/artifact_store.dart';
import '../../domain/import/image_item.dart';
import '../../state/artifact_state.dart';
import '../../state/import_state.dart';
import '../../state/selected_item_state.dart';
import '../settings/settings_page.dart';
import '../wizard/background_step.dart';
import '../wizard/correction_step.dart';
import '../wizard/crop_step.dart';
import '../wizard/enhance_step.dart';
import '../wizard/export_step.dart';

import '../wizard/matting_step.dart';
import '../wizard/print_step.dart';

/// 独立功能主页：大图预览 + 底部功能按钮，每个功能独立处理、独立保存产物文件。
///
/// 替代原 8 步向导：功能之间不再强制顺序，每个功能「确定并保存」后
/// 结果写入 `<文档>/artifacts/<照片ID>/<功能>.jpg|png`，下一个功能
/// 优先读取上一个功能的产物文件作为输入。大图预览优先显示最新产物。
class HomePage extends ConsumerStatefulWidget {
  const HomePage({super.key});

  @override
  ConsumerState<HomePage> createState() => _HomePageState();
}

class _HomePageState extends ConsumerState<HomePage> {
  @override
  void initState() {
    super.initState();
    // 后台预热 BiRefNet 高精抠图模型（TFLite），避免首次抠图长时间等待。
    if (!kIsWeb && defaultTargetPlatform == TargetPlatform.android) {
      unawaited(NativeTfliteSegmenter().warmup());
    }
  }

  /// 首页导入：直接打开系统照片选择器，导入后立即进入功能界面。
  /// 单张模式：导入新照片前清掉旧照片及全部产物。
  Future<void> _importPhoto(BuildContext context) async {
    final importNotifier = ref.read(importStateProvider.notifier);
    final artNotifier = ref.read(artifactStateProvider.notifier);
    for (final old in ref.read(importStateProvider).items) {
      await artNotifier.clear(old.id);
    }
    if (ref.read(importStateProvider).items.isNotEmpty) {
      importNotifier.clear();
    }
    await importNotifier.pickAndImport();
    final items = ref.read(importStateProvider).items;
    if (items.isNotEmpty) {
      ref.read(selectedItemIdProvider.notifier).state = items.last.id;
    }
  }

  @override
  Widget build(BuildContext context) {
    final items = ref.watch(importStateProvider).items;
    final selectedId = ref.watch(selectedItemIdProvider);
    final artifacts = ref.watch(artifactStateProvider);

    return Scaffold(
      appBar: AppBar(
        title: const Text('证件照工坊'),
        actions: [
          IconButton(
            tooltip: '导入照片',
            icon: const Icon(Icons.add_photo_alternate_outlined),
            onPressed: () => _importPhoto(context),
          ),
          IconButton(
            tooltip: '设置与帮助',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsPage()),
            ),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: items.isEmpty
          ? _ImportFirstHint(onImport: () => _importPhoto(context))
          : Column(
              children: [
                Expanded(
                  child: _LargePreview(
                    item: items.where((e) => e.id == selectedId).firstOrNull,
                  ),
                ),
                SafeArea(
                  top: false,
                  child: _FunctionBar(
                    items: items,
                    selectedId: selectedId,
                    artifacts: artifacts,
                  ),
                ),
              ],
            ),
    );
  }
}

/// 大图预览：优先显示最新产物（优化→裁剪→换背景→抠图→矫正→原图），
/// 用 cacheWidth 降采样解码，避免全分辨率大图导致卡顿与内存飙升。
class _LargePreview extends ConsumerWidget {
  const _LargePreview({required this.item});

  final ImageItem? item;

  static const List<ArtifactKind> _chain = [
    ArtifactKind.enhanced,
    ArtifactKind.cropped,
    ArtifactKind.background,
    ArtifactKind.matting,
    ArtifactKind.corrected,
    ArtifactKind.original,
  ];

  /// 最近一次保存的产物优先，其次按处理链回退。
  static List<ArtifactKind> chainFor(ArtifactState st, String itemId) {
    final last = st.lastSaved[itemId];
    if (last != null && !_chain.contains(last)) {
      return [last, ..._chain];
    }
    return _chain;
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final it = item;
    if (it == null) {
      return const SizedBox.expand();
    }
    final artifacts = ref.watch(artifactStateProvider);
    final bytes = artifactBytesFor(
        ref, it.id, _LargePreview.chainFor(artifacts, it.id),
        fallback: it.workingBytes);
    if (bytes == null) {
      return const SizedBox.expand();
    }
    final width = MediaQuery.sizeOf(context).width.toInt();
    final cacheWidth = (width * 1.2).round().clamp(480, 1600);
    return Container(
      color: Colors.black87,
      alignment: Alignment.center,
      child: Image.memory(
        bytes,
        fit: BoxFit.contain,
        cacheWidth: cacheWidth,
        gaplessPlayback: true,
      ),
    );
  }
}

/// 未导入照片时的提示：首页即导入界面，点击直接打开照片选择器。
class _ImportFirstHint extends StatelessWidget {
  const _ImportFirstHint({required this.onImport});

  final VoidCallback onImport;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.add_photo_alternate_outlined,
              size: 56, color: Theme.of(context).colorScheme.outline),
          const SizedBox(height: 12),
          const Text('请先导入照片'),
          const SizedBox(height: 8),
          FilledButton.icon(
            onPressed: onImport,
            icon: const Icon(Icons.add_photo_alternate_outlined),
            label: const Text('导入照片'),
          ),
        ],
      ),
    );
  }
}

/// 功能卡片网格。
class _FunctionBar extends ConsumerWidget {
  const _FunctionBar({
    required this.items,
    required this.selectedId,
    required this.artifacts,
  });

  final List<ImageItem> items;
  final String? selectedId;
  final ArtifactState artifacts;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final selected = items.where((e) => e.id == selectedId).firstOrNull;
    if (selected == null) {
      return const SizedBox.shrink();
    }

    final entries = <_FunctionEntry>[
      _FunctionEntry(
        key: 'correct',
        label: '矫正',
        icon: Icons.tune,
        done: artifacts.has(selected.id, ArtifactKind.corrected),
        pageBuilder: () => const CorrectionStep(),
      ),
      _FunctionEntry(
        key: 'matting',
        label: '抠图',
        icon: Icons.auto_fix_high,
        done: artifacts.has(selected.id, ArtifactKind.matting),
        pageBuilder: () => const MattingStep(),
      ),
      _FunctionEntry(
        key: 'background',
        label: '换背景',
        icon: Icons.wallpaper,
        done: artifacts.has(selected.id, ArtifactKind.background),
        pageBuilder: () => const BackgroundStep(),
      ),
      _FunctionEntry(
        key: 'crop',
        label: '裁剪',
        icon: Icons.crop,
        done: artifacts.has(selected.id, ArtifactKind.cropped),
        pageBuilder: () => const CropStep(),
      ),
      _FunctionEntry(
        key: 'enhance',
        label: '优化',
        icon: Icons.auto_awesome,
        done: artifacts.has(selected.id, ArtifactKind.enhanced),
        pageBuilder: () => const EnhanceStep(),
      ),
      _FunctionEntry(
        key: 'print',
        label: '排版',
        icon: Icons.grid_on,
        done: artifacts.has(selected.id, ArtifactKind.enhanced),
        pageBuilder: () => const PrintStep(),
      ),
      _FunctionEntry(
        key: 'export',
        label: '导出',
        icon: Icons.ios_share,
        done: false,
        pageBuilder: () => const ExportStep(),
      ),
    ];

    return Material(
      color: Theme.of(context).colorScheme.surfaceContainerHighest,
      child: SizedBox(
        height: 76,
        child: ListView.separated(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
          scrollDirection: Axis.horizontal,
          itemCount: entries.length,
          separatorBuilder: (_, __) => const SizedBox(width: 6),
          itemBuilder: (context, index) =>
              _FunctionButton(entry: entries[index]),
        ),
      ),
    );
  }
}

class _FunctionEntry {
  const _FunctionEntry({
    required this.key,
    required this.label,
    required this.icon,
    required this.done,
    required this.pageBuilder,
  });

  final String key;
  final String label;
  final IconData icon;
  final bool done;
  final Widget Function() pageBuilder;
}

class _FunctionButton extends ConsumerWidget {
  const _FunctionButton({required this.entry});

  final _FunctionEntry entry;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    return InkWell(
      borderRadius: BorderRadius.circular(10),
      onTap: () => Navigator.of(context).push(
        MaterialPageRoute(builder: (_) => entry.pageBuilder()),
      ),
      child: Container(
        width: 62,
        decoration: BoxDecoration(
          color: theme.colorScheme.surface,
          borderRadius: BorderRadius.circular(10),
          border: Border.all(
            color: entry.done
                ? theme.colorScheme.primary
                : theme.colorScheme.outlineVariant,
          ),
        ),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Stack(
              children: [
                Icon(entry.icon, size: 22, color: theme.colorScheme.primary),
                if (entry.done)
                  Positioned(
                    right: -8,
                    bottom: -8,
                    child: Icon(Icons.check_circle,
                        size: 13, color: theme.colorScheme.primary),
                  ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              entry.label,
              style: theme.textTheme.labelSmall,
              maxLines: 1,
              overflow: TextOverflow.ellipsis,
            ),
          ],
        ),
      ),
    );
  }
}

