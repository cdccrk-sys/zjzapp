import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:path_provider/path_provider.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image/image.dart' as img;

import '../../domain/artifacts/artifact_store.dart';
import '../../domain/import/image_item.dart';
import '../../domain/matting/background.dart';
import '../../state/artifact_state.dart';
import '../../state/import_state.dart';
import '../../state/selected_item_state.dart';
import '../../state/matting_state.dart';

/// 步骤 3「抠图」：AI 分割 + 背景换色 + 手动画笔修补。
class MattingStep extends ConsumerStatefulWidget {
  const MattingStep({super.key});

  @override
  ConsumerState<MattingStep> createState() => _MattingStepState();
}

class _MattingStepState extends ConsumerState<MattingStep> {
  bool _showResult = true;

  @override
  Widget build(BuildContext context) {
    final items = ref.watch(importStateProvider).items;
    final selectedId = ref.watch(selectedItemIdProvider);
    final selected =
        items.where((e) => e.id == selectedId).firstOrNull;

    if (selected == null && items.isNotEmpty) {
      Future.microtask(() {
        if (!mounted) return;
        if (ref.read(selectedItemIdProvider) == null) {
          ref.read(selectedItemIdProvider.notifier).state = items.first.id;
        }
      });
    }

    // 选中变化时自动抠图（若尚未抠过）。
    ref.listen(selectedItemIdProvider, (prev, next) {
      if (next == null) return;
      final item = items.where((e) => e.id == next).firstOrNull;
      if (item == null) return;
      final st = ref.read(mattingStateProvider);
      if (st.masks[item.id] == null && !st.isProcessing) {
        ref.read(mattingStateProvider.notifier).segment(
              item,
              sourceBytes: independentInputFor(
                  ref, item, ArtifactKind.matting),
            );
      }
    });

    // 进入页面时选中项已存在但尚未抠图：立即触发。
    if (selected != null &&
        ref.read(mattingStateProvider).masks[selected.id] == null &&
        !ref.read(mattingStateProvider).isProcessing) {
      Future.microtask(() {
        if (!mounted) return;
        final st = ref.read(mattingStateProvider);
        if (st.masks[selected.id] == null && !st.isProcessing) {
          ref.read(mattingStateProvider.notifier).segment(
                selected,
                sourceBytes: independentInputFor(
                    ref, selected, ArtifactKind.matting),
              );
        }
      });
    }

    if (items.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('抠图')),
        body: _EmptyHint(onBack: () => Navigator.of(context).pop()),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('抠图')),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              if (selected != null) ...[
                const _ProcessBanner(),
                const SizedBox(height: 12),
                _PreviewCard(
                  item: selected,
                  showResult: _showResult,
                  onToggle: (v) => setState(() => _showResult = v),
                ),
                const SizedBox(height: 12),
                _BrushControls(item: selected),
                const SizedBox(height: 12),
                Card(
                  color: Theme.of(context).colorScheme.surfaceContainerHighest,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Column(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [
                        Text(
                          '抠图结果将保存为透明底 PNG；随后可在「换背景」功能中设置底色。',
                          style: Theme.of(context)
                              .textTheme
                              .bodySmall
                              ?.copyWith(
                                color: Theme.of(context)
                                    .colorScheme
                                    .onSurfaceVariant,
                              ),
                        ),
                        const SizedBox(height: 6),
                        Text(
                          _sourceLabel(
                            ref
                                .watch(mattingStateProvider)
                                .sources[selected.id],
                            ref
                                .watch(mattingStateProvider)
                                .lastError,
                          ),
                          style: Theme.of(context)
                              .textTheme
                              .labelSmall
                              ?.copyWith(
                                color: Theme.of(context)
                                    .colorScheme
                                    .primary,
                                fontWeight: FontWeight.w600,
                              ),
                        ),
                        Align(
                          alignment: Alignment.centerRight,
                          child: TextButton.icon(
                            onPressed: () => _showDiagnostics(context),
                            icon: const Icon(Icons.bug_report_outlined,
                                size: 16),
                            label: const Text('查看诊断日志'),
                            style: TextButton.styleFrom(
                              visualDensity: VisualDensity.compact,
                              textStyle:
                                  Theme.of(context).textTheme.labelSmall,
                            ),
                          ),
                        ),
                      ],
                    ),
                  ),
                ),
                const SizedBox(height: 16),
                _SaveButton(item: selected),
              ],
            ],
          ),
        ),
      ],
    ),
  );
  }

  /// 读取并展示 ONNX 推理阶段日志（崩溃后重启仍可查看）。
  Future<void> _showDiagnostics(BuildContext context) async {
    try {
      final support = await getApplicationSupportDirectory();
      final stage = File('${support.path}/onnx_stage.log');
      final crash = File('${support.path}/onnx_crash.log');
      var body = '';
      if (await stage.exists()) body += '===== 推理阶段日志 =====\n${await stage.readAsString()}\n\n';
      if (await crash.exists()) body += '===== 崩溃日志 =====\n${await crash.readAsString()}\n\n';
      if (body.isEmpty) body = '暂无诊断日志（说明模型加载/推理未记录到异常）';
      if (!context.mounted) return;
      showDialog<void>(
        context: context,
        builder: (ctx) => AlertDialog(
          title: const Text('抠图诊断日志'),
          content: SingleChildScrollView(
            child: SelectableText(body, style: const TextStyle(fontSize: 12)),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(ctx),
              child: const Text('关闭'),
            ),
          ],
        ),
      );
    } catch (e) {
      if (!context.mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('读取诊断日志失败：$e')),
      );
    }
  }

  /// 分割来源标签：便于确认当前使用的抠图模型与失败原因。
  String _sourceLabel(String? source, String? error) {
    final base = switch (source) {
      'onnx' => '当前模型：BiRefNet 高精抠图（发丝级）',
      'u2net' => '当前模型：U2Net 高精抠图（TensorFlow Lite）',
      'geometric' => '当前模型：几何兜底（AI 不可用）',
      _ => 'AI 抠图中…',
    };
    if (error != null && error.isNotEmpty && source == 'geometric') {
      final brief = error.length > 200 ? error.substring(0, 200) : error;
      return '$base\n失败原因：$brief';
    }
    return base;
  }
}

class _ProcessBanner extends ConsumerWidget {
  const _ProcessBanner();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final st = ref.watch(mattingStateProvider);
    if (!st.isProcessing) return const SizedBox.shrink();
    final progress = st.batchTotal > 0
        ? '（${st.batchDone}/${st.batchTotal}，成功 ${st.batchSuccess}）'
        : '';
    return Card(
      child: ListTile(
        leading: SizedBox(
          width: 24,
          height: 24,
          child: CircularProgressIndicator(
            strokeWidth: 2.5,
            value: st.batchTotal > 0 ? st.batchDone / st.batchTotal : null,
          ),
        ),
        title: Text('AI 抠图中$progress…'),
        subtitle: const Text('本地推理，照片不会上传'),
        dense: true,
        contentPadding: const EdgeInsets.symmetric(horizontal: 16, vertical: 4),
      ),
    );
  }
}

/// 预览卡片：原图 / 抠图结果对比 + 画笔画布。
class _PreviewCard extends ConsumerStatefulWidget {
  const _PreviewCard({
    required this.item,
    required this.showResult,
    required this.onToggle,
  });

  final ImageItem item;
  final bool showResult;
  final ValueChanged<bool> onToggle;

  @override
  ConsumerState<_PreviewCard> createState() => _PreviewCardState();
}

class _PreviewCardState extends ConsumerState<_PreviewCard> {
  /// 预览分辨率（长边）。
  static const double _maxSide = 480;

  img.Image? _baseImage; // 缩小后的原图
  Uint8List? _previewMask; // 缩小后的蒙版
  int _previewW = 0;
  int _previewH = 0;
  double _scale = 1; // 预览 → 原图比例

  /// composite 缓存：key = mask+背景+showResult，value = 编码后的 PNG/JPG bytes。
  Uint8List? _cachedDisplay;
  String? _cachedDisplayKey;

  void _ensurePreview(WidgetRef ref) {
    final mask = ref.read(mattingStateProvider).masks[widget.item.id];
    if (mask == null) return;
    final targetMask = Uint8List.fromList(mask);
    if (_previewMask != null &&
        targetMask.length == _previewMask!.length &&
        _isSame(targetMask, _previewMask!)) {
      return;
    }
    // 蒙版内容变化（画笔涂抹）：强制刷新 composite 缓存。
    _cachedDisplay = null;
    _cachedDisplayKey = null;
    final decoded = img.decodeImage(
        independentInputFor(ref, widget.item, ArtifactKind.matting));
    if (decoded == null) return;
    final side = math.max(decoded.width, decoded.height);
    final factor = side > _maxSide ? _maxSide / side : 1.0;
    final base = factor < 1.0
        ? img.copyResize(decoded,
            width: (decoded.width * factor).round(),
            height: (decoded.height * factor).round(),
            interpolation: img.Interpolation.linear)
        : decoded;
    _baseImage = base;
    _previewW = base.width;
    _previewH = base.height;
    _scale = decoded.width / base.width;

    // 缩小蒙版（最近邻到预览尺寸）。
    final maskImg = img.Image.fromBytes(
      width: decoded.width,
      height: decoded.height,
      bytes: mask.buffer,
      numChannels: 1,
    );
    final small = img.copyResize(maskImg,
        width: base.width, height: base.height);
    _previewMask = Uint8List(base.width * base.height);
    for (var i = 0; i < _previewMask!.length; i++) {
      _previewMask![i] =
          small.getPixel(i % base.width, i ~/ base.width).r.toInt();
    }
  }

  bool _isSame(Uint8List a, Uint8List b) {
    for (var i = 0; i < a.length; i++) {
      if (a[i] != b[i]) return false;
    }
    return true;
  }

  /// 抠图结果视图：带 alpha 的透明 PNG（人像保留、背景透明）。
  img.Image _alphaImage(WidgetRef ref) {
    ref.read(mattingStateProvider);
    final base = _baseImage!;
    final alpha = img.Image(width: _previewW, height: _previewH, numChannels: 4);
    for (var y = 0; y < _previewH; y++) {
      for (var x = 0; x < _previewW; x++) {
        final v = _previewMask![y * _previewW + x];
        final p = base.getPixel(x, y);
        alpha.setPixelRgba(x, y, p.r.toInt(), p.g.toInt(), p.b.toInt(), v);
      }
    }
    return alpha;
  }

  static ({int r, int g, int b}) _rgbFromPixel(img.Pixel p) =>
      (r: p.r.toInt(), g: p.g.toInt(), b: p.b.toInt());

  // ignore: unused_element
  img.Image _renderOnBackground(WidgetRef ref, img.Image alpha) {
    final bg = ref.read(mattingStateProvider).selectedBackground;
    final out = img.Image(width: _previewW, height: _previewH, numChannels: 3);
    if (bg.type == PhotoBackgroundType.image) {
      img.Image? bgImage;
      if (bg.imageBytes != null) bgImage = img.decodeImage(bg.imageBytes!);
      for (var y = 0; y < _previewH; y++) {
        for (var x = 0; x < _previewW; x++) {
          final a = alpha.getPixel(x, y).a.toInt();
          final p = alpha.getPixel(x, y);
          final fa = a / 255.0;
          final bgc = bgImage == null
              ? _rgb(0xFFFFFFFF)
              : _rgbFromPixel(bgImage.getPixel(
                  (x * bgImage.width / _previewW).floor().clamp(0, bgImage.width - 1),
                  (y * bgImage.height / _previewH).floor().clamp(0, bgImage.height - 1),
                ));
          out.setPixelRgb(
            x,
            y,
            (p.r * fa + bgc.r * (1 - fa)).round().clamp(0, 255),
            (p.g * fa + bgc.g * (1 - fa)).round().clamp(0, 255),
            (p.b * fa + bgc.b * (1 - fa)).round().clamp(0, 255),
          );
        }
      }
    } else if (bg.type == PhotoBackgroundType.gradient) {
      final c0 = _rgb(bg.color);
      final c1 = _rgb(bg.colorEnd ?? bg.color);
      for (var y = 0; y < _previewH; y++) {
        for (var x = 0; x < _previewW; x++) {
          final t = bg.direction == GradientDirection.topToBottom
              ? _previewH <= 1 ? 0.0 : y / (_previewH - 1)
              : _previewW <= 1 ? 0.0 : x / (_previewW - 1);
          final a = alpha.getPixel(x, y).a.toInt();
          final p = alpha.getPixel(x, y);
          final fa = a / 255.0;
          out.setPixelRgb(
            x,
            y,
            (p.r * fa + (c0.r + (c1.r - c0.r) * t) * (1 - fa)).round().clamp(0, 255),
            (p.g * fa + (c0.g + (c1.g - c0.g) * t) * (1 - fa)).round().clamp(0, 255),
            (p.b * fa + (c0.b + (c1.b - c0.b) * t) * (1 - fa)).round().clamp(0, 255),
          );
        }
      }
    } else if (bg.isTransparent) {
      return alpha;
    } else {
      final c = _rgb(bg.color);
      for (var y = 0; y < _previewH; y++) {
        for (var x = 0; x < _previewW; x++) {
          final a = alpha.getPixel(x, y).a.toInt();
          final p = alpha.getPixel(x, y);
          final fa = a / 255.0;
          out.setPixelRgb(
            x,
            y,
            (p.r * fa + c.r * (1 - fa)).round().clamp(0, 255),
            (p.g * fa + c.g * (1 - fa)).round().clamp(0, 255),
            (p.b * fa + c.b * (1 - fa)).round().clamp(0, 255),
          );
        }
      }
    }
    return out;
  }

  static ({int r, int g, int b}) _rgb(int argb) => (
        r: (argb >> 16) & 0xFF,
        g: (argb >> 8) & 0xFF,
        b: argb & 0xFF,
      );

  /// 画笔拖动（预览坐标 → 原图坐标）。
  void _onBrushDrag(BuildContext context, WidgetRef ref, Offset local) {
    final st = ref.read(mattingStateProvider);
    if (st.masks[widget.item.id] == null) return;
    final size = context.size;
    if (size == null || _baseImage == null) return;
    final px = local.dx / size.width * _previewW;
    final py = local.dy / size.height * _previewH;
    if (px < 0 || py < 0 || px >= _previewW || py >= _previewH) return;
    final add = ref.read(mattingBrushAddProvider);
    const brushRadiusPx = 14.0; // 预览尺寸下的半径
    final cx = (px * _scale).round();
    final cy = (py * _scale).round();
    final radius = (brushRadiusPx * _scale).round();
    ref.read(mattingStateProvider.notifier).repair(
          widget.item,
          cx,
          cy,
          math.max(1, radius),
          add: add,
        );
    setState(() {});
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    ref.watch(mattingStateProvider);

    // 若还没有蒙版，显示占位。
    final st = ref.read(mattingStateProvider);
    final hasMask = st.masks[widget.item.id] != null;
    if (!hasMask) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(24),
          child: Column(
            children: [
              const SizedBox(height: 32),
              Icon(Icons.auto_fix_high, size: 56, color: theme.colorScheme.outline),
              const SizedBox(height: 12),
              const Text('自动抠图进行中或尚未开始'),
              const SizedBox(height: 32),
            ],
          ),
        ),
      );
    }

    _ensurePreview(ref);
    if (_baseImage == null) {
      return const SizedBox(height: 200, child: Center(child: CircularProgressIndicator()));
    }

    final bg = ref.read(mattingStateProvider).selectedBackground;
    final key = '${widget.showResult}|${bg.type}|${bg.color}|${bg.colorEnd}|${_previewMask?.length}|${_previewMask?.isEmpty ?? true}';
    if (_cachedDisplay == null || _cachedDisplayKey != key) {
      final display = widget.showResult ? _alphaImage(ref) : _baseImage!;
      _cachedDisplay = Uint8List.fromList(
        widget.showResult
            ? img.encodePng(display)
            : img.encodeJpg(display, quality: 85),
      );
      _cachedDisplayKey = key;
    }
    final Uint8List png = _cachedDisplay!;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Text('原图', style: theme.textTheme.labelSmall),
            Switch(value: widget.showResult, onChanged: widget.onToggle),
            Text('抠图结果', style: theme.textTheme.labelSmall),
          ],
        ),
        const SizedBox(height: 4),
        Center(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: AspectRatio(
              aspectRatio: _previewW / _previewH,
              child: GestureDetector(
                onPanStart: (d) => _onBrushDrag(context, ref, d.localPosition),
                onPanUpdate: (d) => _onBrushDrag(context, ref, d.localPosition),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    // 棋盘格垫底（仅示意透明区域），透明 PNG 人像覆盖其上。
                    if (widget.showResult)
                      Positioned.fill(
                        child: IgnorePointer(
                          child: CustomPaint(
                            painter: _CheckerboardPainter(),
                          ),
                        ),
                      ),
                    Image.memory(
                      png,
                      fit: BoxFit.contain,
                      gaplessPlayback: true,
                    ),
                  ],
                ),
              ),
            ),
          ),
        ),
        if (widget.showResult) ...[
          const SizedBox(height: 6),
          Text(
            '在结果图上直接涂抹：前景笔恢复人物，背景笔擦除多余区域',
            style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline),
            textAlign: TextAlign.center,
          ),
        ],
      ],
    );
  }
}

/// 透明区域棋盘格（预览透明底时显示）。
class _CheckerboardPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    const cell = 12.0;
    final paint = Paint();
    for (var y = 0; y < size.height / cell; y++) {
      for (var x = 0; x < size.width / cell; x++) {
        paint.color = ((x + y) % 2 == 0)
            ? const Color(0xFFE8E8E8)
            : const Color(0xFFFFFFFF);
        canvas.drawRect(
          Rect.fromLTWH(x * cell, y * cell, cell, cell),
          paint,
        );
      }
    }
  }

  @override
  bool shouldRepaint(covariant CustomPainter oldDelegate) => false;
}

/// 画笔控制条。
class _BrushControls extends ConsumerWidget {
  const _BrushControls({required this.item});

  final ImageItem item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final add = ref.watch(mattingBrushAddProvider);
    final hasMask = ref.watch(mattingStateProvider).masks[item.id] != null;

    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Row(
          children: [
            Expanded(
              child: SegmentedButton<bool>(
                segments: const [
                  ButtonSegment(value: true, label: Text('前景笔', style: TextStyle(fontSize: 12))),
                  ButtonSegment(value: false, label: Text('背景笔', style: TextStyle(fontSize: 12))),
                ],
                selected: {add},
                onSelectionChanged: hasMask
                    ? (s) =>
                        ref.read(mattingBrushAddProvider.notifier).state = s.first
                    : null,
                showSelectedIcon: false,
                style: const ButtonStyle(
                  visualDensity: VisualDensity.compact,
                ),
              ),
            ),
            IconButton(
              tooltip: '重置抠图',
              onPressed: hasMask
                  ? () => ref.read(mattingStateProvider.notifier).reset(item)
                  : null,
              icon: const Icon(Icons.refresh),
            ),
          ],
        ),
      ),
    );
  }
}

class _SaveButton extends ConsumerWidget {
  const _SaveButton({required this.item});

  final ImageItem item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final st = ref.watch(mattingStateProvider);
    final mask = st.masks[item.id];
    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        FilledButton.icon(
          onPressed: mask == null
              ? null
              : () async {
                  final bytes = _transparentPngBytes(ref, item);
                  if (bytes == null) {
                    if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(content: Text('保存失败，请重试')),
                      );
                    }
                    return;
                  }
                  await ref
                      .read(artifactStateProvider.notifier)
                      .save(item.id, ArtifactKind.matting, bytes);
                  if (context.mounted) {
                    ScaffoldMessenger.of(context).showSnackBar(
                      const SnackBar(content: Text('已保存透明底抠图结果')),
                    );
                    Navigator.of(context).pop();
                  }
                },
          icon: const Icon(Icons.check),
          label: const Text('确定并保存'),
        ),
      ],
    );
  }

  /// 将原图 + 蒙版合成为透明底 PNG 字节。
  Uint8List? _transparentPngBytes(WidgetRef ref, ImageItem item) {
    final st = ref.read(mattingStateProvider);
    final mask = st.masks[item.id];
    if (mask == null) return null;
    final decoded = img.decodeImage(
        independentInputFor(ref, item, ArtifactKind.matting));
    if (decoded == null) return null;
    final alpha = img.Image(
      width: decoded.width,
      height: decoded.height,
      numChannels: 4,
    );
    for (var y = 0; y < decoded.height; y++) {
      for (var x = 0; x < decoded.width; x++) {
        final v = mask[y * decoded.width + x];
        final p = decoded.getPixel(x, y);
        alpha.setPixelRgba(x, y, p.r.toInt(), p.g.toInt(), p.b.toInt(), v);
      }
    }
    return Uint8List.fromList(img.encodePng(alpha));
  }
}

class _EmptyHint extends StatelessWidget {
  const _EmptyHint({required this.onBack});

  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.photo_library_outlined, size: 56, color: theme.colorScheme.outline),
          const SizedBox(height: 12),
          const Text('还没有导入照片'),
          const SizedBox(height: 8),
          TextButton(onPressed: onBack, child: const Text('返回导入')),
        ],
      ),
    );
  }
}

