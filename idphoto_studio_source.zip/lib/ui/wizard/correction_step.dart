import 'dart:math' as math;

import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/artifacts/artifact_store.dart';
import '../../domain/face/face_analysis.dart';
import '../../domain/face/face_models.dart';
import '../../domain/import/image_item.dart';
import '../../state/artifact_state.dart';
import '../../state/correction_state.dart';
import '../../state/import_state.dart';
import '../../state/selected_item_state.dart';

/// 步骤 2「矫正」：人脸分析、质量提示、自动/手动旋转矫正。
class CorrectionStep extends ConsumerStatefulWidget {
  const CorrectionStep({super.key});

  @override
  ConsumerState<CorrectionStep> createState() => _CorrectionStepState();
}

class _CorrectionStepState extends ConsumerState<CorrectionStep> {
  bool _showCorrected = true;
  /// 滑杆拖动中的实时角度（null=未在拖动）。
  double? _liveDegrees;

  /// 独立功能输入：上次矫正产物（若存在），否则最近产物/原图。
  Uint8List? _sourceBytes;

  @override
  Widget build(BuildContext context) {
    final items = ref.watch(importStateProvider).items;
    final selectedId = ref.watch(selectedItemIdProvider);
    final selected = items.where((e) => e.id == selectedId).firstOrNull;

    // 首次进入时初始化选中项。
    if (selected == null && items.isNotEmpty) {
      Future.microtask(() {
        if (!mounted) return;
        if (ref.read(selectedItemIdProvider) == null) {
          ref.read(selectedItemIdProvider.notifier).state = items.first.id;
        }
      });
    }

    // 进入页面时读取独立输入（上次矫正产物优先）。
    if (selected != null && _sourceBytes == null) {
      _sourceBytes = independentInputFor(ref, selected, ArtifactKind.corrected);
    }

    // 选中变化时触发分析。
    ref.listen(selectedItemIdProvider, (prev, next) {
      if (next != null) {
        final item = items.where((e) => e.id == next).firstOrNull;
        if (item != null) {
          ref
              .read(correctionStateProvider.notifier)
              .analyze(item, sourceBytes: _sourceBytes);
        }
      }
    });

    // 进入页面时选中项已存在但尚未分析：立即触发分析。
    if (selected != null &&
        ref.read(correctionStateProvider).analyses[selected.id] == null) {
      Future.microtask(() {
        if (!mounted) return;
        if (ref.read(correctionStateProvider).analyses[selected.id] == null) {
          ref
              .read(correctionStateProvider.notifier)
              .analyze(selected, sourceBytes: _sourceBytes);
        }
      });
    }

    if (items.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('矫正')),
        body: _EmptyHint(onBack: () => Navigator.of(context).pop()),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('矫正')),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                if (selected != null) ...[
                  _AnalysisBanner(item: selected),
                  const SizedBox(height: 12),
                  _PreviewCard(
                    item: selected,
                    sourceBytes: _sourceBytes,
                    showCorrected: _showCorrected,
                    onToggleCorrected: (v) =>
                        setState(() => _showCorrected = v),
                    liveDegrees: _liveDegrees,
                  ),
                  const SizedBox(height: 12),
                  _CorrectionControls(
                    item: selected,
                    sourceBytes: _sourceBytes,
                    liveDegrees: _liveDegrees,
                    onLiveDegrees: (v) => setState(() => _liveDegrees = v),
                    onLiveEnd: (v) => setState(() => _liveDegrees = null),
                  ),
                ],
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// 质量提示横幅。
class _AnalysisBanner extends ConsumerWidget {
  const _AnalysisBanner({required this.item});

  final ImageItem item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(correctionStateProvider);
    final analysis = state.analyses[item.id];
    final theme = Theme.of(context);

    if (state.isAnalyzing && state.analyzingItemId == item.id) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              const SizedBox(
                width: 18,
                height: 18,
                child: CircularProgressIndicator(strokeWidth: 2),
              ),
              const SizedBox(width: 12),
              Text('正在分析人脸…', style: theme.textTheme.bodyMedium),
            ],
          ),
        ),
      );
    }

    if (analysis == null) {
      return Card(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Text('点击照片开始分析', style: theme.textTheme.bodyMedium),
        ),
      );
    }

    if (!analysis.analyzerAvailable) {
      return Card(
        color: theme.colorScheme.errorContainer,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Text(
            '分析器不可用：${analysis.analyzerUnavailableReason}\n'
            '仍可使用下方手动旋转微调。',
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.onErrorContainer),
          ),
        ),
      );
    }

    final warnings = analysis.issues;
    final colors = <Color>[];
    for (final issue in warnings) {
      colors.add(switch (issue.type) {
        FaceIssueType.blurry ||
        FaceIssueType.sideFace ||
        FaceIssueType.occluded ||
        FaceIssueType.noFace ||
        FaceIssueType.multipleFaces =>
          theme.colorScheme.errorContainer,
        FaceIssueType.tilted => theme.colorScheme.secondaryContainer,
      });
    }

    if (warnings.isEmpty) {
      return Card(
        color: theme.colorScheme.primaryContainer,
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Icon(Icons.check_circle_outline,
                  color: theme.colorScheme.onPrimaryContainer),
              const SizedBox(width: 8),
              Text(
                '检测到人脸，${_qualityText(analysis)}',
                style: theme.textTheme.bodyMedium
                    ?.copyWith(color: theme.colorScheme.onPrimaryContainer),
              ),
            ],
          ),
        ),
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            for (var i = 0; i < warnings.length; i++)
              Padding(
                padding: EdgeInsets.only(bottom: i == warnings.length - 1 ? 0 : 6),
                child: Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(8),
                  decoration: BoxDecoration(
                    color: colors[i],
                    borderRadius: BorderRadius.circular(8),
                  ),
                  child: Text(
                    '${i + 1}. ${warnings[i].message}',
                    style: theme.textTheme.bodySmall,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }

  String _qualityText(FaceAnalysisResult analysis) {
    final face = analysis.primaryFace;
    final parts = <String>[];
    if (face != null) {
      parts.add('清晰度 ${analysis.blurScore.round()}');
      if (face.yawDegrees != null) parts.add('偏航 ${face.yawDegrees!.round()}°');
      if (face.rollDegrees != null) parts.add('倾斜 ${face.rollDegrees!.round()}°');
    }
    return parts.isEmpty ? '照片清晰' : parts.join(' · ');
  }
}

/// 预览卡片：原图 / 矫正后 + 关键点叠加。
class _PreviewCard extends ConsumerWidget {
  const _PreviewCard({
    required this.item,
    required this.showCorrected,
    required this.onToggleCorrected,
    this.sourceBytes,
    this.liveDegrees,
  });

  final ImageItem item;
  final bool showCorrected;
  final ValueChanged<bool> onToggleCorrected;

  /// 独立功能输入图（上次矫正产物等）。
  final Uint8List? sourceBytes;

  /// 滑杆拖动中的实时角度（用于 UI 层实时旋转预览）。
  final double? liveDegrees;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(correctionStateProvider);
    final result = state.results[item.id];
    final analysis = state.analyses[item.id];
    final theme = Theme.of(context);

    final dragging = liveDegrees != null;
    // 独立输入：'矫正前' 显示本次输入图（可能是上次矫正产物）。
    final source = sourceBytes ?? item.workingBytes;
    final bytes = showCorrected && result != null && !dragging
        ? result.correctedBytes
        : source;

    // 预览盒与图片宽高比严格一致（叠加层才对齐），且限制最大高度。
    final imageAspect = ((result != null ? result.width : item.workingWidth) /
            (result != null ? result.height : item.workingHeight))
        .clamp(0.4, 2.5);

    return Card(
      clipBehavior: Clip.antiAlias,
      child: Column(
        children: [
          Padding(
            padding: const EdgeInsets.fromLTRB(12, 8, 12, 0),
            child: Row(
              children: [
                Text('预览', style: theme.textTheme.titleSmall),
                const Spacer(),
                SegmentedButton<bool>(
                  showSelectedIcon: false,
                  style: const ButtonStyle(
                    visualDensity: VisualDensity.compact,
                  ),
                  segments: const [
                    ButtonSegment(value: false, label: Text('矫正前')),
                    ButtonSegment(value: true, label: Text('矫正后')),
                  ],
                  selected: {showCorrected && result != null},
                  onSelectionChanged: result == null
                      ? null
                      : (s) => onToggleCorrected(s.first),
                ),
              ],
            ),
          ),
          Center(
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxHeight: 380),
              child: AspectRatio(
                aspectRatio: imageAspect,
                child: LayoutBuilder(
                  builder: (context, constraints) {
                    return Stack(
                      fit: StackFit.expand,
                      children: [
                        if (dragging)
                          ClipRect(
                            child: Transform.rotate(
                              angle: liveDegrees! * math.pi / 180,
                              child: Image.memory(
                                source,
                                fit: BoxFit.cover,
                                gaplessPlayback: true,
                                cacheWidth: 1200,
                              ),
                            ),
                          )
                        else
                          Image.memory(
                            bytes,
                            fit: BoxFit.fill,
                            gaplessPlayback: true,
                            cacheWidth: 1200,
                          ),
                        if (analysis != null &&
                            analysis.analyzerAvailable &&
                            analysis.hasFace)
                          CustomPaint(
                            painter: _LandmarkPainter(
                              analysis: analysis,
                              color: theme.colorScheme.primary,
                              // 矫正后预览需把关键点重投影到旋转后的图像上。
                              rotationDegrees:
                                  showCorrected && result != null
                                      ? result.rotationDegrees
                                      : 0,
                            ),
                          ),
                      ],
                    );
                  },
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// 关键点叠加绘制：人脸框、眼线、头部中心、水平参考线。
///
/// [rotationDegrees] 非零时，先把关键点按旋转角度重投影（绕图像中心），
/// 使叠加层与旋转后的预览对齐。
class _LandmarkPainter extends CustomPainter {
  _LandmarkPainter({
    required this.analysis,
    required this.color,
    this.rotationDegrees = 0,
  });

  final FaceAnalysisResult analysis;
  final Color color;
  final double rotationDegrees;

  Offset _project(FacePoint p, Size size) {
    final projected = rotationDegrees == 0
        ? p
        : rotatePointCw(p, rotationDegrees, 1, 1);
    return Offset(projected.x * size.width, projected.y * size.height);
  }

  @override
  void paint(Canvas canvas, Size size) {
    final face = analysis.primaryFace;
    if (face == null) return;

    final paint = Paint()
      ..color = color
      ..strokeWidth = 2
      ..style = PaintingStyle.stroke;

    // 人脸框（四角重投影）。
    final box = face.boundingBox;
    final corners = [
      _project(FacePoint(box.left, box.top), size),
      _project(FacePoint(box.right, box.top), size),
      _project(FacePoint(box.right, box.bottom), size),
      _project(FacePoint(box.left, box.bottom), size),
    ];
    final boxPath = Path()
      ..moveTo(corners[0].dx, corners[0].dy)
      ..lineTo(corners[1].dx, corners[1].dy)
      ..lineTo(corners[2].dx, corners[2].dy)
      ..lineTo(corners[3].dx, corners[3].dy)
      ..close();
    canvas.drawPath(boxPath, paint);

    // 眼睛连线与关键点。
    final eyePaint = Paint()
      ..color = color
      ..strokeWidth = 2.5;
    final leftEye = _project(face.leftEye, size);
    final rightEye = _project(face.rightEye, size);
    final nose = _project(face.nose, size);
    canvas.drawLine(leftEye, rightEye, eyePaint);

    final dotPaint = Paint()..color = color;
    for (final p in [leftEye, rightEye, nose]) {
      canvas.drawCircle(p, 3.5, dotPaint);
    }

    // 头部中心十字。
    final center = _project(computeHeadCenter(face), size);
    final crossPaint = Paint()
      ..color = color.withValues(alpha: 0.8)
      ..strokeWidth = 1.5;
    canvas.drawLine(Offset(center.dx - 8, center.dy), Offset(center.dx + 8, center.dy), crossPaint);
    canvas.drawLine(Offset(center.dx, center.dy - 8), Offset(center.dx, center.dy + 8), crossPaint);
  }

  @override
  bool shouldRepaint(covariant _LandmarkPainter oldDelegate) =>
      oldDelegate.analysis != analysis ||
      oldDelegate.color != color ||
      oldDelegate.rotationDegrees != rotationDegrees;
}

/// 矫正控制：自动矫正 / 手动旋转 / 重置 / 下一步。
class _CorrectionControls extends ConsumerWidget {
  const _CorrectionControls({
    required this.item,
    required this.liveDegrees,
    required this.onLiveDegrees,
    required this.onLiveEnd,
    this.sourceBytes,
  });

  final ImageItem item;
  final double? liveDegrees;
  final ValueChanged<double> onLiveDegrees;
  final ValueChanged<double> onLiveEnd;

  /// 独立功能输入图（上次矫正产物等）。
  final Uint8List? sourceBytes;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final notifier = ref.read(correctionStateProvider.notifier);
    final state = ref.watch(correctionStateProvider);
    final analysis = state.analyses[item.id];
    final result = state.results[item.id];
    final theme = Theme.of(context);

    final canAuto = analysis != null &&
        analysis.analyzerAvailable &&
        analysis.hasFace &&
        analysis.primaryFace != null;

    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Row(
              children: [
                FilledButton.icon(
                  onPressed: canAuto
                      ? () => notifier.applyAutoCorrection(item,
                          sourceBytes: sourceBytes)
                      : null,
                  icon: const Icon(Icons.center_focus_strong),
                  label: const Text('自动矫正'),
                ),
                const SizedBox(width: 8),
                OutlinedButton.icon(
                  onPressed: result == null
                      ? null
                      : () => notifier.reset(item),
                  icon: const Icon(Icons.refresh),
                  label: const Text('重置'),
                ),
                const Spacer(),
                if (result != null)
                  Chip(
                    visualDensity: VisualDensity.compact,
                    avatar: Icon(
                      result.autoCorrected ? Icons.auto_awesome : Icons.tune,
                      size: 14,
                    ),
                    label: Text(
                      result.autoCorrected
                          ? '已自动矫正 ${_fmtAngle(result.rotationDegrees)}'
                          : '手动 ${_fmtAngle(result.rotationDegrees)}',
                      style: theme.textTheme.labelSmall,
                    ),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            Row(
              children: [
                const Text('手动旋转'),
                Expanded(
                  child: Slider(
                    value: (result?.rotationDegrees ?? 0).clamp(-30, 30),
                    min: -30,
                    max: 30,
                    divisions: 120,
                    label: '${(result?.rotationDegrees ?? 0).round()}°',
                    // 拖动：仅 UI 层实时旋转，绝不重渲染位图。
                    onChanged: (v) => onLiveDegrees(v),
                    onChangeEnd: (v) {
                      onLiveEnd(v);
                      notifier.setManualRotation(item, v,
                          sourceBytes: sourceBytes);
                    },
                  ),
                ),
                SizedBox(
                  width: 44,
                  child: Text(
                    '${(result?.rotationDegrees ?? 0).round()}°',
                    textAlign: TextAlign.end,
                    style: theme.textTheme.bodySmall,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              '提示：以眼睛水平为准；肩膀水平将在姿态检测（M2）中启用。',
              style: theme.textTheme.bodySmall
                  ?.copyWith(color: theme.colorScheme.outline),
            ),
            const SizedBox(height: 8),
            FilledButton.tonalIcon(
              onPressed: result == null
                  ? null
                  : () async {
                      await ref
                          .read(artifactStateProvider.notifier)
                          .save(item.id, ArtifactKind.corrected,
                              result.correctedBytes);
                      if (context.mounted) {
                        ScaffoldMessenger.of(context).showSnackBar(
                          const SnackBar(content: Text('已保存矫正结果')),
                        );
                        Navigator.of(context).pop();
                      }
                    },
              icon: const Icon(Icons.check),
              label: const Text('确定并保存'),
            ),
          ],
        ),
      ),
    );
  }

  String _fmtAngle(double deg) {
    final v = deg.abs() < 0.05 ? 0.0 : deg;
    return '${v.toStringAsFixed(1)}°';
  }
}

class _EmptyHint extends StatelessWidget {
  const _EmptyHint({required this.onBack});

  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.face_retouching_natural,
                size: 56, color: theme.colorScheme.outline),
            const SizedBox(height: 16),
            Text('请先在「导入」步骤添加照片', style: theme.textTheme.titleMedium),
            const SizedBox(height: 12),
            OutlinedButton.icon(
              onPressed: onBack,
              icon: const Icon(Icons.arrow_back),
              label: const Text('返回导入'),
            ),
          ],
        ),
      ),
    );
  }
}
