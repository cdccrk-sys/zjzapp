import 'package:flutter/material.dart';

/// 未实现步骤的占位页。
class StepPlaceholder extends StatelessWidget {
  const StepPlaceholder({super.key, required this.stepIndex, required this.stepName});

  final int stepIndex;
  final String stepName;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.construction, size: 56, color: theme.colorScheme.outline),
            const SizedBox(height: 16),
            Text(
              '「$stepName」步骤将在后续里程碑实现',
              style: theme.textTheme.titleMedium,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              '当前进度：M1 矫正模块（第 2/8 步）\n'
              '下一步：AI 抠图与换背景模块',
              style: theme.textTheme.bodySmall,
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }
}
