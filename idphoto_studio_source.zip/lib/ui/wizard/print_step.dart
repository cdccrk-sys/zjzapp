import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image/image.dart' as img;

import '../../domain/artifacts/artifact_store.dart';
import '../../domain/crop/crop_service.dart';
import '../../domain/export/export_service.dart';
import '../../domain/layout/print_layout.dart';
import '../../state/artifact_state.dart';
import '../../state/crop_state.dart';
import '../../state/import_state.dart';
import '../../state/print_state.dart';
import '../../state/selected_item_state.dart';

/// 步骤 6「排版」：相纸选择、排版预览与导出（排版图/PDF）。
class PrintStep extends ConsumerStatefulWidget {
  const PrintStep({super.key});

  @override
  ConsumerState<PrintStep> createState() => _PrintStepState();
}

enum _ExportTarget { sheetJpg, sheetPng, pdf }

class _PrintStepState extends ConsumerState<PrintStep> {
  _ExportTarget _target = _ExportTarget.sheetJpg;
  double _quality = 92;

  /// 当前选中照片的裁剪图（规格像素），用于预览与导出。
  img.Image? _previewPhoto;

  /// 预览缓存键（item+裁框+规格），避免每帧重复解码。
  String? _previewKey;
  img.Image? _cachedDecoded;

  void _ensurePreview() {
    final items = ref.read(importStateProvider).items;
    final item = items.where((e) => e.id == ref.read(selectedItemIdProvider))
        .firstOrNull;
    if (item == null) return;
    final rect = ref.read(cropStateProvider).rects[item.id];
    final spec = ref.read(cropStateProvider).selectedSpec;
    final key =
        '${item.id}|${rect?.x},${rect?.y},${rect?.width},${rect?.height}|${spec.id}';
    if (_previewKey == key && _cachedDecoded != null) return;
    _previewKey = key;
    final decoded = img.decodeImage(
        independentInputFor(ref, item, ArtifactKind.enhanced));
    if (decoded == null) return;
    _cachedDecoded = decoded;
    img.Image photo;
    if (rect != null) {
      photo = const CropService().applyCrop(
        _cachedDecoded!,
        rect,
        targetWidth: spec.pixelWidth,
        targetHeight: spec.pixelHeight,
      );
    } else {
      photo = _cachedDecoded!;
    }
    _previewPhoto = photo;
    // 首次进入自动计算排版（post-frame，避免 build 中写 provider）。
    if (ref.read(printStateProvider).layout == null) {
      Future.microtask(() {
        if (!mounted) return;
        ref.read(printStateProvider.notifier).computeLayout(spec);
      });
    }
  }

  void _export() {
    final photo = _previewPhoto;
    final spec = ref.read(cropStateProvider).selectedSpec;
    if (photo == null) return;
    // 单张排版：不再批量跑全部照片管线（避免 OOM）。
    switch (_target) {
      case _ExportTarget.pdf:
        ref.read(printStateProvider.notifier).exportPdf(photo, spec);
      case _ExportTarget.sheetJpg:
        ref.read(printStateProvider.notifier).exportSheet(
              photo,
              spec,
              format: ExportFormat.jpg,
              jpgQuality: _quality.round(),
            );
      case _ExportTarget.sheetPng:
        ref.read(printStateProvider.notifier).exportSheet(
              photo,
              spec,
              format: ExportFormat.png,
            );
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final items = ref.watch(importStateProvider).items;
    final st = ref.watch(printStateProvider);
    _ensurePreview();

    if (items.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('排版')),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.crop_outlined,
                  size: 56, color: theme.colorScheme.outline),
              const SizedBox(height: 12),
              const Text('请先完成「裁剪」并保存产物'),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('返回'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('排版')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
        Text('选择相纸', style: theme.textTheme.titleSmall),
        const SizedBox(height: 8),
        _PaperSelector(st: st),
        const SizedBox(height: 12),
        _LayoutParams(st: st),
        const SizedBox(height: 12),
        if (st.layout != null) ...[
          Text(
            '排版结果：${st.paper.name}（${st.paper.widthMm.toInt()}×${st.paper.heightMm.toInt()}mm）· '
            '${st.layout!.cols}列 × ${st.layout!.rows}行 · 每页 ${st.layout!.perPage} 张 · '
            '共 ${st.layout!.pages.length} 页',
            style: theme.textTheme.bodySmall,
          ),
          const SizedBox(height: 8),
          _PrintPreview(
            photo: _previewPhoto,
            layout: st.layout!,
            paperAspect: st.paper.widthMm / st.paper.heightMm,
          ),
          const SizedBox(height: 12),
        ],
        _OptionToggles(st: st),
        const SizedBox(height: 12),
        _ExportCard(
          st: st,
          target: _target,
          quality: _quality,
          onTarget: (t) => setState(() {
            _target = t;
            if (t != _ExportTarget.sheetJpg) _quality = 92;
          }),
          onQuality: (v) => setState(() => _quality = v),
          onExport: _export,
        ),
        if (st.failures.isNotEmpty)
          Card(
            color: theme.colorScheme.errorContainer,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                st.failures.join('；'),
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onErrorContainer,
                ),
              ),
            ),
          ),
        if (st.results.isNotEmpty)
          Card(
            child: ListTile(
              dense: true,
              leading: const Icon(Icons.print),
              title: Text(st.results.first.fileName),
              subtitle: Text(
                '${st.results.first.width}×${st.results.first.height}px · '
                '${_fmtSize(st.results.first.sizeBytes)} · ${st.results.first.path}',
                style: theme.textTheme.bodySmall,
              ),
            ),
          ),
        const SizedBox(height: 8),
        FilledButton.icon(
          onPressed: () => Navigator.of(context).pop(),
          icon: const Icon(Icons.check),
          label: const Text('完成'),
        ),
      ],
      ),
    );
  }

  static String _fmtSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / 1024 / 1024).toStringAsFixed(2)} MB';
  }
}

/// 相纸选择。
class _PaperSelector extends ConsumerWidget {
  const _PaperSelector({required this.st});

  final PrintState st;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SizedBox(
      height: 40,
      child: ListView.separated(
        scrollDirection: Axis.horizontal,
        itemCount: PaperSpec.builtin.length,
        separatorBuilder: (_, __) => const SizedBox(width: 6),
        itemBuilder: (context, index) {
          final paper = PaperSpec.builtin[index];
          final active = paper.id == st.paperId;
          return ChoiceChip(
            label: Text(paper.name),
            selected: active,
            onSelected: (_) {
              ref.read(printStateProvider.notifier).setPaper(paper.id);
              _recompute(ref);
            },
            showCheckmark: false,
            visualDensity: VisualDensity.compact,
          );
        },
      ),
    );
  }

  void _recompute(WidgetRef ref) {
    final spec = ref.read(cropStateProvider).selectedSpec;
    ref.read(printStateProvider.notifier).computeLayout(spec);
  }
}

/// 间距 / 边距。
class _LayoutParams extends ConsumerWidget {
  const _LayoutParams({required this.st});

  final PrintState st;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Column(
          children: [
            Row(
              children: [
                const Text('照片间距'),
                Expanded(
                  child: Slider(
                    value: st.gapMm,
                    min: 0,
                    max: 8,
                    divisions: 8,
                    label: '${st.gapMm.toStringAsFixed(1)}mm',
                    onChanged: (v) {
                      ref.read(printStateProvider.notifier).setGap(v);
                      _recompute(ref);
                    },
                  ),
                ),
                Text('${st.gapMm.toStringAsFixed(1)}mm'),
              ],
            ),
            Row(
              children: [
                const Text('纸边距'),
                Expanded(
                  child: Slider(
                    value: st.marginMm,
                    min: 0,
                    max: 20,
                    divisions: 10,
                    label: '${st.marginMm.toStringAsFixed(0)}mm',
                    onChanged: (v) {
                      ref.read(printStateProvider.notifier).setMargin(v);
                      _recompute(ref);
                    },
                  ),
                ),
                Text('${st.marginMm.toStringAsFixed(0)}mm'),
              ],
            ),
          ],
        ),
      ),
    );
  }

  void _recompute(WidgetRef ref) {
    final spec = ref.read(cropStateProvider).selectedSpec;
    ref.read(printStateProvider.notifier).computeLayout(spec);
  }
}

/// 排版预览：按比例模拟纸张与网格。
class _PrintPreview extends StatelessWidget {
  const _PrintPreview({
    required this.photo,
    required this.layout,
    required this.paperAspect,
  });

  final img.Image? photo;
  final PrintLayout layout;
  final double paperAspect;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final firstPage = layout.pages.first;
    final page = firstPage;

    return LayoutBuilder(builder: (context, constraints) {
      final maxW = constraints.maxWidth;
      final previewH = (maxW / paperAspect).clamp(80.0, 420.0);
      // 纸张内可用区（模拟边距）。
      final marginFrac =
          layout.marginMm / layout.paper.widthMm * maxW;
      final contentW = maxW - 2 * marginFrac;
      final gapFrac = layout.gapMm / layout.paper.widthMm * maxW;
      final cellW = (contentW - (layout.cols - 1) * gapFrac) / layout.cols;
      final cellH = cellW / (layout.photoWidthMm / layout.photoHeightMm);

      return Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Container(
            height: previewH,
            decoration: BoxDecoration(
              color: Colors.white,
              border: Border.all(color: theme.colorScheme.outlineVariant),
              borderRadius: BorderRadius.circular(6),
              boxShadow: const [
                BoxShadow(color: Colors.black12, blurRadius: 4),
              ],
            ),
            padding: EdgeInsets.all(marginFrac),
            child: Wrap(
              spacing: gapFrac,
              runSpacing: layout.gapMm / layout.paper.heightMm * previewH,
              children: [
                for (final cell in page.cells)
                  _CellThumb(
                    photo: photo,
                    width: cellW,
                    height: cellH,
                    index: cell.index,
                    showNumber: layout.pages.length == 1,
                  ),
              ],
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '预览仅显示第 1 页（共 ${layout.pages.length} 页）',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.outline,
            ),
            textAlign: TextAlign.center,
          ),
        ],
      );
    });
  }
}

class _CellThumb extends StatefulWidget {
  const _CellThumb({
    required this.photo,
    required this.width,
    required this.height,
    required this.index,
    required this.showNumber,
  });

  final img.Image? photo;
  final double width;
  final double height;
  final int index;
  final bool showNumber;

  @override
  State<_CellThumb> createState() => _CellThumbState();
}

class _CellThumbState extends State<_CellThumb> {
  Uint8List? _cachedPng;
  int? _cachedPhotoId;

  @override
  Widget build(BuildContext context) {
    Widget content;
    if (widget.photo != null) {
      final photoId = identityHashCode(widget.photo!);
      if (_cachedPng == null || _cachedPhotoId != photoId) {
        _cachedPng = Uint8List.fromList(img.encodeJpg(widget.photo!, quality: 60));
        _cachedPhotoId = photoId;
      }
      content = Image.memory(
        _cachedPng!,
        width: widget.width,
        height: widget.height,
        fit: BoxFit.cover,
        gaplessPlayback: true,
      );
    } else {
      content = Container(
        width: widget.width,
        height: widget.height,
        color: Colors.blueGrey.shade100,
      );
    }
    return RepaintBoundary(
      child: Container(
        width: widget.width,
        height: widget.height,
        decoration: BoxDecoration(
          border: Border.all(color: Colors.grey.shade500, width: 0.5),
        ),
        child: Stack(
          fit: StackFit.expand,
          children: [
            content,
            if (widget.showNumber)
              Positioned(
                left: 2,
                bottom: 1,
                child: Text(
                  '${widget.index}',
                  style: const TextStyle(
                    fontSize: 9,
                    color: Colors.black54,
                    backgroundColor: Colors.white70,
                  ),
                ),
              ),
          ],
        ),
      ),
    );
  }
}

/// 输出选项开关。
class _OptionToggles extends ConsumerWidget {
  const _OptionToggles({required this.st});

  final PrintState st;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final o = st.options;
    final notifier = ref.read(printStateProvider.notifier);
    Widget sw(String label, bool value, void Function(bool) onChanged) {
      return SwitchListTile(
        dense: true,
        contentPadding: EdgeInsets.zero,
        title: Text(label, style: Theme.of(context).textTheme.bodyMedium),
        value: value,
        onChanged: onChanged,
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Column(
          children: [
            sw('裁剪线（四角毫米刻度）', o.showCutMarks,
                (v) => notifier.setOptions(o.copyWith(showCutMarks: v))),
            sw('出血线（外扩虚线框）', o.showBleed,
                (v) => notifier.setOptions(o.copyWith(showBleed: v))),
            sw('每张编号（1、2、3…）', o.showNumbering,
                (v) => notifier.setOptions(o.copyWith(showNumbering: v))),
            sw('纸张日期', o.showDate,
                (v) => notifier.setOptions(o.copyWith(showDate: v))),
          ],
        ),
      ),
    );
  }
}

/// 导出卡片。
class _ExportCard extends ConsumerWidget {
  const _ExportCard({
    required this.st,
    required this.target,
    required this.quality,
    required this.onTarget,
    required this.onQuality,
    required this.onExport,
  });

  final PrintState st;
  final _ExportTarget target;
  final double quality;
  final ValueChanged<_ExportTarget> onTarget;
  final ValueChanged<double> onQuality;
  final VoidCallback onExport;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            SegmentedButton<_ExportTarget>(
              segments: const [
                ButtonSegment(
                    value: _ExportTarget.sheetJpg,
                    label: Text('排版图 JPG'),
                    icon: Icon(Icons.image, size: 16)),
                ButtonSegment(
                    value: _ExportTarget.sheetPng,
                    label: Text('排版图 PNG'),
                    icon: Icon(Icons.image_outlined, size: 16)),
                ButtonSegment(
                    value: _ExportTarget.pdf,
                    label: Text('PDF'),
                    icon: Icon(Icons.picture_as_pdf, size: 16)),
              ],
              selected: {target},
              onSelectionChanged: (s) => onTarget(s.first),
            ),
            if (target != _ExportTarget.pdf) ...[
              Row(
                children: [
                  const Text('质量'),
                  Expanded(
                    child: Slider(
                      value: quality,
                      min: 60,
                      max: 100,
                      divisions: 8,
                      label: '${quality.round()}',
                      onChanged: onQuality,
                    ),
                  ),
                  Text('${quality.round()}'),
                ],
              ),
            ] else
              Padding(
                padding: const EdgeInsets.only(top: 8),
                child: Text(
                  'PDF 为矢量排版（${st.paper.pixelWidth}×${st.paper.pixelHeight}px @300DPI），'
                  '适合打印与冲印。',
                  style: theme.textTheme.bodySmall,
                ),
              ),
            const SizedBox(height: 8),
            FilledButton.icon(
              onPressed: st.isExporting || st.layout == null ? null : onExport,
              icon: st.isExporting
                  ? const SizedBox(
                      width: 18,
                      height: 18,
                      child: CircularProgressIndicator(strokeWidth: 2),
                    )
                  : const Icon(Icons.print),
              label: Text(st.isExporting ? '导出中…' : '导出排版文件'),
            ),
          ],
        ),
      ),
    );
  }
}
