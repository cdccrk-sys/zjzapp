import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image/image.dart' as img;

import '../../domain/artifacts/artifact_store.dart';
import '../../domain/crop/crop_service.dart';
import '../../domain/export/export_service.dart';
import '../../domain/pipeline/photo_pipeline.dart';
import '../../state/artifact_state.dart';
import '../../state/correction_state.dart';
import '../../state/crop_state.dart';
import '../../state/enhance_state.dart';
import '../../state/export_state.dart';
import '../../state/import_state.dart';
import '../../state/selected_item_state.dart';
import '../../state/matting_state.dart';

/// 步骤 8「导出」：选择格式并导出已裁剪的证件照。
class ExportStep extends ConsumerStatefulWidget {
  const ExportStep({super.key});

  @override
  ConsumerState<ExportStep> createState() => _ExportStepState();
}

class _ExportStepState extends ConsumerState<ExportStep> {
  ExportFormat _format = ExportFormat.jpg;
  double _quality = 92;

  Future<void> _doExport() async {
    final items = ref.read(importStateProvider).items;
    final selectedId = ref.read(selectedItemIdProvider);
    final item = items.where((e) => e.id == selectedId).firstOrNull;
    if (item == null) return;
    final rect = ref.read(cropStateProvider).rects[item.id];
    final spec = ref.read(cropStateProvider).selectedSpec;
    final notifier = ref.read(exportStateProvider.notifier);
    await notifier.reset();

    final failures = <String>[];
    final decoded = img.decodeImage(
        independentInputFor(ref, item, ArtifactKind.enhanced));
    if (decoded == null) {
      failures.add(item.fileName);
    } else {
      // 透明底 PNG：直接用产物；否则若产物非 enhanced 时按当前参数再管线一次。
      final matting = ref.read(mattingStateProvider);
      final enhance = ref.read(enhanceStateProvider);
      final analyses = ref.read(correctionStateProvider).analyses;
      final processed = const PhotoPipeline().process(
        source: decoded,
        mattingMask: matting.masks[item.id],
        background: matting.selectedBackground,
        enhancement: enhance.params,
        dress: enhance.dress,
        face: analyses[item.id]?.primaryFace,
      );
      final source = rect != null
          ? const CropService().applyCrop(
              processed,
              rect,
              targetWidth: spec.pixelWidth,
              targetHeight: spec.pixelHeight,
            )
          : processed;
      try {
        final service = ref.read(exportServiceProvider);
        final results = await service.exportMany(
          [(source: source, rect: CropRect(x: 0, y: 0, width: source.width, height: source.height), spec: spec)],
          format: _format,
          jpgQuality: _quality.round(),
        );
        ref
            .read(exportStateProvider.notifier)
            .setResults(results, failures, DateTime.now());
      } catch (e) {
        failures.add('导出失败: $e');
        ref.read(exportStateProvider.notifier).setResults([], failures, null);
      }
    }
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final items = ref.watch(importStateProvider).items;
    final items2 = ref.watch(importStateProvider).items;
    final selId = ref.watch(selectedItemIdProvider);
    final selItem = items2.where((e) => e.id == selId).firstOrNull;
    final rectCount = selItem != null &&
            ref.watch(cropStateProvider).rects.containsKey(selItem.id)
        ? 1
        : 0;
    final st = ref.watch(exportStateProvider);

    if (items.isEmpty) {
      return Scaffold(
        appBar: AppBar(title: const Text('导出')),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.photo_library_outlined,
                  size: 56, color: theme.colorScheme.outline),
              const SizedBox(height: 12),
              const Text('还没有导入照片'),
              const SizedBox(height: 8),
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('返回'),
              ),
            ],
          ),
        ),
      );
    }

    return Scaffold(
      appBar: AppBar(title: const Text('导出')),
      body: ListView(
      padding: const EdgeInsets.all(16),
      children: [
        Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                Text('导出设置', style: theme.textTheme.titleSmall),
                const SizedBox(height: 12),
                SegmentedButton<ExportFormat>(
                  segments: const [
                    ButtonSegment(
                      value: ExportFormat.jpg,
                      label: Text('JPG'),
                      icon: Icon(Icons.image, size: 16),
                    ),
                    ButtonSegment(
                      value: ExportFormat.png,
                      label: Text('PNG'),
                      icon: Icon(Icons.image_outlined, size: 16),
                    ),
                    ButtonSegment(
                      value: ExportFormat.transparentPng,
                      label: Text('透明 PNG'),
                      icon: Icon(Icons.filter_none, size: 16),
                    ),
                  ],
                  selected: {_format},
                  onSelectionChanged: (s) => setState(() => _format = s.first),
                ),
                if (_format == ExportFormat.jpg) ...[
                  const SizedBox(height: 12),
                  Row(
                    children: [
                      const Text('质量'),
                      Expanded(
                        child: Slider(
                          value: _quality,
                          min: 60,
                          max: 100,
                          divisions: 8,
                          label: '${_quality.round()}',
                          onChanged: (v) => setState(() => _quality = v),
                        ),
                      ),
                      Text('${_quality.round()}'),
                    ],
                  ),
                ],
                const SizedBox(height: 12),
                Text(
                  '已就绪：$rectCount 张照片 · 规格 ${ref.watch(cropStateProvider).selectedSpec.name}'
                  ' · ${ref.watch(cropStateProvider).selectedSpec.pixelWidth}×'
                  '${ref.watch(cropStateProvider).selectedSpec.pixelHeight}px @300DPI',
                  style: theme.textTheme.bodySmall,
                ),
                const SizedBox(height: 16),
                FilledButton.icon(
                  onPressed: st.isExporting || rectCount == 0 ? null : _doExport,
                  icon: st.isExporting
                      ? const SizedBox(
                          width: 18,
                          height: 18,
                          child: CircularProgressIndicator(strokeWidth: 2),
                        )
                      : const Icon(Icons.save_alt),
                  label: Text(st.isExporting ? '导出中…' : '导出到相册目录'),
                ),
              ],
            ),
          ),
        ),
        const SizedBox(height: 12),
        if (st.failures.isNotEmpty) ...[
          Card(
            color: theme.colorScheme.errorContainer,
            child: Padding(
              padding: const EdgeInsets.all(12),
              child: Text(
                '失败：${st.failures.join('；')}',
                style: theme.textTheme.bodySmall?.copyWith(
                  color: theme.colorScheme.onErrorContainer,
                ),
              ),
            ),
          ),
          const SizedBox(height: 12),
        ],
        if (st.results.isNotEmpty) ...[
          Text('导出结果（${st.results.length}）', style: theme.textTheme.titleSmall),
          const SizedBox(height: 8),
          ...st.results.map((r) => Card(
                child: ListTile(
                  dense: true,
                  leading: const Icon(Icons.insert_drive_file_outlined),
                  title: Text(r.fileName, style: theme.textTheme.bodyMedium),
                  subtitle: Text(
                    '${r.width}×${r.height}px · ${_fmtSize(r.sizeBytes)} · ${r.path}',
                    style: theme.textTheme.bodySmall,
                  ),
                ),
              )),
          const SizedBox(height: 12),
          FilledButton.tonalIcon(
            onPressed: st.isExporting
                ? null
                : () => ref.read(exportStateProvider.notifier).shareAll(),
            icon: const Icon(Icons.share),
            label: const Text('分享导出文件'),
          ),
          const SizedBox(height: 8),
          Text(
            '文件保存在应用文档目录 exports/ 下，可通过分享发送到相册或微信。',
            style: theme.textTheme.bodySmall?.copyWith(
              color: theme.colorScheme.outline,
            ),
          ),
        ],
      ],
      ),
    );
  }

  static String _fmtSize(int bytes) {
    if (bytes < 1024) return '$bytes B';
    if (bytes < 1024 * 1024) return '${(bytes / 1024).toStringAsFixed(1)} KB';
    return '${(bytes / 1024 / 1024).toStringAsFixed(2)} MB';
  }
}
