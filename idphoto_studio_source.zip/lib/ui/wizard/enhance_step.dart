import 'dart:async';
import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image/image.dart' as img;

import '../../domain/dress/dress_service.dart';
import '../../domain/artifacts/artifact_store.dart';
import '../../domain/enhance/enhance_service.dart';
import '../../domain/face/face_models.dart';
import '../../domain/import/image_item.dart';
import '../../domain/matting/background.dart';
import '../../domain/pipeline/photo_pipeline.dart';
import '../../state/artifact_state.dart';
import '../../state/correction_state.dart';
import '../../state/enhance_state.dart';
import '../../state/import_state.dart';
import '../../state/matting_state.dart';
import '../../state/selected_item_state.dart';

/// 步骤 5「优化」：色彩预设/滑杆 + 换装（默认关闭）。
class EnhanceStep extends ConsumerStatefulWidget {
  const EnhanceStep({super.key});

  @override
  ConsumerState<EnhanceStep> createState() => _EnhanceStepState();
}

class _EnhanceStepState extends ConsumerState<EnhanceStep> {
  static const double _previewSide = 360;

  img.Image? _base;
  Uint8List? _previewBytes;
  String? _previewKey;
  String _previewSig = '';
  Timer? _debounce;

  @override
  void dispose() {
    _debounce?.cancel();
    super.dispose();
  }

  void _ensureBase(ImageItem item) {
    if (_base != null && _previewKey == item.id) return;
    final decoded = img.decodeImage(
        independentInputFor(ref, item, ArtifactKind.enhanced));
    if (decoded == null) return;
    _base = _downscale(decoded);
    _previewKey = item.id;
  }

  img.Image _downscale(img.Image src) {
    final side = math.max(src.width, src.height);
    if (side <= _previewSide) return src;
    final f = _previewSide / side;
    return img.copyResize(src,
        width: (src.width * f).round(),
        height: (src.height * f).round(),
        interpolation: img.Interpolation.linear);
  }

  Uint8List _downscaleMask(
    List<int> mask,
    int srcW,
    int srcH,
    int dstW,
    int dstH,
  ) {
    final out = Uint8List(dstW * dstH);
    for (var y = 0; y < dstH; y++) {
      for (var x = 0; x < dstW; x++) {
        final sx = (x * srcW / dstW).floor().clamp(0, srcW - 1);
        final sy = (y * srcH / dstH).floor().clamp(0, srcH - 1);
        out[y * dstW + x] = mask[sy * srcW + sx];
      }
    }
    return out;
  }

  /// 管线处理预览：debounce 300ms 后在 isolate 里跑。
  void _schedulePreview(ImageItem item, String sig) {
    _debounce?.cancel();
    _debounce = Timer(const Duration(milliseconds: 300), () async {
      if (!mounted) return;
      _ensureBase(item);
      final base = _base;
      if (base == null) return;
      final st = ref.read(enhanceStateProvider);
      final mask = ref.read(mattingStateProvider).masks[item.id];
      final bg = ref.read(mattingStateProvider).selectedBackground;
      final face = ref.read(correctionStateProvider).analyses[item.id]?.primaryFace;

      Uint8List? smallMask;
      if (mask != null) {
        final src = img.decodeImage(
            independentInputFor(ref, item, ArtifactKind.enhanced))!;
        final small = _downscale(src);
        smallMask = _downscaleMask(mask, src.width, src.height, small.width, small.height);
      }

      // 打包成 isolate 参数。
      final jpg = await compute(_renderInIsolate, (
        baseBytes: img.encodeJpg(base, quality: 85),
        mask: smallMask,
        bgColor: bg.color,
        bgType: bg.type.index,
        bgColorEnd: bg.colorEnd,
        params: st.params,
        dressIndex: st.dress.index,
        face: face,
      ));
      if (!mounted) return;
      setState(() => _previewBytes = Uint8List.fromList(jpg));
    });
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    ref.watch(enhanceStateProvider);
    ref.watch(mattingStateProvider);
    ref.watch(correctionStateProvider);

    final items = ref.watch(importStateProvider).items;
    final selId = ref.watch(selectedItemIdProvider);
    final item = items.where((e) => e.id == selId).firstOrNull;
    if (items.isEmpty || item == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('优化')),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.auto_fix_high, size: 56, color: theme.colorScheme.outline),
              const SizedBox(height: 12),
              const Text('请先导入照片'),
              TextButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('返回'),
              ),
            ],
          ),
        ),
      );
    }

    // 参数指纹：debounce 后在 isolate 里重算预览。
    final p = ref.watch(enhanceStateProvider).params;
    final sig = [
      item.id,
      p.whiteBalance,
      p.brightness,
      p.contrast,
      p.saturation,
      p.warmth,
      p.sharpen,
      p.smooth,
      p.denoise,
      ref.read(enhanceStateProvider).dress.name,
    ].join('|');
    if (_previewSig != sig) {
      _previewSig = sig;
      _schedulePreview(item, sig);
    }
    final preview = _previewBytes ?? Uint8List(0);

    return Scaffold(
      appBar: AppBar(title: const Text('优化')),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Center(
            child: ClipRRect(
              borderRadius: BorderRadius.circular(10),
              child: preview.isEmpty
                  ? const SizedBox(height: 300)
                  : ConstrainedBox(
                      constraints: const BoxConstraints(maxHeight: 420),
                      child: Image.memory(preview,
                          fit: BoxFit.contain, gaplessPlayback: true),
                    ),
            ),
          ),
          const SizedBox(height: 4),
          Text(
            '预览为实时效果，导出时自动应用',
            style: theme.textTheme.bodySmall
                ?.copyWith(color: theme.colorScheme.outline),
            textAlign: TextAlign.center,
          ),
          const SizedBox(height: 12),
          const _PresetSelector(),
          const SizedBox(height: 8),
          const _SliderPanel(),
          const SizedBox(height: 8),
          const _DressPanel(),
          const SizedBox(height: 16),
          const SizedBox(height: 8),
          _SaveButton(item: item),
        ],
      ),
    );
  }
}

class _PresetSelector extends ConsumerWidget {
  const _PresetSelector();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final preset = ref.watch(enhanceStateProvider).preset;
    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('色彩预设', style: theme.textTheme.titleSmall),
        const SizedBox(height: 6),
        Wrap(
          spacing: 6,
          runSpacing: 6,
          children: [
            for (final p in EnhancementPreset.values)
              ChoiceChip(
                label: Text(p.label),
                selected: preset == p,
                onSelected: (_) =>
                    ref.read(enhanceStateProvider.notifier).setPreset(p),
                showCheckmark: false,
                visualDensity: VisualDensity.compact,
              ),
          ],
        ),
      ],
    );
  }
}

class _SliderPanel extends ConsumerWidget {
  const _SliderPanel();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final p = ref.watch(enhanceStateProvider).params;
    final n = ref.read(enhanceStateProvider.notifier);

    Widget slider({
      required String label,
      required double value,
      required double min,
      required double max,
      required String Function(double) fmt,
      required ValueChanged<double> onChanged,
    }) {
      return Row(
        children: [
          SizedBox(width: 64, child: Text(label, style: theme.textTheme.bodySmall)),
          Expanded(
            child: Slider(
              value: value,
              min: min,
              max: max,
              divisions: 20,
              label: fmt(value),
              onChanged: onChanged,
            ),
          ),
          SizedBox(width: 40, child: Text(fmt(value), textAlign: TextAlign.right)),
        ],
      );
    }

    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
        child: Column(
          children: [
            Row(
              children: [
                const Text('自动白平衡'),
                Switch(
                  value: p.whiteBalance,
                  onChanged: n.setWhiteBalance,
                ),
              ],
            ),
            slider(
              label: '亮度',
              value: p.brightness.toDouble(),
              min: -60,
              max: 60,
              fmt: (v) => v.round().toString(),
              onChanged: (v) => n.setBrightness(v.round()),
            ),
            slider(
              label: '对比度',
              value: p.contrast,
              min: 0.6,
              max: 1.5,
              fmt: (v) => v.toStringAsFixed(2),
              onChanged: n.setContrast,
            ),
            slider(
              label: '饱和度',
              value: p.saturation,
              min: 0.5,
              max: 1.8,
              fmt: (v) => v.toStringAsFixed(2),
              onChanged: n.setSaturation,
            ),
            slider(
              label: '色温',
              value: p.warmth.toDouble(),
              min: -60,
              max: 60,
              fmt: (v) => v.round().toString(),
              onChanged: (v) => n.setWarmth(v.round()),
            ),
            slider(
              label: '锐化',
              value: p.sharpen,
              min: 0,
              max: 100,
              fmt: (v) => v.round().toString(),
              onChanged: n.setSharpen,
            ),
            slider(
              label: '磨皮',
              value: p.smooth,
              min: 0,
              max: 100,
              fmt: (v) => v.round().toString(),
              onChanged: n.setSmooth,
            ),
            slider(
              label: '降噪',
              value: p.denoise,
              min: 0,
              max: 100,
              fmt: (v) => v.round().toString(),
              onChanged: n.setDenoise,
            ),
          ],
        ),
      ),
    );
  }
}

class _DressPanel extends ConsumerWidget {
  const _DressPanel();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final dress = ref.watch(enhanceStateProvider).dress;
    final notifier = ref.read(enhanceStateProvider.notifier);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Text('正装模板', style: theme.textTheme.titleSmall),
                const Spacer(),
                Text(
                  dress == DressTemplate.none ? '已关闭' : '已开启',
                  style: theme.textTheme.bodySmall?.copyWith(
                    color: dress == DressTemplate.none
                        ? theme.colorScheme.outline
                        : theme.colorScheme.primary,
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text(
              '贴图式换装（不改变五官），默认关闭；效果取决于原图姿态，不满意可关闭。',
              style: theme.textTheme.bodySmall?.copyWith(
                color: theme.colorScheme.outline,
              ),
            ),
            const SizedBox(height: 8),
            Wrap(
              spacing: 6,
              runSpacing: 6,
              children: [
                for (final t in DressTemplate.values)
                  ChoiceChip(
                    label: Text(t.label),
                    selected: dress == t,
                    onSelected: (_) => notifier.setDress(t),
                    showCheckmark: false,
                    visualDensity: VisualDensity.compact,
                  ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}


/// isolate 顶层函数：接收预览图 JPG bytes + 管线参数，返回处理后 JPG bytes。
List<int> _renderInIsolate(({
  List<int> baseBytes,
  List<int>? mask,
  int bgColor,
  int bgType,
  int? bgColorEnd,
  EnhancementParams params,
  int dressIndex,
  FaceInfo? face,
}) args) {
  final base = img.decodeImage(Uint8List.fromList(args.baseBytes));
  if (base == null) return args.baseBytes;
  final bg = PhotoBackground(
    type: PhotoBackgroundType.values[args.bgType],
    color: args.bgColor,
    colorEnd: args.bgColorEnd,
  );
  final processed = const PhotoPipeline().process(
    source: base,
    mattingMask: args.mask == null ? null : Uint8List.fromList(args.mask!),
    background: bg,
    enhancement: args.params,
    dress: DressTemplate.values[args.dressIndex],
    face: args.face,
  );
  return img.encodeJpg(processed, quality: 80);
}


/// 确定并保存：读裁剪产物 → 管线（换底+换装+优化）→ 存 enhanced。
class _SaveButton extends ConsumerWidget {
  const _SaveButton({required this.item});

  final ImageItem item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FilledButton.icon(
      onPressed: () async {
        final bytes = await _renderFull(ref);
        if (bytes == null) {
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('保存失败，请重试')),
            );
          }
          return;
        }
        await ref
            .read(artifactStateProvider.notifier)
            .save(item.id, ArtifactKind.enhanced, bytes);
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('已保存优化结果')),
          );
          Navigator.of(context).pop();
        }
      },
      icon: const Icon(Icons.check),
      label: const Text('确定并保存'),
    );
  }

  Future<Uint8List?> _renderFull(WidgetRef ref) async {
    final st = ref.read(enhanceStateProvider);
    final decoded = img.decodeImage(
        independentInputFor(ref, item, ArtifactKind.enhanced));
    if (decoded == null) return null;
    final mask = ref.read(mattingStateProvider).masks[item.id];
    final bg = ref.read(mattingStateProvider).selectedBackground;
    final face =
        ref.read(correctionStateProvider).analyses[item.id]?.primaryFace;
    final processed = const PhotoPipeline().process(
      source: decoded,
      mattingMask: mask,
      background: bg,
      enhancement: st.params,
      dress: st.dress,
      face: face,
    );
    return Uint8List.fromList(img.encodeJpg(processed, quality: 92));
  }
}
