import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../state/import_state.dart';
import '../settings/settings_page.dart';
import 'correction_step.dart';
import 'crop_step.dart';
import 'enhance_step.dart';
import 'export_step.dart';
import 'import_step.dart';
import 'matting_step.dart';
import 'print_step.dart';
import 'step_placeholder.dart';

/// 8 步向导框架：顶部步骤条 + 步骤内容。
///
/// M1 已实现：步骤 0「导入」。
/// 其余步骤为占位页，将在后续里程碑逐个落地。
class WizardPage extends ConsumerWidget {
  const WizardPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final currentStep = ref.watch(wizardStepProvider);
    final theme = Theme.of(context);

    return Scaffold(
      appBar: AppBar(
        title: const Text('证件照工坊'),
        actions: [
          Padding(
            padding: const EdgeInsets.only(right: 4),
            child: Center(
              child: Text(
                '第 ${currentStep + 1} / 8 步 · ${kWizardSteps[currentStep]}',
                style: theme.textTheme.bodySmall,
              ),
            ),
          ),
          IconButton(
            tooltip: '设置与帮助',
            icon: const Icon(Icons.settings_outlined),
            onPressed: () => Navigator.of(context).push(
              MaterialPageRoute(builder: (_) => const SettingsPage()),
            ),
          ),
          const SizedBox(width: 4),
        ],
      ),
      body: Column(
        children: [
          _StepIndicator(currentStep: currentStep),
          const Divider(height: 1),
          Expanded(child: _buildStepBody(currentStep)),
        ],
      ),
    );
  }

  Widget _buildStepBody(int step) {
    switch (step) {
      case 0:
        return const ImportStep();
      case 1:
        return const CorrectionStep();
      case 2:
        return const MattingStep();
      case 4:
        return const CropStep();
      case 5:
        return const EnhanceStep();
      case 6:
        return const PrintStep();
      case 7:
        return const ExportStep();
      default:
        return StepPlaceholder(
          stepIndex: step,
          stepName: kWizardSteps[step],
        );
    }
  }
}

/// 顶部步骤条（可点击跳转；未实现步骤点击后仅提示占位）。
class _StepIndicator extends ConsumerWidget {
  const _StepIndicator({required this.currentStep});

  final int currentStep;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return SizedBox(
      height: 44,
      child: ListView.separated(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
        scrollDirection: Axis.horizontal,
        itemCount: kWizardSteps.length,
        separatorBuilder: (_, __) => const SizedBox(width: 2),
        itemBuilder: (context, index) {
          final active = index == currentStep;
          final done = index < currentStep;
          final theme = Theme.of(context);
          return InkWell(
            borderRadius: BorderRadius.circular(8),
            onTap: () => ref.read(wizardStepProvider.notifier).state = index,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 10),
              alignment: Alignment.center,
              decoration: BoxDecoration(
                color: active
                    ? theme.colorScheme.primary
                    : done
                        ? theme.colorScheme.primaryContainer
                        : theme.colorScheme.surfaceContainerHighest,
                borderRadius: BorderRadius.circular(8),
              ),
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: [
                  Icon(
                    done ? Icons.check : Icons.circle,
                    size: 10,
                    color: active
                        ? theme.colorScheme.onPrimary
                        : theme.colorScheme.onSurfaceVariant,
                  ),
                  const SizedBox(width: 4),
                  Text(
                    '${index + 1}.${kWizardSteps[index]}',
                    style: theme.textTheme.labelSmall?.copyWith(
                      color: active
                          ? theme.colorScheme.onPrimary
                          : theme.colorScheme.onSurfaceVariant,
                    ),
                  ),
                ],
              ),
            ),
          );
        },
      ),
    );
  }
}
