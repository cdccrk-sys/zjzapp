import 'dart:io';
import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image/image.dart' as img;

import '../../domain/artifacts/artifact_store.dart';
import '../../domain/import/image_item.dart';
import '../../domain/matting/background.dart';
import '../../state/artifact_state.dart';
import '../../state/import_state.dart';
import '../../state/matting_state.dart';
import '../../state/selected_item_state.dart';

/// 独立功能「换背景」：读取抠图产物（透明底 PNG），
/// 选择白/蓝/红/灰/浅蓝/渐变/自定义底色并合成，保存为 background 产物。
class BackgroundStep extends ConsumerStatefulWidget {
  const BackgroundStep({super.key});

  @override
  ConsumerState<BackgroundStep> createState() => _BackgroundStepState();
}

class _BackgroundStepState extends ConsumerState<BackgroundStep> {
  bool _showResult = true;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final items = ref.watch(importStateProvider).items;
    final selectedId = ref.watch(selectedItemIdProvider);
    final selected = items.where((e) => e.id == selectedId).firstOrNull;

    if (selected == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('换背景')),
        body: Center(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              Icon(Icons.wallpaper,
                  size: 56, color: theme.colorScheme.outline),
              const SizedBox(height: 12),
              const Text('请先导入照片'),
              const SizedBox(height: 8),
              FilledButton(
                onPressed: () => Navigator.of(context).pop(),
                child: const Text('返回'),
              ),
            ],
          ),
        ),
      );
    }

    final hasMatting = ref.read(artifactStateProvider).has(
          selected.id,
          ArtifactKind.matting,
        );

    return Scaffold(
      appBar: AppBar(title: const Text('换背景')),
      body: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: [
          Expanded(
            child: ListView(
              padding: const EdgeInsets.all(16),
              children: [
                Card(
                  color: theme.colorScheme.surfaceContainerHighest,
                  child: Padding(
                    padding: const EdgeInsets.all(12),
                    child: Text(
                      hasMatting
                          ? '已读取透明底抠图结果，选择底色后点「确定并保存」。'
                          : '未做抠图时自动替换近似背景色；先抠图可获得更精细的换底效果。',
                      style: theme.textTheme.bodySmall?.copyWith(
                        color: theme.colorScheme.onSurfaceVariant,
                      ),
                    ),
                  ),
                ),
                const SizedBox(height: 12),
                _BackgroundPreview(
                  item: selected,
                  showResult: _showResult,
                  onToggle: (v) => setState(() => _showResult = v),
                  background: ref.watch(mattingStateProvider)
                      .selectedBackground,
                ),
                const SizedBox(height: 12),
                const _BackgroundSelector(),
                const SizedBox(height: 16),
                _SaveButton(item: selected),
              ],
            ),
          ),
        ],
      ),
    );
  }
}

/// 背景合成预览。
class _BackgroundPreview extends ConsumerStatefulWidget {
  const _BackgroundPreview({
    required this.item,
    required this.showResult,
    required this.onToggle,
    required this.background,
  });

  final ImageItem item;
  final bool showResult;
  final ValueChanged<bool> onToggle;
  final PhotoBackground background;

  @override
  ConsumerState<_BackgroundPreview> createState() => _BackgroundPreviewState();
}

class _BackgroundPreviewState extends ConsumerState<_BackgroundPreview> {
  static const double _maxSide = 480;

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          children: [
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                Text('原图', style: theme.textTheme.labelSmall),
                Switch(
                  value: widget.showResult,
                  onChanged: widget.onToggle,
                ),
                Text('换底结果', style: theme.textTheme.labelSmall),
              ],
            ),
            const SizedBox(height: 8),
            FutureBuilder<Uint8List?>(
              future: _render(),
              builder: (context, snap) {
                if (snap.connectionState != ConnectionState.done) {
                  return const SizedBox(
                    height: 200,
                    child: Center(child: CircularProgressIndicator()),
                  );
                }
                final bytes = snap.data;
                if (bytes == null || bytes.isEmpty) {
                  return SizedBox(
                    height: 200,
                    child: Center(
                      child: Text(
                        '预览生成失败',
                        style: theme.textTheme.bodySmall,
                      ),
                    ),
                  );
                }
                return ClipRRect(
                  borderRadius: BorderRadius.circular(10),
                  child: AspectRatio(
                    aspectRatio: 3 / 4,
                    child: Image.memory(
                      bytes,
                      fit: BoxFit.contain,
                      gaplessPlayback: true,
                    ),
                  ),
                );
              },
            ),
          ],
        ),
      ),
    );
  }

  Future<Uint8List?> _render() async {
    // 独立功能输入：上次换背景结果 → 最近产物（透明抠图等）→ 原图。
    final input =
        independentInputFor(ref, widget.item, ArtifactKind.background);
    final decoded = img.decodeImage(input);
    if (decoded == null) return null;

    if (!widget.showResult) {
      return _encode(decoded, _toJpg(decoded));
    }
    final background = widget.background;

    final side = math.max(decoded.width, decoded.height);
    final factor = side > _maxSide ? _maxSide / side : 1.0;
    final small = factor < 1.0
        ? img.copyResize(decoded,
            width: (decoded.width * factor).round(),
            height: (decoded.height * factor).round(),
            interpolation: img.Interpolation.linear)
        : decoded;

    final composed = _composeOn(small, background);
    return _encode(composed, _toJpg(composed));
  }

  img.Image _composeOn(img.Image src, PhotoBackground bg) {
    final out = img.Image(
        width: src.width, height: src.height, numChannels: 3);
    for (var y = 0; y < src.height; y++) {
      for (var x = 0; x < src.width; x++) {
        final p = src.getPixel(x, y);
        final a = p.a.toInt();
        final fa = a / 255.0;
        final c = _bgColorAt(bg, x, y, src.width, src.height);
        out.setPixelRgb(
          x,
          y,
          (p.r * fa + c.r * (1 - fa)).round().clamp(0, 255),
          (p.g * fa + c.g * (1 - fa)).round().clamp(0, 255),
          (p.b * fa + c.b * (1 - fa)).round().clamp(0, 255),
        );
      }
    }
    return out;
  }

  ({int r, int g, int b}) _bgColorAt(
    PhotoBackground bg,
    int x,
    int y,
    int w,
    int h,
  ) {
    if (bg.type == PhotoBackgroundType.image && bg.imageBytes != null) {
      final decoded = img.decodeImage(bg.imageBytes!);
      if (decoded != null) {
        final p = decoded.getPixel(
          (x * decoded.width / w).floor().clamp(0, decoded.width - 1),
          (y * decoded.height / h).floor().clamp(0, decoded.height - 1),
        );
        return (r: p.r.toInt(), g: p.g.toInt(), b: p.b.toInt());
      }
    }
    if (bg.type == PhotoBackgroundType.gradient) {
      final t = bg.direction == GradientDirection.topToBottom
          ? (h <= 1 ? 0.0 : y / (h - 1))
          : (w <= 1 ? 0.0 : x / (w - 1));
      final c0 = _rgb(bg.color);
      final c1 = _rgb(bg.colorEnd ?? bg.color);
      return (
        r: (c0.r + (c1.r - c0.r) * t).round().clamp(0, 255),
        g: (c0.g + (c1.g - c0.g) * t).round().clamp(0, 255),
        b: (c0.b + (c1.b - c0.b) * t).round().clamp(0, 255),
      );
    }
    return _rgb(bg.color);
  }

  ({int r, int g, int b}) _rgb(int argb) => (
        r: (argb >> 16) & 0xFF,
        g: (argb >> 8) & 0xFF,
        b: argb & 0xFF,
      );

  img.Image _toJpg(img.Image src) {
    if (src.numChannels == 4) {
      // 去 alpha 以便 JPG 编码。
      final out = img.Image(width: src.width, height: src.height, numChannels: 3);
      for (var y = 0; y < src.height; y++) {
        for (var x = 0; x < src.width; x++) {
          final p = src.getPixel(x, y);
          out.setPixelRgb(x, y, p.r.toInt(), p.g.toInt(), p.b.toInt());
        }
      }
      return out;
    }
    return src;
  }

  Uint8List _encode(img.Image image, img.Image forJpg) {
    final bytes = img.encodeJpg(forJpg, quality: 85);
    return Uint8List.fromList(bytes);
  }
}

/// 背景选择器（纯色/渐变/自定义图片）。
class _BackgroundSelector extends ConsumerWidget {
  const _BackgroundSelector();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final selected = ref.watch(mattingStateProvider).selectedBackground;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('背景', style: theme.textTheme.titleSmall),
        const SizedBox(height: 8),
        SizedBox(
          height: 64,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: PhotoBackground.presets.length + 2,
            separatorBuilder: (_, __) => const SizedBox(width: 8),
            itemBuilder: (context, index) {
              if (index == PhotoBackground.presets.length) {
                // 自定义图片。
                return InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => _pickImageBackground(context, ref),
                  child: Container(
                    width: 64,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: selected.type == PhotoBackgroundType.image
                            ? theme.colorScheme.primary
                            : theme.colorScheme.outlineVariant,
                        width: selected.type == PhotoBackgroundType.image
                            ? 2.5
                            : 1,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.image_outlined,
                            size: 20, color: theme.colorScheme.primary),
                        Text('图片', style: theme.textTheme.labelSmall),
                      ],
                    ),
                  ),
                );
              }
              if (index == PhotoBackground.presets.length + 1) {
                // 透明底。
                final active = selected.isTransparent;
                return InkWell(
                  borderRadius: BorderRadius.circular(8),
                  onTap: () => ref
                      .read(mattingStateProvider.notifier)
                      .setBackground(PhotoBackground.transparent),
                  child: Container(
                    width: 64,
                    decoration: BoxDecoration(
                      color: theme.colorScheme.surfaceContainerHighest,
                      borderRadius: BorderRadius.circular(8),
                      border: Border.all(
                        color: active
                            ? theme.colorScheme.primary
                            : theme.colorScheme.outlineVariant,
                        width: active ? 2.5 : 1,
                      ),
                    ),
                    child: Column(
                      mainAxisAlignment: MainAxisAlignment.center,
                      children: [
                        Icon(Icons.opacity,
                            size: 20, color: theme.colorScheme.primary),
                        Text('透明', style: theme.textTheme.labelSmall),
                      ],
                    ),
                  ),
                );
              }
              final bg = PhotoBackground.presets[index];
              final active = bg == selected;
              return InkWell(
                borderRadius: BorderRadius.circular(8),
                onTap: () =>
                    ref.read(mattingStateProvider.notifier).setBackground(bg),
                child: Container(
                  width: 64,
                  decoration: BoxDecoration(
                    color: bg.type == PhotoBackgroundType.gradient
                        ? null
                        : Color(bg.color),
                    gradient: bg.type == PhotoBackgroundType.gradient
                        ? LinearGradient(
                            begin: Alignment.topCenter,
                            end: Alignment.bottomCenter,
                            colors: [
                              Color(bg.color),
                              Color(bg.colorEnd ?? bg.color),
                            ],
                          )
                        : null,
                    borderRadius: BorderRadius.circular(8),
                    border: Border.all(
                      color: active
                          ? theme.colorScheme.primary
                          : theme.colorScheme.outlineVariant,
                      width: active ? 2.5 : 1,
                    ),
                  ),
                  child: Center(
                    child: Text(
                      bg.label,
                      style: theme.textTheme.labelSmall?.copyWith(
                        color: bg.type == PhotoBackgroundType.solid &&
                                bg.color == 0xFFFFFFFF
                            ? Colors.black54
                            : Colors.white,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                  ),
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}

Future<void> _pickImageBackground(BuildContext context, WidgetRef ref) async {
  final paths = await ref.read(importPickerProvider).pickImages();
  if (paths.isEmpty) return;
  try {
    final bytes = await File(paths.first).readAsBytes();
    final decoded = img.decodeImage(bytes);
    if (decoded == null) {
      if (context.mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('无法解析该图片，请换一张')),
        );
      }
      return;
    }
    ref
        .read(mattingStateProvider.notifier)
        .setBackground(PhotoBackground.fromImage(bytes));
  } catch (_) {
    if (context.mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('读取图片失败')),
      );
    }
  }
}

class _SaveButton extends ConsumerWidget {
  const _SaveButton({required this.item});

  final ImageItem item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return FilledButton.icon(
      onPressed: () async {
        final bytes = await _renderFull(context, ref, item);
        if (bytes == null) {
          if (context.mounted) {
            ScaffoldMessenger.of(context).showSnackBar(
              const SnackBar(content: Text('保存失败，请重试')),
            );
          }
          return;
        }
        await ref
            .read(artifactStateProvider.notifier)
            .save(item.id, ArtifactKind.background, bytes);
        if (context.mounted) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('已保存换背景结果')),
          );
          Navigator.of(context).pop();
        }
      },
      icon: const Icon(Icons.check),
      label: const Text('确定并保存'),
    );
  }

  /// 用原尺寸渲染合成结果（JPG）。
  Future<Uint8List?> _renderFull(
    BuildContext context,
    WidgetRef ref,
    ImageItem item,
  ) async {
    // 独立功能输入：上次换背景结果 → 最近产物（透明抠图等）→ 原图。
    final input = independentInputFor(ref, item, ArtifactKind.background);
    final decoded = img.decodeImage(input);
    if (decoded == null) return null;
    final bg = ref.read(mattingStateProvider).selectedBackground;
    if (bg.isTransparent) {
      // 透明底：原样保存 PNG。
      return Uint8List.fromList(img.encodePng(decoded));
    }
    final img.Image out;
    if (decoded.hasAlpha) {
      // 透明底：按 alpha 合成背景色。
      out = img.Image(
          width: decoded.width, height: decoded.height, numChannels: 3);
      for (var y = 0; y < decoded.height; y++) {
        for (var x = 0; x < decoded.width; x++) {
          final p = decoded.getPixel(x, y);
          final a = p.a.toInt();
          final fa = a / 255.0;
          final c = _bgColorAt(decoded, bg, x, y);
          out.setPixelRgb(
            x,
            y,
            (p.r * fa + c.r * (1 - fa)).round().clamp(0, 255),
            (p.g * fa + c.g * (1 - fa)).round().clamp(0, 255),
            (p.b * fa + c.b * (1 - fa)).round().clamp(0, 255),
          );
        }
      }
    } else {
      // 无透明底：替换与边缘近似的背景色（近似色抠图）。
      out = _replaceNearBackground(decoded, bg);
    }
    return Uint8List.fromList(img.encodeJpg(out, quality: 92));
  }

  /// 无透明底时的近似背景色替换：取四角平均色为背景基准，
  /// 与基准颜色接近的像素替换为目标背景色，其余保留原图。
  img.Image _replaceNearBackground(img.Image src, PhotoBackground bg) {
    final w = src.width, h = src.height;
    final corners = [
      src.getPixel(0, 0),
      src.getPixel(w - 1, 0),
      src.getPixel(0, h - 1),
      src.getPixel(w - 1, h - 1),
    ];
    var sr = 0, sg = 0, sb = 0;
    for (final c in corners) {
      sr += c.r.toInt();
      sg += c.g.toInt();
      sb += c.b.toInt();
    }
    final baseR = sr ~/ 4, baseG = sg ~/ 4, baseB = sb ~/ 4;
    final out = img.Image(width: w, height: h, numChannels: 3);
    const th = 46.0;
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final p = src.getPixel(x, y);
        final dr = p.r.toInt() - baseR;
        final dg = p.g.toInt() - baseG;
        final db = p.b.toInt() - baseB;
        if (dr * dr + dg * dg + db * db > th * th * 3) {
          out.setPixelRgb(x, y, p.r.toInt(), p.g.toInt(), p.b.toInt());
        } else {
          final c = _bgColorAt(src, bg, x, y);
          out.setPixelRgb(x, y, c.r, c.g, c.b);
        }
      }
    }
    return out;
  }

  ({int r, int g, int b}) _bgColorAt(
    img.Image src,
    PhotoBackground bg,
    int x,
    int y,
  ) {
    if (bg.type == PhotoBackgroundType.image && bg.imageBytes != null) {
      final decoded = img.decodeImage(bg.imageBytes!);
      if (decoded != null) {
        final p = decoded.getPixel(
          (x * decoded.width / src.width).floor().clamp(0, decoded.width - 1),
          (y * decoded.height / src.height)
              .floor()
              .clamp(0, decoded.height - 1),
        );
        return (r: p.r.toInt(), g: p.g.toInt(), b: p.b.toInt());
      }
    }
    if (bg.type == PhotoBackgroundType.gradient) {
      final t = bg.direction == GradientDirection.topToBottom
          ? (src.height <= 1 ? 0.0 : y / (src.height - 1))
          : (src.width <= 1 ? 0.0 : x / (src.width - 1));
      final c0 = _rgb(bg.color);
      final c1 = _rgb(bg.colorEnd ?? bg.color);
      return (
        r: (c0.r + (c1.r - c0.r) * t).round().clamp(0, 255),
        g: (c0.g + (c1.g - c0.g) * t).round().clamp(0, 255),
        b: (c0.b + (c1.b - c0.b) * t).round().clamp(0, 255),
      );
    }
    return _rgb(bg.color);
  }

  ({int r, int g, int b}) _rgb(int argb) => (
        r: (argb >> 16) & 0xFF,
        g: (argb >> 8) & 0xFF,
        b: argb & 0xFF,
      );
}
