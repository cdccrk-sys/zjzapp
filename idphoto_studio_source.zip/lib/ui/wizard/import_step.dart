import 'dart:io' show Platform;

import 'package:desktop_drop/desktop_drop.dart';
import 'package:flutter/foundation.dart';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/artifacts/artifact_store.dart';
import '../../domain/import/image_item.dart';
import '../../state/artifact_state.dart';
import '../../state/import_state.dart';
import '../../state/selected_item_state.dart';

/// 步骤 1「导入」：拖拽 / 选择文件 / 选择文件夹 / 批量导入。
class ImportStep extends ConsumerWidget {
  const ImportStep({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final state = ref.watch(importStateProvider);
    final isDesktop =
        !kIsWeb &&
            !Platform.environment.containsKey('FLUTTER_TEST') &&
            (Platform.isWindows || Platform.isLinux || Platform.isMacOS);

    final content = Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Expanded(
          child: ListView(
            padding: const EdgeInsets.all(16),
            children: [
              _buildImportActions(context, ref, isDesktop),
              const SizedBox(height: 16),
              if (state.failures.isNotEmpty) _buildFailures(context, state),
              if (state.isLoading)
                const Padding(
                  padding: EdgeInsets.all(24),
                  child: Center(child: CircularProgressIndicator()),
                ),
              if (!state.isLoading && state.items.isEmpty)
                _buildEmptyHint(context),
              if (state.items.isNotEmpty)
                _buildPhotoGrid(context, ref, state.items),
            ],
          ),
        ),
        if (state.items.isNotEmpty)
          SafeArea(
            top: false,
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 8, 16, 12),
              child: Row(
                children: [
                  Text(
                    '已导入 ${state.items.length} 张',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                  const Spacer(),
                  TextButton(
                    onPressed: () => ref.read(importStateProvider.notifier).clear(),
                    child: const Text('清空'),
                  ),
                  const SizedBox(width: 8),
                  FilledButton.icon(
                    onPressed: state.items.isEmpty
                        ? null
                        : () async {
                            final artNotifier =
                                ref.read(artifactStateProvider.notifier);
                            final importNotifier =
                                ref.read(importStateProvider.notifier);
                            // 单张模式：先移除旧照片（本页之外的历史照片及其产物）。
                            final importedIds =
                                state.items.map((e) => e.id).toSet();
                            for (final old
                                in ref.read(importStateProvider).items) {
                              if (!importedIds.contains(old.id)) {
                                await artNotifier.clear(old.id);
                                importNotifier.removeItem(old.id);
                              }
                            }
                            for (final item in state.items) {
                              await artNotifier.save(
                                item.id,
                                ArtifactKind.original,
                                item.workingBytes,
                              );
                            }
                            if (state.items.isNotEmpty) {
                              ref.read(selectedItemIdProvider.notifier).state =
                                  state.items.first.id;
                            }
                            if (context.mounted &&
                                Navigator.of(context).canPop()) {
                              Navigator.of(context).pop();
                            }
                          },
                    icon: const Icon(Icons.check),
                    label: const Text('确定并保存'),
                  ),
                ],
              ),
            ),
          ),
      ],
    );

    final scaffold = Scaffold(
      appBar: AppBar(title: const Text('导入')),
      body: content,
    );

    // Windows 等桌面平台支持拖拽导入；移动端跳过。
    if (isDesktop) {
      return DropTarget(
        onDragDone: (details) {
          ref
              .read(importStateProvider.notifier)
              .importFiles(details.files.map((f) => f.path).toList());
        },
        child: scaffold,
      );
    }
    return scaffold;
  }

  Widget _buildImportActions(BuildContext context, WidgetRef ref, bool isDesktop) {
    final notifier = ref.read(importStateProvider.notifier);
    final theme = Theme.of(context);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            Icon(Icons.photo_library_outlined, size: 44, color: theme.colorScheme.primary),
            const SizedBox(height: 8),
            Text(
              isDesktop ? '拖拽单张照片到此处，或点击下方按钮导入' : '从相册选择单张照片导入',
              style: theme.textTheme.bodyMedium,
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 6),
            Text(
              '支持 JPG / PNG / WEBP / HEIC · 自动读取 EXIF 矫正方向 · 全部本地处理',
              style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 16),
            Wrap(
              spacing: 12,
              runSpacing: 8,
              alignment: WrapAlignment.center,
              children: [
                FilledButton.icon(
                  onPressed: () => notifier.pickAndImport(),
                  icon: const Icon(Icons.add_photo_alternate_outlined),
                  label: const Text('选择照片'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildEmptyHint(BuildContext context) {
    final theme = Theme.of(context);
    return Padding(
      padding: const EdgeInsets.symmetric(vertical: 32),
      child: Column(
        children: [
          Icon(Icons.image_outlined, size: 40, color: theme.colorScheme.outline),
          const SizedBox(height: 8),
          Text(
            '暂无照片，导入后将显示在这里',
            style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline),
          ),
        ],
      ),
    );
  }

  Widget _buildFailures(BuildContext context, ImportState state) {
    final theme = Theme.of(context);
    return Card(
      color: theme.colorScheme.errorContainer,
      child: Padding(
        padding: const EdgeInsets.all(12),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(
              '${state.failures.length} 张导入失败',
              style: theme.textTheme.titleSmall
                  ?.copyWith(color: theme.colorScheme.onErrorContainer),
            ),
            const SizedBox(height: 6),
            for (final f in state.failures)
              Padding(
                padding: const EdgeInsets.only(bottom: 4),
                child: Text(
                  '${f.fileName}：${f.message}',
                  style: theme.textTheme.bodySmall
                      ?.copyWith(color: theme.colorScheme.onErrorContainer),
                ),
              ),
          ],
        ),
      ),
    );
  }

  Widget _buildPhotoGrid(BuildContext context, WidgetRef ref, List<ImageItem> items) {
    return GridView.builder(
      shrinkWrap: true,
      physics: const NeverScrollableScrollPhysics(),
      gridDelegate: const SliverGridDelegateWithMaxCrossAxisExtent(
        maxCrossAxisExtent: 140,
        mainAxisSpacing: 8,
        crossAxisSpacing: 8,
      ),
      itemCount: items.length,
      itemBuilder: (context, index) {
        final item = items[index];
        return _PhotoTile(item: item);
      },
    );
  }
}

class _PhotoTile extends ConsumerWidget {
  const _PhotoTile({required this.item});

  final ImageItem item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    return Card(
      clipBehavior: Clip.antiAlias,
      child: Stack(
        fit: StackFit.expand,
        children: [
          Image.memory(
            item.thumbnailBytes,
            fit: BoxFit.cover,
            gaplessPlayback: true,
          ),
          Positioned(
            left: 4,
            bottom: 4,
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 5, vertical: 2),
              decoration: BoxDecoration(
                color: Colors.black54,
                borderRadius: BorderRadius.circular(4),
              ),
              child: Text(
                item.exifCorrected ? '${item.fileName} · 已矫正' : item.fileName,
                overflow: TextOverflow.ellipsis,
                style: theme.textTheme.labelSmall?.copyWith(color: Colors.white),
              ),
            ),
          ),
          Positioned(
            right: 2,
            top: 2,
            child: IconButton(
              visualDensity: VisualDensity.compact,
              icon: const Icon(Icons.close, size: 16, color: Colors.white),
              onPressed: () =>
                  ref.read(importStateProvider.notifier).removeItem(item.id),
            ),
          ),
        ],
      ),
    );
  }
}
