import 'dart:math' as math;
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:image/image.dart' as img;

import '../../domain/artifacts/artifact_store.dart';
import '../../domain/import/image_item.dart';
import '../../domain/crop/crop_service.dart';
import '../../domain/specs/idphoto_specs.dart';
import '../../state/artifact_state.dart';
import '../../state/correction_state.dart';
import '../../state/crop_state.dart';
import '../../state/import_state.dart';
import '../../state/selected_item_state.dart';

/// 步骤 5「裁剪」：规格选择 + 自动/手动裁剪框。
class CropStep extends ConsumerStatefulWidget {
  const CropStep({super.key});

  @override
  ConsumerState<CropStep> createState() => _CropStepState();
}

class _CropStepState extends ConsumerState<CropStep> {
  @override
  Widget build(BuildContext context) {
    final items = ref.watch(importStateProvider).items;
    final selectedId = ref.watch(selectedItemIdProvider);
    final selected =
        items.where((e) => e.id == selectedId).firstOrNull;

    if (selected == null && items.isNotEmpty) {
      Future.microtask(() {
        if (!mounted) return;
        if (ref.read(selectedItemIdProvider) == null) {
          ref.read(selectedItemIdProvider.notifier).state = items.first.id;
        }
      });
    }

    // 选中变化时自动构图。
    ref.listen(selectedItemIdProvider, (prev, next) {
      if (next == null) return;
      final item = items.where((e) => e.id == next).firstOrNull;
      if (item == null) return;
      final st = ref.read(cropStateProvider);
      if (st.rects[item.id] == null && !st.isApplying) {
        ref
            .read(cropStateProvider.notifier)
            .autoCrop(item, ref.read(correctionStateProvider).analyses[item.id]);
      }
    });

    // 进入页面时选中项已存在但尚未构图：立即自动构图。
    if (selected != null &&
        ref.read(cropStateProvider).rects[selected.id] == null &&
        !ref.read(cropStateProvider).isApplying) {
      Future.microtask(() {
        if (!mounted) return;
        final st = ref.read(cropStateProvider);
        if (st.rects[selected.id] == null && !st.isApplying) {
          ref
              .read(cropStateProvider.notifier)
              .autoCrop(selected,
                  ref.read(correctionStateProvider).analyses[selected.id]);
        }
      });
    }

    // 切换规格后清空裁框 → 自动重新构图。
    ref.listen(cropStateProvider, (prev, next) {
      if (prev?.selectedSpecId == next.selectedSpecId || next.isApplying) return;
      final sel = ref
          .read(importStateProvider)
          .items
          .where((e) => e.id == ref.read(selectedItemIdProvider))
          .firstOrNull;
      if (sel != null) {
        ref
            .read(cropStateProvider.notifier)
            .autoCrop(sel, ref.read(correctionStateProvider).analyses[sel.id]);
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('裁剪')),
      body: items.isEmpty
          ? _EmptyHint(onBack: () => Navigator.of(context).pop())
          : Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Expanded(
                  child: ListView(
                    padding: const EdgeInsets.all(16),
                    children: [
                      const _SpecSelector(),
                      const SizedBox(height: 12),
                      if (selected != null) ...[
                        _CropPreview(item: selected),
                        const SizedBox(height: 12),
                        _CropControls(item: selected),
                        const SizedBox(height: 16),
                        _SaveButton(item: selected),
                      ],
                    ],
                  ),
                ),
              ],
            ),
    );
  }
}

/// 规格选择。
class _SpecSelector extends ConsumerWidget {
  const _SpecSelector();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final theme = Theme.of(context);
    final selected = ref.watch(cropStateProvider).selectedSpec;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.start,
      children: [
        Text('证件照规格', style: theme.textTheme.titleSmall),
        const SizedBox(height: 8),
        SizedBox(
          height: 40,
          child: ListView.separated(
            scrollDirection: Axis.horizontal,
            itemCount: IdPhotoSpec.builtin.length,
            separatorBuilder: (_, __) => const SizedBox(width: 6),
            itemBuilder: (context, index) {
              final spec = IdPhotoSpec.builtin[index];
              final active = spec.id == selected.id;
              return ChoiceChip(
                label: Text(
                  '${spec.name}\n${spec.widthMm.toInt()}×${spec.heightMm.toInt()}',
                  style: theme.textTheme.labelSmall?.copyWith(
                    fontSize: 10,
                    height: 1.2,
                  ),
                  textAlign: TextAlign.center,
                ),
                selected: active,
                onSelected: (_) =>
                    ref.read(cropStateProvider.notifier).selectSpec(spec),
                showCheckmark: false,
                visualDensity: VisualDensity.compact,
                labelPadding: const EdgeInsets.symmetric(horizontal: 6),
              );
            },
          ),
        ),
      ],
    );
  }
}

/// 裁剪预览：裁框叠加 + 拖拽 + 缩放。
class _CropPreview extends ConsumerStatefulWidget {
  const _CropPreview({required this.item});

  final ImageItem item;

  @override
  ConsumerState<_CropPreview> createState() => _CropPreviewState();
}

class _CropPreviewState extends ConsumerState<_CropPreview> {
  static const double _maxSide = 420;
  img.Image? _base;
  Uint8List? _encoded;
  double _scale = 1;

  void _ensureBase() {
    if (_base != null) return;
    final decoded = img.decodeImage(
        independentInputFor(ref, widget.item, ArtifactKind.cropped));
    if (decoded == null) return;
    final side = math.max(decoded.width, decoded.height);
    final factor = side > _maxSide ? _maxSide / side : 1.0;
    _base = factor < 1.0
        ? img.copyResize(decoded,
            width: (decoded.width * factor).round(),
            height: (decoded.height * factor).round(),
            interpolation: img.Interpolation.linear)
        : decoded;
    _scale = decoded.width / _base!.width;
  }

  void _onPan(Offset delta) {
    final rect = ref.read(cropStateProvider).rects[widget.item.id];
    if (rect == null) return;
    final dx = (delta.dx * _scale).round();
    final dy = (delta.dy * _scale).round();
    if (dx == 0 && dy == 0) return;
    ref.read(cropStateProvider.notifier).shift(widget.item, dx, dy);
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    ref.watch(cropStateProvider);
    _ensureBase();
    if (_base == null) {
      return const SizedBox(height: 200, child: Center(child: CircularProgressIndicator()));
    }

    final rect = ref.read(cropStateProvider).rects[widget.item.id];
    _encoded ??= Uint8List.fromList(img.encodeJpg(_base!, quality: 85));
    final png = _encoded!;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Center(
          child: ClipRRect(
            borderRadius: BorderRadius.circular(10),
            child: AspectRatio(
              aspectRatio: _base!.width / _base!.height,
              child: GestureDetector(
                onPanUpdate: (d) => _onPan(d.delta),
                child: Stack(
                  fit: StackFit.expand,
                  children: [
                    Image.memory(png, fit: BoxFit.contain, gaplessPlayback: true),
                    if (rect != null)
                      Positioned.fill(
                        child: CustomPaint(
                          painter: _CropOverlayPainter(
                            rect: Rect.fromLTWH(
                              rect.x / _scale,
                              rect.y / _scale,
                              rect.width / _scale,
                              rect.height / _scale,
                            ),
                            color: theme.colorScheme.primary,
                          ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ),
        const SizedBox(height: 6),
        Text(
          '拖动画面调整人物位置；下方滑杆缩放取景（保持规格比例）',
          style: theme.textTheme.bodySmall?.copyWith(color: theme.colorScheme.outline),
          textAlign: TextAlign.center,
        ),
      ],
    );
  }
}

/// 裁框叠加层：半透明遮罩 + 框线 + 网格参考线。
class _CropOverlayPainter extends CustomPainter {
  _CropOverlayPainter({required this.rect, required this.color});

  final Rect rect;
  final Color color;

  @override
  void paint(Canvas canvas, Size size) {
    // 遮罩（框外压暗）。
    final mask = Path()
      ..addRect(Rect.fromLTWH(0, 0, size.width, size.height))
      ..addRect(rect)
      ..fillType = PathFillType.evenOdd;
    canvas.drawPath(mask, Paint()..color = Colors.black.withValues(alpha: 0.45));

    // 框线。
    final border = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 2
      ..color = color;
    canvas.drawRect(rect, border);

    // 网格（三等分参考线）。
    final grid = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 0.8
      ..color = Colors.white.withValues(alpha: 0.8);
    for (var i = 1; i < 3; i++) {
      final x = rect.left + rect.width * i / 3;
      final y = rect.top + rect.height * i / 3;
      canvas.drawLine(Offset(x, rect.top), Offset(x, rect.bottom), grid);
      canvas.drawLine(Offset(rect.left, y), Offset(rect.right, y), grid);
    }

    // 眼睛参考线（约 58% 高度处）。
    final eyeLine = Paint()
      ..style = PaintingStyle.stroke
      ..strokeWidth = 1
      ..color = Colors.yellow.withValues(alpha: 0.9);
    final eyeY = rect.top + rect.height * 0.58;
    canvas.drawLine(
        Offset(rect.left + 4, eyeY), Offset(rect.right - 4, eyeY), eyeLine);
  }

  @override
  bool shouldRepaint(covariant _CropOverlayPainter oldDelegate) =>
      oldDelegate.rect != rect || oldDelegate.color != color;
}

/// 裁剪控制：缩放滑杆 + 重新自动裁剪。
class _CropControls extends ConsumerWidget {
  const _CropControls({required this.item});

  final ImageItem item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final hasRect = ref.watch(cropStateProvider).rects[item.id] != null;
    return Card(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
        child: Column(
          children: [
            Row(
              children: [
                const Icon(Icons.zoom_in, size: 18),
                const SizedBox(width: 8),
                Expanded(
                  child: Slider(
                    value: _zoomValue(ref),
                    min: 0.7,
                    max: 1.5,
                    onChanged: hasRect
                        ? (v) {
                            final prev = _zoomValue(ref);
                            if (prev == 0) return;
                            ref
                                .read(cropStateProvider.notifier)
                                .zoom(item, v / prev);
                          }
                        : null,
                  ),
                ),
                const Icon(Icons.zoom_out, size: 18),
              ],
            ),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                TextButton.icon(
                  onPressed: hasRect
                      ? () => ref
                          .read(cropStateProvider.notifier)
                          .autoCrop(item, ref.read(correctionStateProvider).analyses[item.id])
                      : null,
                  icon: const Icon(Icons.center_focus_strong, size: 18),
                  label: const Text('重新自动构图'),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }

  double _zoomValue(WidgetRef ref) {
    // 从 rect 与预览基图推算当前缩放（简化：固定存于控件状态不可行，
    // 这里用一个近似：基于 rect 高度与原图高度之比）。
    final rect = ref.read(cropStateProvider).rects[item.id];
    if (rect == null) return 1.0;
    final decoded = img.decodeImage(
        independentInputFor(ref, item, ArtifactKind.cropped));
    if (decoded == null) return 1.0;
    return (rect.height / decoded.height).clamp(0.7, 1.5);
  }
}

class _SaveButton extends ConsumerWidget {
  const _SaveButton({required this.item});

  final ImageItem item;

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final rect = ref.watch(cropStateProvider).rects[item.id];
    return FilledButton.icon(
      onPressed: rect == null
          ? null
          : () async {
              final bytes = _cropBytes(ref, item);
              if (bytes == null) {
                if (context.mounted) {
                  ScaffoldMessenger.of(context).showSnackBar(
                    const SnackBar(content: Text('保存失败，请重试')),
                  );
                }
                return;
              }
              await ref
                  .read(artifactStateProvider.notifier)
                  .save(item.id, ArtifactKind.cropped, bytes);
              if (context.mounted) {
                ScaffoldMessenger.of(context).showSnackBar(
                  const SnackBar(content: Text('已保存裁剪结果')),
                );
                Navigator.of(context).pop();
              }
            },
      icon: const Icon(Icons.check),
      label: const Text('确定并保存'),
    );
  }

  Uint8List? _cropBytes(WidgetRef ref, ImageItem item) {
    final st = ref.read(cropStateProvider);
    final rect = st.rects[item.id];
    if (rect == null) return null;
    final decoded = img.decodeImage(
        independentInputFor(ref, item, ArtifactKind.cropped));
    if (decoded == null) return null;
    final spec = st.selectedSpec;
    final cropped = const CropService().applyCrop(
      decoded,
      rect,
      targetWidth: spec.pixelWidth,
      targetHeight: spec.pixelHeight,
    );
    return Uint8List.fromList(img.encodeJpg(cropped, quality: 92));
  }
}

class _EmptyHint extends StatelessWidget {
  const _EmptyHint({required this.onBack});

  final VoidCallback onBack;

  @override
  Widget build(BuildContext context) {
    return Center(
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(Icons.photo_library_outlined, size: 56, color: Theme.of(context).colorScheme.outline),
          const SizedBox(height: 12),
          const Text('还没有导入照片'),
          const SizedBox(height: 8),
          TextButton(onPressed: onBack, child: const Text('返回导入')),
        ],
      ),
    );
  }
}

