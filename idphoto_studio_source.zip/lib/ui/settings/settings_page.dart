import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';

import '../../domain/privacy/cleanup_service.dart';
import '../../state/settings_state.dart';

/// 设置与帮助页：主题、隐私、常见问题、关于。
class SettingsPage extends ConsumerWidget {
  const SettingsPage({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final mode = ref.watch(settingsStateProvider).themeMode;
    final notifier = ref.read(settingsStateProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: const Text('设置与帮助')),
      body: ListView(
        children: [
          const _SectionTitle('外观'),
          ListTile(
            leading: const Icon(Icons.brightness_6),
            title: const Text('主题'),
            trailing: DropdownButton<ThemeMode>(
              value: mode,
              underline: const SizedBox.shrink(),
              items: const [
                DropdownMenuItem(value: ThemeMode.system, child: Text('跟随系统')),
                DropdownMenuItem(value: ThemeMode.light, child: Text('浅色')),
                DropdownMenuItem(value: ThemeMode.dark, child: Text('深色')),
              ],
              onChanged: (m) {
                if (m != null) notifier.setThemeMode(m);
              },
            ),
          ),
          const Divider(),
          const _SectionTitle('隐私与安全'),
          const ListTile(
            leading: Icon(Icons.shield_outlined),
            title: Text('完全本地处理'),
            subtitle: Text(
              '照片全程在本机处理，不上传任何云端；\n分割模型内置（约 250KB），无网络也可使用。',
            ),
          ),
          const ListTile(
            leading: Icon(Icons.offline_pin_outlined),
            title: Text('离线可用'),
            subtitle: Text('不收集照片，不发送统计数据，不联网。'),
          ),
          ListTile(
            leading: const Icon(Icons.cleaning_services_outlined),
            title: const Text('清除导出缓存'),
            subtitle: const Text('删除应用生成的 exports/、prints/ 导出文件'),
            trailing: FilledButton.tonal(
              onPressed: () => _confirmCleanup(context),
              child: const Text('清理'),
            ),
          ),
          const Divider(),
          const _SectionTitle('更新'),
          ListTile(
            leading: const Icon(Icons.system_update_alt),
            title: const Text('自动检查更新'),
            subtitle: const Text('默认关闭：离线版无更新通道，开启后仅在设置页手动检查'),
            trailing: Switch(
              value: ref.watch(settingsStateProvider).checkUpdate,
              onChanged: (v) =>
                  ref.read(settingsStateProvider.notifier).setCheckUpdate(v),
            ),
          ),
          const Divider(),
          const _SectionTitle('常见问题'),
          const _Faq(
            q: '为什么提示「未检测到人脸」？',
            a: '请确保照片正面清晰、光线均匀；侧脸、遮挡、模糊都会导致检测失败。',
          ),
          const _Faq(
            q: '抠图边缘不理想怎么办？',
            a: '使用画笔工具在画面涂抹「保留」或「擦除」区域，可多次修补。',
          ),
          const _Faq(
            q: '证件照规格如何选择？',
            a: '内置一寸、二寸、护照、签证等 14 种常见规格；可在裁剪步骤切换，尺寸按 300DPI 换算。',
          ),
          const _Faq(
            q: '导出文件保存在哪里？',
            a: '单张导出保存在应用文档目录 exports/，排版文件在 prints/，可通过「分享」发送到相册或微信。',
          ),
          const _Faq(
            q: '换装功能安全吗？',
            a: '贴图式换装默认关闭，不改变五官比例；效果取决于原图姿态，不满意可随时关闭。',
          ),
          const Divider(),
          const _SectionTitle('关于'),
          const ListTile(
            leading: Icon(Icons.photo_camera_back),
            title: Text('证件照工坊 v0.4.0'),
            subtitle: Text('Android · 离线本地版\n模型许可：Apache-2.0（可商用）'),
          ),
          const SizedBox(height: 24),
        ],
      ),
    );
  }
}

Future<void> _confirmCleanup(BuildContext context) async {
  final confirmed = await showDialog<bool>(
    context: context,
    builder: (ctx) => AlertDialog(
      title: const Text('清除导出缓存'),
      content: const Text('将删除应用生成的排版图、单张导出等文件，不影响原始照片。确定继续？'),
      actions: [
        TextButton(
          onPressed: () => Navigator.of(ctx).pop(false),
          child: const Text('取消'),
        ),
        FilledButton(
          onPressed: () => Navigator.of(ctx).pop(true),
          child: const Text('清除'),
        ),
      ],
    ),
  );
  if (confirmed != true || !context.mounted) return;
  final removed = await const CleanupService().clearExportCache();
  if (!context.mounted) return;
  ScaffoldMessenger.of(context).showSnackBar(
    SnackBar(content: Text('已清理 $removed 个文件')),
  );
}

class _SectionTitle extends StatelessWidget {
  const _SectionTitle(this.text);

  final String text;

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: const EdgeInsets.fromLTRB(16, 16, 16, 4),
      child: Text(
        text,
        style: Theme.of(context).textTheme.titleSmall?.copyWith(
              color: Theme.of(context).colorScheme.primary,
            ),
      ),
    );
  }
}

class _Faq extends StatelessWidget {
  const _Faq({required this.q, required this.a});

  final String q;
  final String a;

  @override
  Widget build(BuildContext context) {
    return ExpansionTile(
      leading: const Icon(Icons.help_outline, size: 20),
      title: Text(q, style: const TextStyle(fontSize: 14)),
      childrenPadding: EdgeInsets.zero,
      tilePadding: const EdgeInsets.symmetric(horizontal: 16),
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 0, 16, 12),
          child: Align(
            alignment: Alignment.centerLeft,
            child: Text(a, style: Theme.of(context).textTheme.bodySmall),
          ),
        ),
      ],
    );
  }
}
