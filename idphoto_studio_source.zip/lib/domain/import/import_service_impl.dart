import 'dart:io';
import 'dart:math';
import 'dart:typed_data';

import 'package:exif/exif.dart';
import 'package:image/image.dart' as img;
import 'package:path/path.dart' as p;
import 'package:uuid/uuid.dart';

import 'exif_orientation.dart';
import 'heic_decoder.dart';
import 'heic_decoder_platform.dart';
import 'image_item.dart';
import 'import_service.dart';
import 'supported_formats.dart';

/// 基于 `exif` 包的默认 EXIF 读取器。
class DefaultExifReader implements ExifReader {
  @override
  Future<int?> readOrientation(Uint8List bytes) async {
    try {
      final tags = await readExifFromBytes(bytes);
      final tag = tags['Exif.Image.Orientation'];
      return parseOrientationString(tag?.printable);
    } catch (_) {
      // 无 EXIF / 非 JPEG / 数据损坏等，统一视为无需矫正。
      return null;
    }
  }
}

/// 本地导入服务实现。
class LocalImportService implements ImportService {
  LocalImportService({
    ExifReader? exifReader,
    HeicDecoder? heicDecoder,
    this.maxFileBytes = 100 * 1024 * 1024,
  })  : _exifReader = exifReader ?? DefaultExifReader(),
        _heicDecoder = heicDecoder ?? createDefaultHeicDecoder();

  final ExifReader _exifReader;
  final HeicDecoder _heicDecoder;

  /// 单文件大小上限（默认 100MB）。
  final int maxFileBytes;

  static const _uuid = Uuid();

  @override
  Future<ImportResult> importFile(String path) async {
    final result = await importFiles([path]);
    return result;
  }

  @override
  Future<ImportResult> importFiles(List<String> paths) async {
    final items = <ImageItem>[];
    final failures = <ImportFailure>[];
    for (final path in paths) {
      try {
        items.add(await _importOne(path));
      } on ImportFailureException catch (e) {
        failures.add(e.failure);
      } catch (e) {
        failures.add(ImportFailure(
          filePath: path,
          fileName: p.basename(path),
          code: ImportFailureCode.unknown,
          message: '导入失败：$e',
        ));
      }
    }
    return ImportResult(items: items, failures: failures);
  }

  @override
  Future<ImportResult> importDirectory(String directoryPath) async {
    final dir = Directory(directoryPath);
    if (!await dir.exists()) {
      return ImportResult(
        items: const [],
        failures: [
          ImportFailure(
            filePath: directoryPath,
            fileName: p.basename(directoryPath),
            code: ImportFailureCode.fileNotFound,
            message: '目录不存在或不可访问',
          ),
        ],
      );
    }
    final files = <String>[];
    await for (final entity in dir.list(followLinks: false)) {
      if (entity is File) {
        final ext = p.extension(entity.path).replaceFirst('.', '').toLowerCase();
        if (isSupportedExtension(ext)) {
          files.add(entity.path);
        }
      }
    }
    files.sort();
    return importFiles(files);
  }

  /// 单张导入，失败抛 [ImportFailureException]。
  Future<ImageItem> _importOne(String path) async {
    final ext = p.extension(path).replaceFirst('.', '').toLowerCase();
    final fileName = p.basename(path);

    if (!isSupportedExtension(ext)) {
      throw ImportFailureException(ImportFailure(
        filePath: path,
        fileName: fileName,
        code: ImportFailureCode.unsupportedFormat,
        message: '不支持的格式：${extensionDisplayName(ext)}（支持 JPG/JPEG/PNG/WEBP/HEIC）',
      ));
    }

    final file = File(path);
    if (!await file.exists()) {
      throw ImportFailureException(ImportFailure(
        filePath: path,
        fileName: fileName,
        code: ImportFailureCode.fileNotFound,
        message: '文件不存在或不可访问',
      ));
    }
    final size = await file.length();
    if (size > maxFileBytes) {
      throw ImportFailureException(ImportFailure(
        filePath: path,
        fileName: fileName,
        code: ImportFailureCode.tooLarge,
        message: '文件过大（${_fmtBytes(size)}，上限 ${_fmtBytes(maxFileBytes)}）',
      ));
    }

    // 解码：HEIC 走平台解码器，其余走 image 包。
    Uint8List rawBytes;
    int? exifOrientation;
    try {
      if (isHeicExtension(ext)) {
        if (!_heicDecoder.isSupported) {
          throw ImportFailureException(ImportFailure(
            filePath: path,
            fileName: fileName,
            code: ImportFailureCode.heicNotSupported,
            message: '当前平台暂不支持 HEIC，请先转换为 JPG/PNG',
          ));
        }
        rawBytes = await _heicDecoder.decodeToPngBytes(path);
        // Android 系统解码器已应用 HEIF 方向元数据，不再二次矫正。
      } else {
        rawBytes = await file.readAsBytes();
        exifOrientation = await _exifReader.readOrientation(rawBytes);
      }
    } on HeicDecodeException catch (e) {
      throw ImportFailureException(ImportFailure(
        filePath: path,
        fileName: fileName,
        code: ImportFailureCode.heicNotSupported,
        message: e.message,
      ));
    }

    final decoded = img.decodeImage(rawBytes);
    if (decoded == null) {
      throw ImportFailureException(ImportFailure(
        filePath: path,
        fileName: fileName,
        code: ImportFailureCode.decodeFailed,
        message: '图片解码失败，文件可能已损坏或不是有效图片',
      ));
    }

    final originalWidth = decoded.width;
    final originalHeight = decoded.height;

    // EXIF 矫正。
    var oriented = decoded;
    var exifCorrected = false;
    if (exifOrientation != null && needsCorrection(exifOrientation)) {
      oriented = applyExifCorrection(decoded, exifOrientation);
      exifCorrected = true;
    }

    // 降采样：处理用图 ≤ kMaxWorkingEdge，缩略图 ≤ kMaxThumbnailEdge。
    final working = _resizeIfNeeded(oriented, ImageItem.kMaxWorkingEdge);
    final workingBytes = Uint8List.fromList(img.encodeJpg(working, quality: 92));

    final thumb =
        _resizeIfNeeded(oriented, ImageItem.kMaxThumbnailEdge, downscaleOnly: true);
    final thumbBytes = Uint8List.fromList(img.encodeJpg(thumb, quality: 80));

    return ImageItem(
      id: _uuid.v4(),
      sourcePath: path,
      fileName: fileName,
      workingBytes: workingBytes,
      workingWidth: working.width,
      workingHeight: working.height,
      thumbnailBytes: thumbBytes,
      originalWidth: originalWidth,
      originalHeight: originalHeight,
      exifOrientation: exifOrientation ?? 1,
      exifCorrected: exifCorrected,
      importedAt: DateTime.now(),
    );
  }

  /// 等比缩放（默认仅当超出 maxEdge 时缩小；[downscaleOnly] 时小图不放大）。
  img.Image _resizeIfNeeded(
    img.Image image,
    int maxEdge, {
    bool downscaleOnly = true,
  }) {
    final longEdge = max(image.width, image.height);
    if (longEdge <= maxEdge) {
      if (downscaleOnly) return image;
      final scale = maxEdge / longEdge;
      return img.copyResize(
        image,
        width: max(1, (image.width * scale).round()),
        height: max(1, (image.height * scale).round()),
        interpolation: img.Interpolation.linear,
      );
    }
    final scale = maxEdge / longEdge;
    return img.copyResize(
      image,
      width: max(1, (image.width * scale).round()),
      height: max(1, (image.height * scale).round()),
      interpolation: img.Interpolation.linear,
    );
  }

  static String _fmtBytes(int bytes) {
    if (bytes >= 1024 * 1024) return '${(bytes / 1024 / 1024).toStringAsFixed(1)}MB';
    return '${(bytes / 1024).toStringAsFixed(0)}KB';
  }
}

/// 内部异常：携带已构造好的 [ImportFailure]。
class ImportFailureException implements Exception {
  ImportFailureException(this.failure);

  final ImportFailure failure;
}
