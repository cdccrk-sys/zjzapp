/// EXIF Orientation 标签（1–8）的语义与矫正实现。
///
/// 标准定义（TIFF/EXIF），与 PIL ImageOps.exif_transpose 一致：
/// 1  正常
/// 2  水平翻转
/// 3  旋转 180°
/// 4  垂直翻转
/// 5  水平翻转 + 顺时针旋转 270°（主对角线转置）
/// 6  顺时针旋转 90°
/// 7  水平翻转 + 顺时针旋转 90°（反对角线转置）
/// 8  顺时针旋转 270°
///
/// 矫正原语分解：旋转分量（[rotationDegrees]，顺时针）+ 翻转分量
/// （[needsHorizontalFlip] / [needsVerticalFlip]）。全部逻辑为纯函数，
/// 可独立单元测试。
library;

import 'dart:typed_data';

import 'package:image/image.dart' as img;

/// EXIF Orientation 值 → 需要顺时针旋转的度数。
int rotationDegrees(int orientation) {
  switch (orientation) {
    case 3:
      return 180;
    case 5:
      return 270;
    case 6:
      return 90;
    case 7:
      return 90;
    case 8:
      return 270;
    default:
      return 0;
  }
}

/// 该 Orientation 值是否需要水平翻转（2/5/7）。
bool needsHorizontalFlip(int orientation) {
  return orientation == 2 || orientation == 5 || orientation == 7;
}

/// 该 Orientation 值是否需要垂直翻转（4）。
bool needsVerticalFlip(int orientation) {
  return orientation == 4;
}

/// 该 Orientation 值是否需要任何矫正（2–8 均需要，1 为正常）。
bool needsCorrection(int orientation) {
  return orientation >= 2 && orientation <= 8;
}

/// 解析 EXIF Orientation 字符串为整数（1–8）。
///
/// 兼容两种来源：
/// - 纯数字（如 "6"、" 3 "）；
/// - exif 包/标准 EXIF 的名称（如 "Rotated 90 CW"、"Mirrored horizontal"）。
/// 解析失败或不可识别时返回 null。
int? parseOrientationString(String? printable) {
  if (printable == null || printable.isEmpty) return null;
  final t = printable.trim();

  // 数字开头（排除 "18"、"0"、"9" 等歧义/越界值）。
  final m = RegExp(r'^([1-8])(\D|$)').firstMatch(t);
  if (m != null) return int.parse(m.group(1)!);

  // 名称映射（归一化大小写与空格/连字符后按优先级匹配，避免子串误判）。
  final n = t.toLowerCase().replaceAll(RegExp(r'[\s-]+'), '');
  if (n.contains('horizontal(normal)') || n.contains('topleft')) return 1;
  if (n.contains('mirroredhorizontal') && n.contains('90ccw')) return 5;
  if (n.contains('mirroredhorizontal') && n.contains('90cw')) return 7;
  if (n.contains('mirroredhorizontal') || n.contains('topright')) return 2;
  if (n.contains('mirroredvertical') || n.contains('bottomleft')) return 4;
  if (n.contains('rotated180') ||
      n.contains('rotate180') ||
      n.contains('bottomright')) {
    return 3;
  }
  if (n.contains('90cw') || n.contains('righttop')) return 6;
  if (n.contains('90ccw') ||
      n.contains('270cw') ||
      n.contains('leftbottom')) {
    return 8;
  }
  if (n.contains('lefttop')) return 5;
  return null;
}

/// 对已解码图像应用 EXIF 矫正。
///
/// 顺序：垂直翻转（4）→ 水平翻转（2/5/7）→ 顺时针旋转。返回新对象，不改动入参。
img.Image applyExifCorrection(img.Image image, int orientation) {
  var result = image;
  if (needsVerticalFlip(orientation)) {
    result = img.flipVertical(result);
  } else if (needsHorizontalFlip(orientation)) {
    result = img.flipHorizontal(result);
  }
  final deg = rotationDegrees(orientation);
  if (deg != 0) {
    result = img.copyRotate(result, angle: deg);
  }
  return result;
}

/// EXIF 读取器抽象：从图片字节中读取 Orientation 整数值。
///
/// 独立成接口以便在测试中注入假实现，且便于后续替换解析库。
abstract class ExifReader {
  /// 返回 EXIF Orientation（1–8）；无 EXIF 或读取失败返回 null。
  Future<int?> readOrientation(Uint8List bytes);
}
