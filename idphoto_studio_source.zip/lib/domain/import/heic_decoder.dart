import 'dart:typed_data';

/// HEIC/HEIF 解码器抽象。
///
/// Android（API 28+）使用系统解码器（见 android/.../MainActivity.kt 的
/// `idphoto/heic` MethodChannel）；Windows 在 M1 阶段返回不支持。
/// 后续里程碑可替换为基于 libheif/WIC 的插件实现，不影响其他模块。
abstract class HeicDecoder {
  /// 将 HEIC 文件解码为 PNG 字节；失败抛 [HeicDecodeException]。
  Future<Uint8List> decodeToPngBytes(String filePath);

  /// 当前平台是否支持 HEIC 解码。
  bool get isSupported;
}

class HeicDecodeException implements Exception {
  HeicDecodeException(this.message, {this.code = 'heic_decode_failed'});

  final String message;
  final String code;

  @override
  String toString() => 'HeicDecodeException($code): $message';
}
