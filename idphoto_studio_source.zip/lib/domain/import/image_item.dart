import 'dart:typed_data';

/// 导入成功后的图片工作项。
///
/// 设计要点：
/// - 不把原图整张读入内存；只保留 [workingBytes]（处理用降采样图）与
///   [thumbnailBytes]（预览缩略图），原图路径供后续导出模块按需读取。
/// - [workingBytes] 为 JPEG 编码（质量 92），兼顾体积与后续处理精度；
///   纯处理流程在解码后的 [img.Image] 上执行，无二次压缩损失问题。
class ImageItem {
  ImageItem({
    required this.id,
    required this.sourcePath,
    required this.fileName,
    required this.workingBytes,
    required this.workingWidth,
    required this.workingHeight,
    required this.thumbnailBytes,
    required this.originalWidth,
    required this.originalHeight,
    required this.exifOrientation,
    required this.exifCorrected,
    required this.importedAt,
  });

  /// 唯一 ID（工程文件索引用）。
  final String id;

  /// 原始文件绝对路径。
  final String sourcePath;

  /// 文件名（含扩展名）。
  final String fileName;

  /// 处理用图（EXIF 已矫正 + 降采样 ≤ [kMaxWorkingEdge]）的编码字节。
  final Uint8List workingBytes;

  /// 处理用图尺寸。
  final int workingWidth;
  final int workingHeight;

  /// 预览缩略图编码字节（JPEG，短边 ≤ 320px）。
  final Uint8List thumbnailBytes;

  /// 原图尺寸（EXIF 矫正前）。
  final int originalWidth;
  final int originalHeight;

  /// 原文件 EXIF Orientation（1–8；无则为 1）。
  final int exifOrientation;

  /// 是否因 EXIF 执行过旋转/翻转矫正。
  final bool exifCorrected;

  final DateTime importedAt;

  /// 处理用图最大边长（像素）。超过则等比降采样。
  static const int kMaxWorkingEdge = 2000;

  /// 缩略图最大边长（像素）。
  static const int kMaxThumbnailEdge = 320;
}

/// 单张导入失败的记录。
class ImportFailure {
  ImportFailure({
    required this.filePath,
    required this.fileName,
    required this.code,
    required this.message,
  });

  final String filePath;
  final String fileName;
  final ImportFailureCode code;
  final String message;
}

/// 导入失败原因分类（用于 UI 提示与后续重试策略）。
enum ImportFailureCode {
  /// 扩展名不在支持列表。
  unsupportedFormat,

  /// 文件不存在或不可读。
  fileNotFound,

  /// 文件超过大小上限。
  tooLarge,

  /// 图片解码失败（损坏/非图片内容）。
  decodeFailed,

  /// HEIC 当前平台不支持。
  heicNotSupported,

  /// 无权限访问。
  permissionDenied,

  /// 其他未知错误。
  unknown,
}

/// 导入结果：成功项 + 失败清单。
class ImportResult {
  ImportResult({required this.items, required this.failures});

  final List<ImageItem> items;
  final List<ImportFailure> failures;

  bool get hasFailures => failures.isNotEmpty;
}
