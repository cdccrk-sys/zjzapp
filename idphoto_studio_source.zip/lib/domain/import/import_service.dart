import 'image_item.dart';

/// 图片导入服务接口。
///
/// 职责：格式校验 → 读取 → 解码（含 HEIC）→ EXIF 矫正 →
/// 降采样生成处理图与缩略图 → 产出 [ImageItem]。
/// 实现为平台无关纯 Dart + 可注入依赖，便于单测与后续扩展。
abstract class ImportService {
  /// 导入单个文件路径。
  Future<ImportResult> importFile(String path);

  /// 批量导入多个文件路径（保持传入顺序）。
  Future<ImportResult> importFiles(List<String> paths);

  /// 导入目录下全部受支持图片（不递归子目录，按文件名排序）。
  Future<ImportResult> importDirectory(String directoryPath);
}
