import 'dart:io' show Platform;

import 'package:flutter/services.dart';

import 'heic_decoder.dart';

/// 基于 MethodChannel 的 Android 系统 HEIC 解码器。
///
/// Android 侧实现位于 android/.../MainActivity.kt，通过
/// `BitmapFactory.decodeFile` 解码后压缩为 PNG 字节返回。
class AndroidHeicDecoder implements HeicDecoder {
  AndroidHeicDecoder({MethodChannel? channel})
      : _channel = channel ?? const MethodChannel('idphoto/heic');

  final MethodChannel _channel;

  @override
  bool get isSupported => Platform.isAndroid;

  @override
  Future<Uint8List> decodeToPngBytes(String filePath) async {
    if (!isSupported) {
      throw HeicDecodeException(
        '当前平台不支持 HEIC 解码，请先将图片转换为 JPG/PNG 格式',
        code: 'heic_not_supported',
      );
    }
    try {
      final bytes = await _channel.invokeMethod<Uint8List>('decode', {
        'path': filePath,
      });
      if (bytes == null) {
        throw HeicDecodeException('系统解码器未返回数据，文件可能已损坏');
      }
      return bytes;
    } on PlatformException catch (e) {
      throw HeicDecodeException(e.message ?? '系统解码器失败', code: e.code);
    }
  }
}

/// 不支持 HEIC 的占位实现（Windows/Linux/macOS 在 M1 阶段）。
class UnsupportedHeicDecoder implements HeicDecoder {
  @override
  bool get isSupported => false;

  @override
  Future<Uint8List> decodeToPngBytes(String filePath) {
    throw HeicDecodeException(
      '当前平台暂不支持 HEIC 解码，请先将图片转换为 JPG/PNG 格式',
      code: 'heic_not_supported',
    );
  }
}

/// 按当前平台返回合适的 HEIC 解码器。
HeicDecoder createDefaultHeicDecoder() {
  if (Platform.isAndroid) {
    return AndroidHeicDecoder();
  }
  return UnsupportedHeicDecoder();
}
