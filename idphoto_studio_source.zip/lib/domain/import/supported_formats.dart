/// 支持的图片格式定义。
///
/// 分层说明：
/// - [kRasterExtensions]：`image` 包原生支持（全平台，含 Windows），
///   不依赖系统编解码器。
/// - [kHeicExtensions]：HEIC/HEIF 仅在 Android（API 28+）通过系统解码器
///   支持；Windows 端在 M1 阶段给出明确错误提示，后续里程碑接入插件兜底。
library;

/// `image` 包原生可解码的光栅格式扩展名（不含点号，小写）。
const Set<String> kRasterExtensions = {'jpg', 'jpeg', 'png', 'webp'};

/// HEIC/HEIF 格式扩展名。
const Set<String> kHeicExtensions = {'heic', 'heif'};

/// 全部受支持扩展名（用于文件选择器过滤）。
const Set<String> kSupportedExtensions = {...kRasterExtensions, ...kHeicExtensions};

/// 扩展名转显示名称（用于错误提示）。
String extensionDisplayName(String ext) {
  final e = ext.toLowerCase();
  if (kHeicExtensions.contains(e)) return e.toUpperCase();
  return e.toUpperCase();
}

/// 判断扩展名是否受支持。
bool isSupportedExtension(String ext) => kSupportedExtensions.contains(ext.toLowerCase());

/// 判断是否为 HEIC 格式。
bool isHeicExtension(String ext) => kHeicExtensions.contains(ext.toLowerCase());
