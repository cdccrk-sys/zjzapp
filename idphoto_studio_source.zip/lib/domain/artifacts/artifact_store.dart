import 'dart:io';
import 'dart:typed_data';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// 产物文件种类（每个独立功能对应一种）。
///
/// 功能链：original → corrected → matting(透明PNG) → background →
/// cropped → enhanced → 最终导出。
enum ArtifactKind {
  /// 导入后的工作图（原始处理图）。
  original,

  /// 矫正后的照片。
  corrected,

  /// 抠图结果（透明底 PNG，保留 alpha）。
  matting,

  /// 换背景后的照片。
  background,

  /// 按规格裁剪后的照片。
  cropped,

  /// 色彩优化后的照片。
  enhanced,
}

extension ArtifactKindX on ArtifactKind {
  String get key => switch (this) {
        ArtifactKind.original => 'original',
        ArtifactKind.corrected => 'corrected',
        ArtifactKind.matting => 'matting',
        ArtifactKind.background => 'background',
        ArtifactKind.cropped => 'cropped',
        ArtifactKind.enhanced => 'enhanced',
      };

  /// 产物文件扩展名：抠图用透明 PNG，其余用 JPG。
  String get ext => this == ArtifactKind.matting ? 'png' : 'jpg';
}

/// 产物文件存储：`<应用文档>/artifacts/<itemId>/<功能>.jpg|png`。
///
/// 每个功能「确定并保存」后写一个独立文件；下一个功能从该文件读取，
/// 从而把 8 个步骤彻底拆成相互独立的 8 个功能。
class ArtifactStore {
  const ArtifactStore();

  Future<Directory> _root() async {
    final docs = await getApplicationDocumentsDirectory();
    return Directory(p.join(docs.path, 'artifacts'));
  }

  Future<Directory> _itemDir(String itemId) async {
    final root = await _root();
    final dir = Directory(p.join(root.path, itemId));
    if (!dir.existsSync()) dir.createSync(recursive: true);
    return dir;
  }

  /// 某功能产物的文件路径。
  Future<String> pathFor(String itemId, ArtifactKind kind) async {
    final dir = await _itemDir(itemId);
    return p.join(dir.path, '${kind.key}.${kind.ext}');
  }

  /// 保存产物文件。
  Future<void> save(
    String itemId,
    ArtifactKind kind,
    Uint8List bytes,
  ) async {
    final path = await pathFor(itemId, kind);
    await File(path).writeAsBytes(bytes, flush: true);
  }

  /// 读取产物文件；不存在返回 null。
  Future<Uint8List?> load(String itemId, ArtifactKind kind) async {
    final path = await pathFor(itemId, kind);
    final f = File(path);
    if (!f.existsSync()) return null;
    try {
      return await f.readAsBytes();
    } catch (_) {
      return null;
    }
  }

  /// 产物文件是否存在。
  Future<bool> exists(String itemId, ArtifactKind kind) async {
    final path = await pathFor(itemId, kind);
    return File(path).existsSync();
  }

  /// 删除某照片的全部产物（隐私清理/重新导入时调用）。
  Future<void> deleteAll(String itemId) async {
    final root = await _root();
    final dir = Directory(p.join(root.path, itemId));
    if (dir.existsSync()) {
      try {
        await dir.delete(recursive: true);
      } catch (_) {}
    }
  }

  /// 列出某照片已保存的产物种类。
  Future<List<ArtifactKind>> savedKinds(String itemId) async {
    final root = await _root();
    final dir = Directory(p.join(root.path, itemId));
    if (!dir.existsSync()) return const [];
    final out = <ArtifactKind>[];
    for (final kind in ArtifactKind.values) {
      if (await exists(itemId, kind)) out.add(kind);
    }
    return out;
  }

  /// 扫描全部照片的已保存产物（itemId → 种类集合）。
  Future<Map<String, Set<ArtifactKind>>> savedKindsAll() async {
    final root = await _root();
    if (!root.existsSync()) return const {};
    final out = <String, Set<ArtifactKind>>{};
    await for (final entry in root.list()) {
      if (entry is! Directory) continue;
      final id = p.basename(entry.path);
      final kinds = <ArtifactKind>{};
      for (final kind in ArtifactKind.values) {
        if (await exists(id, kind)) kinds.add(kind);
      }
      if (kinds.isNotEmpty) out[id] = kinds;
    }
    return out;
  }
}
