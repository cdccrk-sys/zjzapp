import 'dart:math' as math;

import 'package:image/image.dart' as img;

/// 正装模板（贴图式）。
enum DressTemplate {
  none('不换装'),
  menSuit('男式西装（深蓝）'),
  womenBlazer('女式西装（黑色）'),
  whiteShirt('白衬衫');

  const DressTemplate(this.label);

  final String label;
}

/// 换装贴图服务。
///
/// 采用「贴图式」方案：按人脸框估计肩部位置与宽度，
/// 将程序绘制的正装图形贴合到身体区域并做边缘羽化融合。
/// 默认关闭（[DressTemplate.none]），不改变五官。
class DressService {
  const DressService();

  /// 换装：在 [source] 上贴合正装。
  ///
  /// [faceTop]/[faceBottom]/[faceCenterX]/[faceWidth]：归一化人脸框
  /// （0..1，相对图像宽高）。
  img.Image dress(
    img.Image source,
    DressTemplate template, {
    required double faceTop,
    required double faceBottom,
    required double faceCenterX,
    required double faceWidth,
  }) {
    if (template == DressTemplate.none) return img.Image.from(source);
    final out = img.Image.from(source);
    final w = source.width;
    final h = source.height;

    // 估计肩线：脸下缘 + 脸高的 0.35；肩宽 ≈ 脸宽的 2.6 倍。
    final faceH = (faceBottom - faceTop) * h;
    final shoulderY = (faceBottom * h + faceH * 0.35).clamp(0, h - 1);
    final shoulderHalf = (faceWidth * w * 1.3).clamp(20, w * 0.6);

    // 服装从肩线延伸到图底。
    final topY = shoulderY.round();
    final bottomY = h - 1;

    final suitColor = _colorOf(template);
    final lapelColor = _lapelOf(template);
    final tieColor = template == DressTemplate.menSuit
        ? img.ColorRgb8(120, 20, 30)
        : template == DressTemplate.whiteShirt
            ? img.ColorRgb8(160, 160, 160)
            : img.ColorRgb8(90, 90, 90);

    for (var y = topY; y <= bottomY; y++) {
      // 垂直渐窄（轻微梯形，模拟肩膀到腰）。
      final t = (y - topY) / math.max(1, bottomY - topY);
      final halfW = (shoulderHalf * (1 - 0.18 * t)).round();
      final x0 = (faceCenterX * w - halfW).round().clamp(0, w - 1);
      final x1 = (faceCenterX * w + halfW).round().clamp(0, w - 1);
      for (var x = x0; x <= x1; x++) {
        // 翻领：两侧 12% 区域用领口色，中央领口 V 形。
        final rel = (x - x0) / math.max(1, x1 - x0);
        final vNeck = 0.42 + 0.08 * t; // V 领开口随高度变宽
        final inLapel =
            (rel < 0.16 && y < topY + faceH * 0.5) ||
                (rel > 0.84 && y < topY + faceH * 0.5);
        final isTie = rel > 0.45 && rel < 0.55 && y < topY + faceH * 0.9;
        img.Color c;
        if (isTie) {
          c = tieColor;
        } else if (inLapel) {
          c = lapelColor;
        } else if (rel > vNeck - 0.12 && rel < vNeck + 0.12) {
          c = lapelColor; // 领口边缘
        } else {
          c = suitColor;
        }
        // 与底图按半透明混合，边缘羽化（顶部 8% 渐变）。
        final alpha = y < topY + faceH * 0.08
            ? ((y - topY) / math.max(1, faceH * 0.08)).clamp(0.0, 1.0)
            : 1.0;
        final k = 0.82 * alpha;
        final bg = source.getPixel(x, y);
        out.setPixelRgb(
          x,
          y,
          (bg.r.toInt() * (1 - k) + c.r * k).round().clamp(0, 255),
          (bg.g.toInt() * (1 - k) + c.g * k).round().clamp(0, 255),
          (bg.b.toInt() * (1 - k) + c.b * k).round().clamp(0, 255),
        );
      }
    }
    return out;
  }

  img.Color _colorOf(DressTemplate t) {
    switch (t) {
      case DressTemplate.menSuit:
        return img.ColorRgb8(25, 42, 86);
      case DressTemplate.womenBlazer:
        return img.ColorRgb8(20, 20, 24);
      case DressTemplate.whiteShirt:
        return img.ColorRgb8(244, 244, 246);
      case DressTemplate.none:
        return img.ColorRgb8(0, 0, 0);
    }
  }

  img.Color _lapelOf(DressTemplate t) {
    switch (t) {
      case DressTemplate.menSuit:
        return img.ColorRgb8(10, 18, 42);
      case DressTemplate.womenBlazer:
        return img.ColorRgb8(8, 8, 10);
      case DressTemplate.whiteShirt:
        return img.ColorRgb8(224, 226, 230);
      case DressTemplate.none:
        return img.ColorRgb8(0, 0, 0);
    }
  }
}
