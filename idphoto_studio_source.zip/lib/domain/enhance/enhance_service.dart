import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;

/// 色彩优化预设。
enum EnhancementPreset {
  natural('自然'),
  bright('明亮'),
  soft('柔和'),
  formal('正式'),
  hd('高清');

  const EnhancementPreset(this.label);

  final String label;
}

/// 色彩优化参数（全部可调强度，默认中性）。
@immutable
class EnhancementParams {
  const EnhancementParams({
    this.whiteBalance = false,
    this.brightness = 0,
    this.contrast = 1.0,
    this.saturation = 1.0,
    this.warmth = 0,
    this.sharpen = 0,
    this.smooth = 0,
    this.denoise = 0,
    this.deOil = 0,
  });

  /// 自动白平衡（灰度世界）。
  final bool whiteBalance;

  /// 亮度 -100..100。
  final int brightness;

  /// 对比度 0.5..1.5。
  final double contrast;

  /// 饱和度 0..2。
  final double saturation;

  /// 色温 -100..100（>0 偏暖）。
  final int warmth;

  /// 锐化强度 0..100。
  final double sharpen;

  /// 磨皮强度 0..100。
  final double smooth;

  /// 降噪强度 0..100。
  final double denoise;

  /// 去油光强度 0..100。
  final double deOil;

  bool get isIdentity =>
      whiteBalance == false &&
      brightness == 0 &&
      contrast == 1.0 &&
      saturation == 1.0 &&
      warmth == 0 &&
      sharpen == 0 &&
      smooth == 0 &&
      denoise == 0 &&
      deOil == 0;

  EnhancementParams copyWith({
    bool? whiteBalance,
    int? brightness,
    double? contrast,
    double? saturation,
    int? warmth,
    double? sharpen,
    double? smooth,
    double? denoise,
    double? deOil,
  }) {
    return EnhancementParams(
      whiteBalance: whiteBalance ?? this.whiteBalance,
      brightness: brightness ?? this.brightness,
      contrast: contrast ?? this.contrast,
      saturation: saturation ?? this.saturation,
      warmth: warmth ?? this.warmth,
      sharpen: sharpen ?? this.sharpen,
      smooth: smooth ?? this.smooth,
      denoise: denoise ?? this.denoise,
      deOil: deOil ?? this.deOil,
    );
  }

  /// 预设参数。
  static EnhancementParams ofPreset(EnhancementPreset preset) {
    switch (preset) {
      case EnhancementPreset.natural:
        return const EnhancementParams(
          whiteBalance: true,
          contrast: 1.05,
          saturation: 1.0,
        );
      case EnhancementPreset.bright:
        return const EnhancementParams(
          whiteBalance: true,
          brightness: 15,
          contrast: 1.1,
          saturation: 1.1,
        );
      case EnhancementPreset.soft:
        return const EnhancementParams(
          whiteBalance: true,
          saturation: 0.9,
          smooth: 30,
        );
      case EnhancementPreset.formal:
        return const EnhancementParams(
          whiteBalance: true,
          contrast: 1.15,
          saturation: 0.95,
          sharpen: 30,
        );
      case EnhancementPreset.hd:
        return const EnhancementParams(
          whiteBalance: true,
          contrast: 1.08,
          saturation: 1.05,
          sharpen: 50,
          denoise: 20,
        );
    }
  }
}

/// 色彩优化服务（纯 Dart，基于 image 库，可单测）。
class ColorEnhanceService {
  const ColorEnhanceService();

  /// 应用全部增强，返回新图。
  img.Image enhance(img.Image source, EnhancementParams p) {
    if (p.isIdentity) return img.Image.from(source);
    var image = img.Image.from(source);

    if (p.whiteBalance) {
      image = _autoWhiteBalance(image);
    }
    if (p.warmth != 0) {
      image = _warmth(image, p.warmth);
    }
    if (p.brightness != 0 || p.contrast != 1.0 || p.saturation != 1.0) {
      // image 库 brightness 为乘法标量：1.0 不变，>1 更亮。
      image = img.adjustColor(
        image,
        brightness: 1 + p.brightness / 100,
        contrast: p.contrast,
        saturation: p.saturation,
      );
    }
    if (p.denoise > 0) {
      image = _denoise(image, p.denoise);
    }
    if (p.deOil > 0) {
      image = _deOil(image, p.deOil);
    }
    if (p.smooth > 0) {
      image = _smooth(image, p.smooth);
    }
    if (p.sharpen > 0) {
      image = _sharpen(image, p.sharpen);
    }
    return image;
  }

  /// 灰度世界白平衡。
  img.Image _autoWhiteBalance(img.Image src) {
    final out = img.Image.from(src);
    var sumR = 0.0, sumG = 0.0, sumB = 0.0;
    final n = src.width * src.height;
    final step = math.max(1, n ~/ 40000); // 抽样避免全图遍历慢
    var count = 0;
    for (var i = 0; i < n; i += step) {
      final x = i % src.width;
      final y = i ~/ src.width;
      final c = src.getPixel(x, y);
      sumR += c.r.toInt();
      sumG += c.g.toInt();
      sumB += c.b.toInt();
      count++;
    }
    if (count == 0) return out;
    final mr = sumR / count, mg = sumG / count, mb = sumB / count;
    final avg = (mr + mg + mb) / 3;
    if (avg < 1) return out;
    final fr = avg / mr, fg = avg / mg, fb = avg / mb;
    // 限制增益范围，避免过激。
    double clampF(double f) => f.clamp(0.6, 1.6);
    final cr = clampF(fr), cg = clampF(fg), cb = clampF(fb);
    for (var y = 0; y < src.height; y++) {
      for (var x = 0; x < src.width; x++) {
        final c = src.getPixel(x, y);
        out.setPixelRgb(
          x,
          y,
          (c.r.toInt() * cr).round().clamp(0, 255),
          (c.g.toInt() * cg).round().clamp(0, 255),
          (c.b.toInt() * cb).round().clamp(0, 255),
        );
      }
    }
    return out;
  }

  /// 色温：>0 偏暖（R 升 B 降），<0 偏冷。
  img.Image _warmth(img.Image src, int warmth) {
    final t = warmth / 100.0;
    final out = img.Image.from(src);
    for (var y = 0; y < src.height; y++) {
      for (var x = 0; x < src.width; x++) {
        final c = src.getPixel(x, y);
        final r = (c.r.toInt() + 40 * t).round().clamp(0, 255);
        final b = (c.b.toInt() - 40 * t).round().clamp(0, 255);
        out.setPixelRgb(x, y, r, c.g.toInt(), b);
      }
    }
    return out;
  }

  /// 降噪：轻度中值/高斯混合。用高斯模糊与原图按强度混合。
  img.Image _denoise(img.Image src, double strength) {
    final sigma = 0.5 + strength / 100 * 1.5;
    final radius = math.max(1, sigma.round());

    final blurred = img.gaussianBlur(src, radius: radius);
    final k = (strength / 100 * 0.8).clamp(0.0, 0.8);
    return _blend(src, blurred, k);
  }

  /// 去油光：高光像素压暗。
  img.Image _deOil(img.Image src, double strength) {
    final k = strength / 100;
    final out = img.Image.from(src);
    const thr = 180;
    for (var y = 0; y < src.height; y++) {
      for (var x = 0; x < src.width; x++) {
        final c = src.getPixel(x, y);
        final lum = (c.r.toInt() * 0.3 + c.g.toInt() * 0.59 + c.b.toInt() * 0.11);
        if (lum > thr) {
          final f = 1 - (lum - thr) / 75 * k * 0.5;
          out.setPixelRgb(
            x,
            y,
            (c.r.toInt() * f).round().clamp(0, 255),
            (c.g.toInt() * f).round().clamp(0, 255),
            (c.b.toInt() * f).round().clamp(0, 255),
          );
        }
      }
    }
    return out;
  }

  /// 磨皮：与原图做轻度混合（保留细节），强度越大越柔。
  img.Image _smooth(img.Image src, double strength) {
    const radius = 2;
    final blurred = img.gaussianBlur(src, radius: radius);
    final k = (strength / 100 * 0.5).clamp(0.0, 0.5);
    return _blend(src, blurred, k);
  }

  /// 锐化：Unsharp Mask。
  img.Image _sharpen(img.Image src, double strength) {
    final blurred = img.gaussianBlur(src, radius: 1);
    final k = (strength / 100 * 1.2).clamp(0.0, 1.2);
    final out = img.Image.from(src);
    for (var y = 0; y < src.height; y++) {
      for (var x = 0; x < src.width; x++) {
        final c = src.getPixel(x, y);
        final b = blurred.getPixel(x, y);
        final r = (c.r.toInt() + (c.r.toInt() - b.r.toInt()) * k)
            .round()
            .clamp(0, 255);
        final g = (c.g.toInt() + (c.g.toInt() - b.g.toInt()) * k)
            .round()
            .clamp(0, 255);
        final bl = (c.b.toInt() + (c.b.toInt() - b.b.toInt()) * k)
            .round()
            .clamp(0, 255);
        out.setPixelRgb(x, y, r, g, bl);
      }
    }
    return out;
  }

  img.Image _blend(img.Image a, img.Image b, double k) {
    final out = img.Image.from(a);
    for (var y = 0; y < a.height; y++) {
      for (var x = 0; x < a.width; x++) {
        final ca = a.getPixel(x, y);
        final cb = b.getPixel(x, y);
        out.setPixelRgb(
          x,
          y,
          (ca.r.toInt() * (1 - k) + cb.r.toInt() * k).round().clamp(0, 255),
          (ca.g.toInt() * (1 - k) + cb.g.toInt() * k).round().clamp(0, 255),
          (ca.b.toInt() * (1 - k) + cb.b.toInt() * k).round().clamp(0, 255),
        );
      }
    }
    return out;
  }
}

/// 缩略用工具：把图缩到目标长边并返回字节。
Uint8List encodePreview(img.Image source, {int maxSide = 480, int quality = 80}) {
  final side = math.max(source.width, source.height);
  if (side > maxSide) {
    final f = maxSide / side;
    final resized = img.copyResize(source,
        width: (source.width * f).round(),
        height: (source.height * f).round(),
        interpolation: img.Interpolation.linear);
    return Uint8List.fromList(img.encodeJpg(resized, quality: quality));
  }
  return Uint8List.fromList(img.encodeJpg(source, quality: quality));
}
