import 'dart:io';
import 'dart:typed_data';

import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:pdf/pdf.dart';
import 'package:pdf/widgets.dart' as pw;

import '../export/export_service.dart';
import '../layout/print_layout.dart';

/// 排版导出选项。
class PrintExportOptions {
  const PrintExportOptions({
    this.showCutMarks = true,
    this.showBleed = false,
    this.showNumbering = true,
    this.showDate = true,
    this.dateText,
    this.bleedMm = 2,
    this.cutMarkLengthMm = 5,
    this.cutMarkGapMm = 3,
  });

  /// 裁剪线（四角毫米刻度线）。
  final bool showCutMarks;

  /// 出血线（照片外扩虚线框）。
  final bool showBleed;

  /// 每张照片编号（1、2、3…）。
  final bool showNumbering;

  /// 纸张日期。
  final bool showDate;

  /// 日期文本（默认 yyyy-MM-dd）。
  final String? dateText;

  final double bleedMm;
  final double cutMarkLengthMm;
  final double cutMarkGapMm;

  PrintExportOptions copyWith({
    bool? showCutMarks,
    bool? showBleed,
    bool? showNumbering,
    bool? showDate,
    String? dateText,
  }) {
    return PrintExportOptions(
      showCutMarks: showCutMarks ?? this.showCutMarks,
      showBleed: showBleed ?? this.showBleed,
      showNumbering: showNumbering ?? this.showNumbering,
      showDate: showDate ?? this.showDate,
      dateText: dateText ?? this.dateText,
      bleedMm: bleedMm,
      cutMarkLengthMm: cutMarkLengthMm,
      cutMarkGapMm: cutMarkGapMm,
    );
  }
}

/// 排版图/PDF 导出服务。
class PrintExportService {
  PrintExportService();

  Future<Directory> _exportDir() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('${docs.path}${Platform.pathSeparator}prints');
    if (!dir.existsSync()) dir.createSync(recursive: true);
    return dir;
  }

  /// 导出排版图（JPG/PNG，300DPI）。
  ///
  /// [photos]：多张照片时按格顺序循环铺排（不同照片排到同一页）；
  /// 为空时全部格子用 [photo]。
  Future<ExportResultItem> exportPrintSheet(
    img.Image photo,
    PrintLayout layout, {
    List<img.Image> photos = const [],
    ExportFormat format = ExportFormat.jpg,
    int jpgQuality = 92,
    PrintExportOptions options = const PrintExportOptions(),
    String? customName,
    DateTime? timestamp,
  }) async {
    final sheet = _renderSheet(photo, layout, options, photos: photos);
    final Uint8List bytes;
    final String ext;
    switch (format) {
      case ExportFormat.jpg:
        bytes = Uint8List.fromList(img.encodeJpg(sheet, quality: jpgQuality));
        ext = 'jpg';
      case ExportFormat.png:
      case ExportFormat.transparentPng:
        bytes = Uint8List.fromList(img.encodePng(sheet));
        ext = 'png';
    }

    final dir = await _exportDir();
    final ts = timestamp ?? DateTime.now();
    final name = customName ??
        '排版_${layout.paper.name}_${ts.year}${_two(ts.month)}${_two(ts.day)}_${_two(ts.hour)}${_two(ts.minute)}${_two(ts.second)}';
    final file = File('${dir.path}${Platform.pathSeparator}$name.$ext');
    await file.writeAsBytes(bytes, flush: true);
    return ExportResultItem(
      path: file.path,
      fileName: '$name.$ext',
      sizeBytes: bytes.length,
      width: sheet.width,
      height: sheet.height,
    );
  }

  /// 导出排版 PDF（矢量页面，300DPI 尺寸）。
  Future<ExportResultItem> exportPrintPdf(
    img.Image photo,
    PrintLayout layout, {
    List<img.Image> photos = const [],
    PrintExportOptions options = const PrintExportOptions(),
    String? customName,
    DateTime? timestamp,
  }) async {
    final doc = await _renderPdf(photo, layout, options, photos: photos);
    final bytes = await doc.save();
    final dir = await _exportDir();
    final ts = timestamp ?? DateTime.now();
    final name = customName ??
        '排版_${layout.paper.name}_${ts.year}${_two(ts.month)}${_two(ts.day)}_${_two(ts.hour)}${_two(ts.minute)}${_two(ts.second)}';
    final file = File('${dir.path}${Platform.pathSeparator}$name.pdf');
    await file.writeAsBytes(bytes, flush: true);
    return ExportResultItem(
      path: file.path,
      fileName: '$name.pdf',
      sizeBytes: bytes.length,
      width: layout.paper.pixelWidth,
      height: layout.paper.pixelHeight,
    );
  }

  /// ---- 渲染：排版位图 ----

  img.Image _renderSheet(
    img.Image photo,
    PrintLayout layout,
    PrintExportOptions options, {
    List<img.Image> photos = const [],
  }) {
    final paper = layout.paper;
    final sheet = img.Image(
      width: paper.pixelWidth,
      height: paper.pixelHeight,
      numChannels: 3,
    );
    img.fill(sheet, color: img.ColorRgb8(255, 255, 255));

    final dateText = options.dateText ?? _todayText();
    final pool = photos.isEmpty ? [photo] : photos;
    for (final page in layout.pages) {
      for (final cell in page.cells) {
        _drawCell(sheet, pool[(cell.index - 1) % pool.length], layout, cell, options);
      }
    }
    if (options.showDate && dateText.isNotEmpty) {
      img.drawString(
        sheet,
        dateText,
        font: img.arial14,
        x: paper.pixelWidth - 10 - dateText.length * 8,
        y: paper.pixelHeight - 24,
        color: img.ColorRgb8(120, 120, 120),
      );
    }
    return sheet;
  }

  void _drawCell(
    img.Image sheet,
    img.Image photo,
    PrintLayout layout,
    PrintCell cell,
    PrintExportOptions options,
  ) {
    final paper = layout.paper;
    final dpi = paper.dpi;
    double px(double mm) => mm / 25.4 * dpi;

    final x0 = px(cell.xMm).round();
    final y0 = px(cell.yMm).round();
    final w = px(cell.widthMm).round();
    final h = px(cell.heightMm).round();

    // 照片（拉伸铺满，比例与规格一致）。
    final fitted = img.copyResize(photo,
        width: w, height: h, interpolation: img.Interpolation.linear);
    img.compositeImage(sheet, fitted, dstX: x0, dstY: y0);

    final dark = img.ColorRgb8(60, 60, 60);
    final gray = img.ColorRgb8(160, 160, 160);

    // 出血线：外扩虚线框。
    if (options.showBleed) {
      final b = px(options.bleedMm).round();
      _drawDashedRect(
        sheet,
        x0 - b,
        y0 - b,
        w + 2 * b,
        h + 2 * b,
        gray,
        dash: 6,
      );
    }

    // 裁剪线：四角毫米刻度线。
    if (options.showCutMarks) {
      final len = px(options.cutMarkLengthMm).round();
      final gap = px(options.cutMarkGapMm).round();
      final x1 = x0 - gap, x2 = x0 + w + gap;
      final y1 = y0 - gap, y2 = y0 + h + gap;
      // 四角各两条线。
      _vLine(sheet, x1, y1 - len, y1, dark);
      _hLine(sheet, x1 - len, x1, y1, dark);
      _vLine(sheet, x2, y1 - len, y1, dark);
      _hLine(sheet, x2, x2 + len, y1, dark);
      _vLine(sheet, x1, y2, y2 + len, dark);
      _hLine(sheet, x1 - len, x1, y2, dark);
      _vLine(sheet, x2, y2, y2 + len, dark);
      _hLine(sheet, x2, x2 + len, y2, dark);
    }

    // 编号：左下角内侧。
    if (options.showNumbering) {
      img.drawString(
        sheet,
        '${cell.index}',
        font: img.arial24,
        x: x0 + 4,
        y: y0 + h - 30,
        color: dark,
      );
    }
  }

  void _vLine(img.Image im, int x, int y1, int y2, img.Color c) {
    for (var y = y1; y <= y2; y++) {
      if (x >= 0 && x < im.width && y >= 0 && y < im.height) {
        im.setPixel(x, y, c);
      }
    }
  }

  void _hLine(img.Image im, int x1, int x2, int y, img.Color c) {
    for (var x = x1; x <= x2; x++) {
      if (x >= 0 && x < im.width && y >= 0 && y < im.height) {
        im.setPixel(x, y, c);
      }
    }
  }

  void _drawDashedRect(
    img.Image im,
    int x,
    int y,
    int w,
    int h,
    img.Color c, {
    int dash = 6,
  }) {
    void dashH(int y1, int x1, int x2) {
      var on = true;
      for (var xx = x1; xx <= x2; xx += 2) {
        if (on) _hLine(im, xx, (xx + dash).clamp(0, x2), y1, c);
        on = !on;
      }
    }

    void dashV(int x1, int y1, int y2) {
      var on = true;
      for (var yy = y1; yy <= y2; yy += 2) {
        if (on) _vLine(im, x1, yy, (yy + dash).clamp(0, y2), c);
        on = !on;
      }
    }

    dashH(y, x, x + w);
    dashH(y + h, x, x + w);
    dashV(x, y, y + h);
    dashV(x + w, y, y + h);
  }

  /// ---- 渲染：PDF ----

  Future<pw.Document> _renderPdf(
    img.Image photo,
    PrintLayout layout,
    PrintExportOptions options, {
    List<img.Image> photos = const [],
  }) async {
    final doc = pw.Document();
    final paper = layout.paper;
    final dateText = options.dateText ?? _todayText();
    final pool = photos.isEmpty ? [photo] : photos;

    for (final page in layout.pages) {
      doc.addPage(
        pw.Page(
          pageFormat: PdfPageFormat(
            paper.widthMm * PdfPageFormat.mm,
            paper.heightMm * PdfPageFormat.mm,
          ),
          margin: pw.EdgeInsets.zero,
          build: (ctx) {
            final children = <pw.Widget>[];
            for (final cell in page.cells) {
              children.addAll(_pdfCell(pool[(cell.index - 1) % pool.length], layout, cell, options));
            }
            if (options.showDate && dateText.isNotEmpty) {
              children.add(pw.Positioned(
                left: paper.widthMm - 12 - dateText.length * 2.6,
                bottom: 4,
                child: pw.Text(
                  dateText,
                  style: const pw.TextStyle(
                    fontSize: 7,
                    color: PdfColors.grey600,
                  ),
                ),
              ));
            }
            return pw.Stack(children: children);
          },
        ),
      );
    }
    return doc;
  }

  List<pw.Widget> _pdfCell(
    img.Image photo,
    PrintLayout layout,
    PrintCell cell,
    PrintExportOptions options,
  ) {
    final out = <pw.Widget>[];
    final photoPng = img.encodePng(photo);
    out.add(pw.Positioned(
      left: cell.xMm,
      top: cell.yMm,
      child: pw.SizedBox(
        width: cell.widthMm,
        height: cell.heightMm,
        child: pw.Image(pw.MemoryImage(Uint8List.fromList(photoPng)),
            fit: pw.BoxFit.fill),
      ),
    ));

    const line = pw.BorderSide(
      color: PdfColors.grey700,
      width: 0.3,
    );
    final bleed = options.bleedMm;
    // 出血线：外扩虚线框（用四边细线近似虚线）。
    if (options.showBleed) {
      out.add(pw.Positioned(
        left: cell.xMm - bleed,
        top: cell.yMm - bleed,
        child: pw.SizedBox(
          width: cell.widthMm + 2 * bleed,
          height: cell.heightMm + 2 * bleed,
          child: pw.Container(
            decoration: pw.BoxDecoration(
              border: pw.Border.all(
                color: PdfColors.grey400,
                width: 0.25,
              ),
            ),
          ),
        ),
      ));
    }

    // 裁剪线：四角。
    if (options.showCutMarks) {
      final gap = options.cutMarkGapMm;
      final len = options.cutMarkLengthMm;
      final x1 = cell.xMm - gap, x2 = cell.xMm + cell.widthMm + gap;
      final y1 = cell.yMm - gap, y2 = cell.yMm + cell.heightMm + gap;
      void mark(double mx, double my, double mw, double mh) {
        out.add(pw.Positioned(
          left: mx,
          top: my,
          child: pw.Container(
            width: mw,
            height: mh,
            decoration: pw.BoxDecoration(
              border: pw.Border(
                left: mw <= mh ? line : pw.BorderSide.none,
                top: mh <= mw ? line : pw.BorderSide.none,
              ),
            ),
          ),
        ));
      }

      mark(x1, y1 - len, 0.3, len);
      mark(x1 - len, y1, len, 0.3);
      mark(x2, y1 - len, 0.3, len);
      mark(x2, y1, len, 0.3);
      mark(x1, y2, 0.3, len);
      mark(x1 - len, y2, len, 0.3);
      mark(x2, y2, 0.3, len);
      mark(x2, y2, len, 0.3);
    }

    if (options.showNumbering) {
      out.add(pw.Positioned(
        left: cell.xMm + 2,
        bottom: layout.paper.heightMm - cell.yMm - cell.heightMm + 4,
        child: pw.Text(
          '${cell.index}',
          style: const pw.TextStyle(fontSize: 8, color: PdfColors.grey700),
        ),
      ));
    }
    return out;
  }

  static String _two(int n) => n.toString().padLeft(2, '0');

  static String _todayText() {
    final now = DateTime.now();
    return '${now.year}-${_two(now.month)}-${_two(now.day)}';
  }
}
