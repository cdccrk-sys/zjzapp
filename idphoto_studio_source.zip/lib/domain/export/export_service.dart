import 'dart:io';
import 'dart:typed_data';

import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';
import 'package:share_plus/share_plus.dart';

import '../crop/crop_service.dart';
import '../specs/idphoto_specs.dart';

/// 导出格式。
enum ExportFormat {
  jpg,
  png,
  transparentPng,
}

/// 导出结果项。
class ExportResultItem {
  const ExportResultItem({
    required this.path,
    required this.fileName,
    required this.sizeBytes,
    required this.width,
    required this.height,
  });

  final String path;
  final String fileName;
  final int sizeBytes;
  final int width;
  final int height;
}

/// 导出服务：裁剪图编码、保存到应用文档目录、分享。
class ExportService {
  ExportService();

  /// 导出目录（应用文档目录/exports）。
  Future<Directory> exportDirectory() async {
    final docs = await getApplicationDocumentsDirectory();
    final dir = Directory('${docs.path}${Platform.pathSeparator}exports');
    if (!dir.existsSync()) dir.createSync(recursive: true);
    return dir;
  }

  /// 裁剪 + 编码 + 保存单张证件照。
  ///
  /// [source] 源图；[rect] 裁剪框（源图像素坐标）；
  /// [spec] 目标规格（决定输出像素尺寸）。
  Future<ExportResultItem> exportOne(
    img.Image source,
    CropRect rect,
    IdPhotoSpec spec, {
    ExportFormat format = ExportFormat.jpg,
    int jpgQuality = 92,
    String? customName,
    DateTime? timestamp,
  }) async {
    final cropped = img.copyCrop(source,
        x: rect.x, y: rect.y, width: rect.width, height: rect.height);
    final resized = img.copyResize(
      cropped,
      width: spec.pixelWidth,
      height: spec.pixelHeight,
      interpolation: img.Interpolation.linear,
    );

    final Uint8List bytes;
    final String ext;
    switch (format) {
      case ExportFormat.jpg:
        bytes = Uint8List.fromList(img.encodeJpg(resized, quality: jpgQuality));
        ext = 'jpg';
      case ExportFormat.png:
        bytes = Uint8List.fromList(img.encodePng(resized));
        ext = 'png';
      case ExportFormat.transparentPng:
        bytes = Uint8List.fromList(img.encodePng(resized));
        ext = 'png';
    }

    final dir = await exportDirectory();
    final ts = timestamp ?? DateTime.now();
    final name = customName ??
        '${spec.name}_${ts.year}${_two(ts.month)}${_two(ts.day)}_${_two(ts.hour)}${_two(ts.minute)}${_two(ts.second)}';
    final file = File('${dir.path}${Platform.pathSeparator}$name.$ext');
    await file.writeAsBytes(bytes, flush: true);

    return ExportResultItem(
      path: file.path,
      fileName: '$name.$ext',
      sizeBytes: bytes.length,
      width: resized.width,
      height: resized.height,
    );
  }

  /// 批量导出。
  Future<List<ExportResultItem>> exportMany(
    List<({img.Image source, CropRect rect, IdPhotoSpec spec})> jobs, {
    ExportFormat format = ExportFormat.jpg,
    int jpgQuality = 92,
  }) async {
    final results = <ExportResultItem>[];
    for (var i = 0; i < jobs.length; i++) {
      final j = jobs[i];
      results.add(await exportOne(
        j.source,
        j.rect,
        j.spec,
        format: format,
        jpgQuality: jpgQuality,
        customName: '${j.spec.name}_${i + 1}',
      ));
    }
    return results;
  }

  /// 分享文件（系统分享面板）。
  Future<void> share(List<ExportResultItem> items, {String? text}) async {
    final files = items.map((e) => XFile(e.path)).toList();
    await Share.shareXFiles(files, text: text ?? '证件照');
  }

  static String _two(int n) => n.toString().padLeft(2, '0');
}
