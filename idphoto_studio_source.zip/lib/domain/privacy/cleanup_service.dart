import 'dart:io';

import 'package:path/path.dart' as p;
import 'package:path_provider/path_provider.dart';

/// 隐私清理服务：清除导出缓存目录（exports/、prints/）。
///
/// 仅删除应用自身产生的导出文件，不影响用户系统相册与原始照片。
class CleanupService {
  const CleanupService();

  /// 删除导出缓存，返回删除的文件数。
  ///
  /// [docsPath] 仅供测试注入文档目录；生产环境使用系统文档目录。
  Future<int> clearExportCache({String? docsPath}) async {
    final docs = docsPath == null
        ? await getApplicationDocumentsDirectory()
        : Directory(docsPath);
    var removed = 0;
    for (final dirName in const ['exports', 'prints']) {
      final dir = Directory(p.join(docs.path, dirName));
      if (!await dir.exists()) continue;
      await for (final entity in dir.list(recursive: true)) {
        try {
          if (entity is File) {
            await entity.delete();
            removed++;
          }
        } catch (_) {
          // 跳过占用中的文件。
        }
      }
    }
    return removed;
  }
}
