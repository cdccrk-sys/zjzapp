import 'dart:math' as math;

/// 相纸规格（毫米）。
class PaperSpec {
  const PaperSpec({
    required this.id,
    required this.name,
    required this.widthMm,
    required this.heightMm,
    this.dpi = 300,
  });

  final String id;
  final String name;
  final double widthMm;
  final double heightMm;

  /// 输出 DPI（冲印标准 300）。
  final int dpi;

  int get pixelWidth => (widthMm / 25.4 * dpi).round();
  int get pixelHeight => (heightMm / 25.4 * dpi).round();

  /// 是否横放使用（宽≥高）。
  bool get isLandscape => widthMm >= heightMm;

  /// 内置相纸规格：5 寸 / 6 寸 / 7 寸 / A4。
  static const List<PaperSpec> builtin = [
    PaperSpec(
      id: 'photo5',
      name: '5 寸',
      widthMm: 127,
      heightMm: 89,
      dpi: 300,
    ),
    PaperSpec(
      id: 'photo6',
      name: '6 寸',
      widthMm: 152,
      heightMm: 102,
      dpi: 300,
    ),
    PaperSpec(
      id: 'photo7',
      name: '7 寸',
      widthMm: 178,
      heightMm: 127,
      dpi: 300,
    ),
    PaperSpec(
      id: 'a4',
      name: 'A4',
      widthMm: 210,
      heightMm: 297,
      dpi: 300,
    ),
  ];

  static PaperSpec? byId(String id) {
    for (final s in builtin) {
      if (s.id == id) return s;
    }
    return null;
  }
}

/// 证件照排版方向（相对相纸）。
enum PrintOrientation { portrait, landscape }

/// 排版结果：单格位置（毫米，相对纸张左上角）。
class PrintCell {
  const PrintCell({
    required this.xMm,
    required this.yMm,
    required this.widthMm,
    required this.heightMm,
    required this.index,
  });

  final double xMm;
  final double yMm;
  final double widthMm;
  final double heightMm;

  /// 全局序号（从 1 开始）。
  final int index;
}

/// 单页排版。
class PrintLayoutPage {
  const PrintLayoutPage({required this.pageIndex, required this.cells});

  final int pageIndex;
  final List<PrintCell> cells;
}

/// 整体排版结果。
class PrintLayout {
  const PrintLayout({
    required this.paper,
    required this.photoWidthMm,
    required this.photoHeightMm,
    required this.cols,
    required this.rows,
    required this.gapMm,
    required this.marginMm,
    required this.pages,
    required this.perPage,
  });

  final PaperSpec paper;
  final double photoWidthMm;
  final double photoHeightMm;
  final int cols;
  final int rows;
  final double gapMm;
  final double marginMm;
  final List<PrintLayoutPage> pages;

  /// 每页可排张数。
  final int perPage;

  /// 总张数（所有页）。
  int get total => pages.fold(0, (sum, p) => sum + p.cells.length);
}

/// 排版算法：在相纸上按网格铺满证件照。
class LayoutService {
  const LayoutService();

  /// 计算排版。
  ///
  /// [photoWidthMm]/[photoHeightMm]：证件照毫米尺寸；
  /// [count]：需要排版的总张数（不足一页则一页排 count 张，
  /// 超过一页则每页铺满、最后不足铺满也生成）。
  /// [gapMm]：照片间距；[marginMm]：纸边距。
  PrintLayout layout(
    PaperSpec paper,
    double photoWidthMm,
    double photoHeightMm, {
    int count = 8,
    double gapMm = 2,
    double marginMm = 8,
  }) {
    // 自动选择可容纳最多的方向（横排/竖排）。
    final layout = _gridFor(paper, photoWidthMm, photoHeightMm, gapMm, marginMm);
    final perPage = layout.$1 * layout.$2;
    final totalCount = math.max(1, count);
    final pageCount = (totalCount + perPage - 1) ~/ perPage;

    final pages = <PrintLayoutPage>[];
    var idx = 0;
    for (var p = 0; p < pageCount; p++) {
      final cells = <PrintCell>[];
      final onPage = math.min(perPage, totalCount - p * perPage);
      for (var c = 0; c < onPage; c++) {
        idx++;
        final col = c % layout.$1;
        final row = c ~/ layout.$1;
        cells.add(_cellAt(
          paper: paper,
          photoWidthMm: photoWidthMm,
          photoHeightMm: photoHeightMm,
          cols: layout.$1,
          rows: layout.$2,
          gapMm: gapMm,
          marginMm: marginMm,
          col: col,
          row: row,
          index: idx,
        ));
      }
      pages.add(PrintLayoutPage(pageIndex: p + 1, cells: cells));
    }

    return PrintLayout(
      paper: paper,
      photoWidthMm: photoWidthMm,
      photoHeightMm: photoHeightMm,
      cols: layout.$1,
      rows: layout.$2,
      gapMm: gapMm,
      marginMm: marginMm,
      pages: pages,
      perPage: perPage,
    );
  }

  (int, int) _gridFor(
    PaperSpec paper,
    double pw,
    double ph,
    double gap,
    double margin,
  ) {
    // 竖排：照片竖放（高>宽）。
    final colsV = _cols(paper.widthMm, pw, gap, margin);
    final rowsV = _cols(paper.heightMm, ph, gap, margin);
    // 横排：照片旋转 90°（宽=高、高=宽）。
    final colsH = _cols(paper.widthMm, ph, gap, margin);
    final rowsH = _cols(paper.heightMm, pw, gap, margin);
    if (colsV * rowsV >= colsH * rowsH) {
      return (math.max(1, colsV), math.max(1, rowsV));
    }
    return (math.max(1, colsH), math.max(1, rowsH));
  }

  int _cols(double paperSide, double photoSide, double gap, double margin) {
    if (photoSide <= 0) return 1;
    final usable = paperSide - 2 * margin;
    if (usable <= 0) return 1;
    return ((usable + gap) / (photoSide + gap)).floor();
  }

  PrintCell _cellAt({
    required PaperSpec paper,
    required double photoWidthMm,
    required double photoHeightMm,
    required int cols,
    required int rows,
    required double gapMm,
    required double marginMm,
    required int col,
    required int row,
    required int index,
  }) {
    final contentW = cols * photoWidthMm + (cols - 1) * gapMm;
    final contentH = rows * photoHeightMm + (rows - 1) * gapMm;
    final startX = (paper.widthMm - contentW) / 2;
    final startY = (paper.heightMm - contentH) / 2;
    return PrintCell(
      xMm: startX + col * (photoWidthMm + gapMm),
      yMm: startY + row * (photoHeightMm + gapMm),
      widthMm: photoWidthMm,
      heightMm: photoHeightMm,
      index: index,
    );
  }
}
