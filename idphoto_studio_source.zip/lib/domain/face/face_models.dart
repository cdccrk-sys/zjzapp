/// 人脸分析与自动矫正的领域模型。
///
/// 本文件只定义数据结构与纯计算逻辑（不依赖任何视觉 SDK），
/// 视觉能力由 [FaceAnalyzer] 实现（见 face_analyzer.dart），
/// 平台实现见 mediapipe_face_analyzer.dart。
library;

import 'dart:math';

/// 归一化关键点（坐标 0..1，相对图像宽高）。
class FacePoint {
  const FacePoint(this.x, this.y, {this.visibility = 1.0});

  final double x;
  final double y;

  /// 可见度 0..1（来自姿态模型；无遮挡信息时为 1.0）。
  final double visibility;
}

/// 两点欧氏距离（归一化坐标）。
double distance2d(FacePoint a, FacePoint b) {
  final dx = a.x - b.x;
  final dy = a.y - b.y;
  return sqrt(dx * dx + dy * dy);
}

/// 基于几何不对称判定侧脸：|鼻子−左眼| 与 |鼻子−右眼| 的差 / 眼距。
bool isSideFaceByGeometry({
  required FacePoint leftEye,
  required FacePoint rightEye,
  required FacePoint nose,
}) {
  final eyeDist = distance2d(leftEye, rightEye);
  if (eyeDist < 1e-6) return false;
  final dLeft = distance2d(nose, leftEye);
  final dRight = distance2d(nose, rightEye);
  return (dLeft - dRight).abs() / eyeDist > kSideFaceAsymmetryRatio;
}

/// 眼睛闭合判定（blendshape 系数，0..1）。
bool isEyesClosed(double blinkLeft, double blinkRight) {
  return blinkLeft > kEyeClosedThreshold || blinkRight > kEyeClosedThreshold;
}

/// 归一化矩形（0..1，相对图像宽高）。
class NormalizedRect {
  const NormalizedRect({
    required this.left,
    required this.top,
    required this.right,
    required this.bottom,
  });

  final double left;
  final double top;
  final double right;
  final double bottom;

  double get width => right - left;
  double get height => bottom - top;
  double get centerX => (left + right) / 2;
  double get centerY => (top + bottom) / 2;
}

/// 质量提示类型。
enum FaceIssueType {
  /// 未检测到人脸。
  noFace,

  /// 检测到多张人脸。
  multipleFaces,

  /// 侧脸角度过大。
  sideFace,

  /// 遮挡（如闭眼）。
  occluded,

  /// 图像模糊。
  blurry,

  /// 头部倾斜较大。
  tilted,
}

/// 单条质量提示。
class FaceIssue {
  const FaceIssue(this.type, this.message);

  final FaceIssueType type;
  final String message;
}

/// 单张人脸的分析结果。
class FaceInfo {
  const FaceInfo({
    required this.boundingBox,
    required this.leftEye,
    required this.rightEye,
    required this.nose,
    required this.chin,
    this.yawDegrees,
    this.pitchDegrees,
    this.rollDegrees,
    this.eyeBlinkLeft = 0,
    this.eyeBlinkRight = 0,
    this.leftShoulder,
    this.rightShoulder,
  });

  /// 人脸框（归一化）。
  final NormalizedRect boundingBox;

  /// 左眼/右眼外角、鼻尖、下巴（归一化）。
  final FacePoint leftEye;
  final FacePoint rightEye;
  final FacePoint nose;
  final FacePoint chin;

  /// 头部姿态角（度）。来自 3D 姿态估计，可能为 null。
  final double? yawDegrees;
  final double? pitchDegrees;
  final double? rollDegrees;

  /// 眼睛闭合系数 0..1（1 为完全闭合）。无遮挡模型时为 0。
  final double eyeBlinkLeft;
  final double eyeBlinkRight;

  /// 左右肩关键点（归一化）。由姿态模型提供，M2 里程碑接入。
  final FacePoint? leftShoulder;
  final FacePoint? rightShoulder;
}

/// 一张图片的完整分析结果。
class FaceAnalysisResult {
  FaceAnalysisResult({
    required this.faces,
    required this.imageWidth,
    required this.imageHeight,
    required this.blurScore,
    this.analyzerUnavailableReason,
  }) : issues = _buildIssues(faces, blurScore);

  /// 检测到的人脸（按置信度降序）。
  final List<FaceInfo> faces;

  final int imageWidth;
  final int imageHeight;

  /// 模糊评分（Laplacian 方差，越大越清晰）。
  final double blurScore;

  /// 分析器不可用的原因（如平台原生库缺失）；null 表示分析正常。
  final String? analyzerUnavailableReason;

  /// 组合后的质量提示。
  final List<FaceIssue> issues;

  bool get analyzerAvailable => analyzerUnavailableReason == null;
  bool get hasFace => faces.isNotEmpty;

  /// 主脸（置信度最高）。
  FaceInfo? get primaryFace => faces.isEmpty ? null : faces.first;

  /// 是否包含某一类问题。
  bool hasIssue(FaceIssueType type) => issues.any((i) => i.type == type);

  static List<FaceIssue> _buildIssues(List<FaceInfo> faces, double blurScore) {
    final issues = <FaceIssue>[];
    if (faces.isEmpty) {
      issues.add(const FaceIssue(
        FaceIssueType.noFace,
        '未检测到人脸，请上传正面单人照片',
      ));
    } else {
      if (faces.length > 1) {
        issues.add(FaceIssue(
          FaceIssueType.multipleFaces,
          '检测到 ${faces.length} 张人脸，请选择单人照片',
        ));
      }
      final face = faces.first;
      // 侧脸：几何不对称 + 姿态偏航角双通道判断。
      if (isSideFaceByGeometry(
        leftEye: face.leftEye,
        rightEye: face.rightEye,
        nose: face.nose,
      )) {
        issues.add(const FaceIssue(
          FaceIssueType.sideFace,
          '侧脸角度较大，请正对镜头',
        ));
      } else if (face.yawDegrees != null && face.yawDegrees!.abs() > 25) {
        issues.add(const FaceIssue(
          FaceIssueType.sideFace,
          '侧脸角度较大，请正对镜头',
        ));
      }
      // 闭眼/遮挡。
      if (isEyesClosed(face.eyeBlinkLeft, face.eyeBlinkRight)) {
        issues.add(const FaceIssue(
          FaceIssueType.occluded,
          '眼睛闭合或遮挡，请睁开眼睛',
        ));
      }
      // 头部倾斜（可自动矫正，仅提示）。
      if (face.rollDegrees != null && face.rollDegrees!.abs() > 10) {
        issues.add(FaceIssue(
          FaceIssueType.tilted,
          '头部倾斜 ${face.rollDegrees!.round()}°，将自动水平矫正',
        ));
      }
    }
    if (blurScore < kBlurThreshold) {
      issues.add(FaceIssue(
        FaceIssueType.blurry,
        '照片模糊（清晰度评分 ${blurScore.toStringAsFixed(0)}，建议 ≥ $kBlurThreshold）',
      ));
    }
    return issues;
  }
}

/// 模糊评分阈值（Laplacian 方差）。
const double kBlurThreshold = 100;

/// 侧脸几何判定阈值：鼻子到两眼距离差 / 眼距。
const double kSideFaceAsymmetryRatio = 0.35;

/// 眼睛闭合判定阈值。
const double kEyeClosedThreshold = 0.8;
