/// 人脸几何与质量判定的纯计算逻辑（全部为纯函数，可独立单元测试）。
///
/// 坐标系约定：像素坐标 y 向下；"顺时针旋转图像"与 image 包
/// `copyRotate(angle: 正数)` 方向一致。
///
/// 几何判定（isSideFaceByGeometry / isEyesClosed / distance2d）定义在
/// face_models.dart，与阈值常量同库，供组装提示复用。
library;

import 'dart:math';
import 'dart:typed_data';

import 'package:image/image.dart' as img;

import 'face_models.dart';

/// 两点连线与水平线的夹角（度，y 向下坐标系）。
double lineAngleDegrees(FacePoint a, FacePoint b) {
  return atan2(b.y - a.y, b.x - a.x) * 180 / pi;
}

/// 使眼睛连线水平需要顺时针旋转图像的度数。
///
/// 推导：旋转图像 R 度（顺时针）等价于把线段旋转 R 度；线段原夹角为 α，
/// 需 α + R = 0，故 R = -α。
double computeEyeLevelRotation(FacePoint leftEye, FacePoint rightEye) {
  return -lineAngleDegrees(leftEye, rightEye);
}

/// 使肩膀连线水平需要顺时针旋转图像的度数（语义同上）。
double computeShoulderLevelRotation(FacePoint leftShoulder, FacePoint rightShoulder) {
  return -lineAngleDegrees(leftShoulder, rightShoulder);
}

/// 将归一化点绕图像中心顺时针旋转 [degrees] 度。
///
/// y 向下坐标系中，顺时针旋转 θ：`(dx,dy) → (dx·cosθ − dy·sinθ, dx·sinθ + dy·cosθ)`。
FacePoint rotatePointCw(
  FacePoint p,
  double degrees,
  double imageWidth,
  double imageHeight,
) {
  final rad = degrees * pi / 180;
  final cx = imageWidth / 2;
  final cy = imageHeight / 2;
  final dx = p.x - cx;
  final dy = p.y - cy;
  final nx = dx * cos(rad) - dy * sin(rad);
  final ny = dx * sin(rad) + dy * cos(rad);
  return FacePoint(nx + cx, ny + cy, visibility: p.visibility);
}

/// 头部中心（两眼 + 鼻尖的均值，归一化）。
FacePoint computeHeadCenter(FaceInfo face) {
  return FacePoint(
    (face.leftEye.x + face.rightEye.x + face.nose.x) / 3,
    (face.leftEye.y + face.rightEye.y + face.nose.y) / 3,
  );
}

/// 组合自动矫正计划：眼睛水平为主；肩膀信息可用时一并给出。
class CorrectionPlan {
  const CorrectionPlan({
    required this.rotationDegrees,
    this.shoulderRotationDegrees,
    required this.headCenter,
    required this.faceBox,
  });

  /// 使眼睛水平所需顺时针旋转度数（0 表示无需旋转）。
  final double rotationDegrees;

  /// 使肩膀水平所需度数；肩膀不可用时为 null。
  final double? shoulderRotationDegrees;

  /// 头部中心（归一化，供裁剪模块参考）。
  final FacePoint headCenter;

  /// 人脸框（归一化，供裁剪模块参考）。
  final NormalizedRect faceBox;
}

/// 从主脸构建矫正计划。
///
/// 眼睛与肩膀角度冲突时以眼睛为准（证件照核心要求眼睛水平）。
CorrectionPlan buildCorrectionPlan(FaceInfo face) {
  final rotation = computeEyeLevelRotation(face.leftEye, face.rightEye);
  double? shoulderRotation;
  if (face.leftShoulder != null && face.rightShoulder != null) {
    shoulderRotation = computeShoulderLevelRotation(
      face.leftShoulder!,
      face.rightShoulder!,
    );
  }
  return CorrectionPlan(
    rotationDegrees: rotation,
    shoulderRotationDegrees: shoulderRotation,
    headCenter: computeHeadCenter(face),
    faceBox: face.boundingBox,
  );
}

/// 图像模糊评分：灰度 + 降采样后计算 3×3 Laplacian 方差。
///
/// 值越大越清晰；低于 [kBlurThreshold] 判为模糊。
double computeBlurScore(img.Image source, {int maxEdge = 160}) {
  final small = _resizeDown(source, maxEdge);
  final gray = img.grayscale(small);
  final w = gray.width;
  final h = gray.height;
  if (w < 3 || h < 3) return 0;

  final values = <double>[];
  for (var y = 1; y < h - 1; y++) {
    for (var x = 1; x < w - 1; x++) {
      final v = gray.getPixel(x, y).r.toDouble();
      final lap = gray.getPixel(x - 1, y).r +
          gray.getPixel(x + 1, y).r +
          gray.getPixel(x, y - 1).r +
          gray.getPixel(x, y + 1).r -
          4 * v;
      values.add(lap);
    }
  }
  if (values.isEmpty) return 0;
  final mean = values.reduce((a, b) => a + b) / values.length;
  var variance = 0.0;
  for (final v in values) {
    variance += (v - mean) * (v - mean);
  }
  return variance / values.length;
}

/// 是否模糊。
bool isBlurry(double blurScore, {double threshold = kBlurThreshold}) {
  return blurScore < threshold;
}

img.Image _resizeDown(img.Image image, int maxEdge) {
  final longEdge = max(image.width, image.height);
  if (longEdge <= maxEdge) return image;
  final scale = maxEdge / longEdge;
  return img.copyResize(
    image,
    width: max(1, (image.width * scale).round()),
    height: max(1, (image.height * scale).round()),
    interpolation: img.Interpolation.average,
  );
}

/// 解码辅助：从编码字节解码为 image 图像；失败返回 null。
img.Image? tryDecodeImage(Uint8List bytes) => img.decodeImage(bytes);
