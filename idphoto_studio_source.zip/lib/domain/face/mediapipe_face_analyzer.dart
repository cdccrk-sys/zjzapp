import 'package:image/image.dart' as img;
import 'package:mediapipe_face_mesh/mediapipe_face_mesh.dart' as mp;

import 'face_analysis.dart';
import 'face_analyzer.dart';
import 'face_models.dart';

/// 基于 mediapipe_face_mesh 的实现（Android / Windows x64，模型随包内置）。
///
/// 流程：FaceDetectorProcessor 检测（支持多人计数）→ FaceMeshProcessor
/// 用主脸 ROI 产出 478 关键点 → 3D 姿态估计（yaw/pitch/roll）→
/// blendshapes 判闭眼 → 模糊评分（纯 Dart）→ 组装质量提示。
///
/// 说明：
/// - 肩膀关键点需要姿态模型（MediaPipe Pose），M2 里程碑接入；
///   当前返回 null，矫正时仅使用眼睛水平。
/// - 原生库在首次 analyze 时加载；任何底层异常都会降级为
///   [FaceAnalysisResult.analyzerUnavailableReason] 非空的结果，不向上抛。
class MediaPipeFaceAnalyzer implements FaceAnalyzer {
  MediaPipeFaceAnalyzer({bool enableBlendshapes = true})
      : _enableBlendshapes = enableBlendshapes;

  final bool _enableBlendshapes;

  Future<void>? _initFuture;
  mp.FaceDetectorProcessor? _detector;
  mp.FaceMeshProcessor? _mesh;
  mp.FaceBlendshapesProcessor? _blendshapes;

  Future<void> _ensureInitialized() {
    return _initFuture ??= _initialize();
  }

  Future<void> _initialize() async {
    _detector = await mp.FaceDetectorProcessor.create(
      model: mp.FaceDetectionModel.shortRange,
      maxResults: 5,
      minDetectionConfidence: 0.5,
    );
    _mesh = await mp.FaceMeshProcessor.create(model: mp.FaceMeshModel.v2);
    if (_enableBlendshapes) {
      _blendshapes = await mp.FaceBlendshapesProcessor.create();
    }
  }

  @override
  Future<FaceAnalysisResult> analyze(img.Image image) async {
    try {
      await _ensureInitialized();
      final frame = mp.FaceMeshImage(
        pixels: image.getBytes(order: img.ChannelOrder.rgba),
        width: image.width,
        height: image.height,
      );

      final blurScore = computeBlurScore(image);

      // 检测（多人计数）。
      final detections = _detector!.process(frame).detections;
      if (detections.isEmpty) {
        return FaceAnalysisResult(
          faces: const [],
          imageWidth: image.width,
          imageHeight: image.height,
          blurScore: blurScore,
        );
      }

      // 主脸关键点。
      final mesh = _mesh!.process(
        frame,
        roi: detections.first.expandedFaceRect,
      );
      if (mesh.landmarks.length < 468) {
        return FaceAnalysisResult(
          faces: const [],
          imageWidth: image.width,
          imageHeight: image.height,
          blurScore: blurScore,
        );
      }

      // 关键点索引（MediaPipe Face Mesh 标准）：左眼外 33、右眼外 263、
      // 鼻尖 1、下巴 152。
      final lm = mesh.landmarks;
      FacePoint at(int i) => FacePoint(lm[i].x, lm[i].y);

      // 3D 姿态（可能失败，降级为 null）。
      double? yaw;
      double? pitch;
      double? roll;
      try {
        final pose = mesh.estimateGeometry().headPose;
        yaw = pose.yawDegrees;
        pitch = pose.pitchDegrees;
        roll = pose.rollDegrees;
      } catch (_) {
        // 姿态估计不可用时忽略。
      }

      // 闭眼（blendshape）。
      var blinkLeft = 0.0;
      var blinkRight = 0.0;
      if (_blendshapes != null) {
        try {
          final shapes = _blendshapes!.process(mesh);
          if (shapes != null) {
            blinkLeft = shapes[mp.FaceBlendshape.eyeBlinkLeft];
            blinkRight = shapes[mp.FaceBlendshape.eyeBlinkRight];
          }
        } catch (_) {
          // blendshape 失败时忽略。
        }
      }

      final face = FaceInfo(
        boundingBox: NormalizedRect(
          left: mesh.rect.xCenter - mesh.rect.width / 2,
          top: mesh.rect.yCenter - mesh.rect.height / 2,
          right: mesh.rect.xCenter + mesh.rect.width / 2,
          bottom: mesh.rect.yCenter + mesh.rect.height / 2,
        ),
        leftEye: at(33),
        rightEye: at(263),
        nose: at(1),
        chin: at(152),
        yawDegrees: yaw,
        pitchDegrees: pitch,
        rollDegrees: roll,
        eyeBlinkLeft: blinkLeft,
        eyeBlinkRight: blinkRight,
      );

      return FaceAnalysisResult(
        faces: [face],
        imageWidth: image.width,
        imageHeight: image.height,
        blurScore: blurScore,
      );
    } catch (e) {
      return FaceAnalysisResult(
        faces: const [],
        imageWidth: image.width,
        imageHeight: image.height,
        blurScore: 0,
        analyzerUnavailableReason: '人脸分析器不可用：$e',
      );
    }
  }
}
