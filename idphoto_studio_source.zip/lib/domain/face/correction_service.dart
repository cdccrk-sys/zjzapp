import 'dart:typed_data';

import 'package:image/image.dart' as img;

import 'face_analysis.dart';
import 'face_models.dart';

/// 矫正结果：矫正后的图像字节 + 应用参数。
class CorrectionResult {
  const CorrectionResult({
    required this.rotationDegrees,
    required this.autoCorrected,
    required this.correctedBytes,
    required this.width,
    required this.height,
    this.analysis,
  });

  /// 实际应用的顺时针旋转度数。
  final double rotationDegrees;

  /// 是否来自自动矫正（false 表示手动旋转或未矫正）。
  final bool autoCorrected;

  /// 矫正后图像（JPEG，质量 92）。
  final Uint8List correctedBytes;
  final int width;
  final int height;

  /// 最近一次人脸分析（可能为 null）。
  final FaceAnalysisResult? analysis;

  bool get corrected => rotationDegrees != 0;
}

/// 图像矫正服务：对工作图应用旋转并编码。
///
/// 旋转后默认中心裁剪回原图尺寸（当旋转画布完全覆盖原图时），
/// 避免预览出现白色边角；90° 等旋转画布不覆盖原图时保留旋转结果。
class CorrectionService {
  const CorrectionService();

  /// 应用顺时针旋转 [rotationDegrees] 度；0 度时原样编码。
  CorrectionResult applyRotation({
    required img.Image source,
    required double rotationDegrees,
    FaceAnalysisResult? analysis,
  }) {
    final rotated = _rotateAndCropBack(source, rotationDegrees);
    return CorrectionResult(
      rotationDegrees: rotationDegrees,
      autoCorrected: false,
      correctedBytes: Uint8List.fromList(img.encodeJpg(rotated, quality: 92)),
      width: rotated.width,
      height: rotated.height,
      analysis: analysis,
    );
  }

  /// 按矫正计划自动矫正（眼睛水平）。
  CorrectionResult applyAutoCorrection({
    required img.Image source,
    required FaceInfo face,
    FaceAnalysisResult? analysis,
  }) {
    final plan = buildCorrectionPlan(face);
    final rotated = _rotateAndCropBack(source, plan.rotationDegrees);
    return CorrectionResult(
      rotationDegrees: plan.rotationDegrees,
      autoCorrected: true,
      correctedBytes: Uint8List.fromList(img.encodeJpg(rotated, quality: 92)),
      width: rotated.width,
      height: rotated.height,
      analysis: analysis,
    );
  }

  /// 旋转 + 中心裁剪回原尺寸。
  img.Image _rotateAndCropBack(img.Image source, double angle) {
    if (angle == 0) return source;
    final rotated = img.copyRotate(
      source,
      angle: angle,
      interpolation: img.Interpolation.linear,
    );
    if (rotated.width >= source.width && rotated.height >= source.height) {
      final x = ((rotated.width - source.width) / 2).floor();
      final y = ((rotated.height - source.height) / 2).floor();
      return img.copyCrop(rotated, x: x, y: y, width: source.width, height: source.height);
    }
    return rotated;
  }
}
