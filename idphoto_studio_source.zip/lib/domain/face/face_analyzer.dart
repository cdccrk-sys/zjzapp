import 'package:image/image.dart' as img;

import 'face_models.dart';

/// 人脸分析器接口。
///
/// 平台无关契约：输入已解码图像，输出结构化分析结果。
/// 实现（MediaPipe）见 mediapipe_face_analyzer.dart；
/// 测试中可注入假实现。
abstract class FaceAnalyzer {
  /// 分析一张图像。
  ///
  /// 实现必须自行捕获底层异常：原生库缺失/模型加载失败时返回
  /// [FaceAnalysisResult.analyzerUnavailableReason] 非空的降级结果，
  /// 不得向调用方抛异常。
  Future<FaceAnalysisResult> analyze(img.Image image);
}
