import 'dart:math' as math;

import 'package:flutter/foundation.dart';
import 'package:image/image.dart' as img;

import '../face/face_models.dart';
import '../specs/idphoto_specs.dart';

/// 裁剪框（源图像素坐标，整数）。
class CropRect {
  const CropRect({
    required this.x,
    required this.y,
    required this.width,
    required this.height,
  });

  final int x;
  final int y;
  final int width;
  final int height;

  /// 与目标规格的宽高比匹配度（1=完全匹配）。
  double aspectError(double targetAspect) {
    final a = width / height;
    return (a - targetAspect).abs();
  }

  CropRect clampTo(int imageWidth, int imageHeight) {
    var nx = x, ny = y, nw = width, nh = height;
    if (nw > imageWidth) nw = imageWidth;
    if (nh > imageHeight) nh = imageHeight;
    nx = nx.clamp(0, math.max(0, imageWidth - nw));
    ny = ny.clamp(0, math.max(0, imageHeight - nh));
    return CropRect(x: nx, y: ny, width: nw, height: nh);
  }

  CropRect shiftBy(int dx, int dy, int imageWidth, int imageHeight) {
    return CropRect(x: x + dx, y: y + dy, width: width, height: height)
        .clampTo(imageWidth, imageHeight);
  }

  CropRect scaleBy(double factor, int imageWidth, int imageHeight) {
    final nw = (width * factor).round().clamp(10, imageWidth);
    final nh = (height * factor).round().clamp(10, imageHeight);
    // 保持中心。
    final cx = x + width ~/ 2;
    final cy = y + height ~/ 2;
    return CropRect(
      x: cx - nw ~/ 2,
      y: cy - nh ~/ 2,
      width: nw,
      height: nh,
    ).clampTo(imageWidth, imageHeight);
  }
}

/// 裁剪规则（证件照构图参数）。
@immutable
class CropRule {
  const CropRule({
    this.eyeHeightRatio = 0.58,
    this.faceRatio = 0.5,
  });

  /// 眼睛水平线在照片中的高度占比（0.5-0.65）。
  final double eyeHeightRatio;

  /// 眼-下巴距离占照片高度比例（0.42-0.62）。
  /// 越小头部在画面中越小（留白越多）。
  final double faceRatio;

  CropRule copyWith({
    double? eyeHeightRatio,
    double? faceRatio,
  }) {
    return CropRule(
      eyeHeightRatio: eyeHeightRatio ?? this.eyeHeightRatio,
      faceRatio: faceRatio ?? this.faceRatio,
    );
  }
}

/// 裁剪计算结果。
class CropResult {
  const CropResult({required this.rect, required this.rule});

  final CropRect rect;
  final CropRule rule;
}

/// 裁剪服务：自动构图 + 手动微调 + 实际裁剪。
class CropService {
  const CropService();

  /// 基于人脸关键点自动计算裁剪框。
  ///
  /// [face] 人脸信息（归一化坐标），[spec] 目标规格。
  /// [imageWidth]/[imageHeight] 源图尺寸。
  CropResult autoCrop(
    FaceInfo face,
    IdPhotoSpec spec,
    int imageWidth,
    int imageHeight, {
    CropRule rule = const CropRule(),
  }) {
    // 眼睛与下巴（归一化，相对各自维度）。
    final eyeY = (face.leftEye.y + face.rightEye.y) / 2;
    final eyeX = (face.leftEye.x + face.rightEye.x) / 2;
    final faceH = (face.chin.y - eyeY).abs(); // 眼-下巴距离（归一化高度）

    // 照片高：眼-下巴距离占照片高度 faceRatio。
    double H;
    if (faceH > 0.01) {
      H = faceH / rule.faceRatio * imageHeight;
    } else {
      // 退化：基于人脸框。
      H = face.boundingBox.height * imageHeight * 1.6;
    }
    H = H.clamp(1, imageHeight.toDouble());

    // 眼睛锚点：eyePx = yTop + H * eyeHeightRatio。
    final eyePx = eyeY * imageHeight;
    final yTop =
        (eyePx - H * rule.eyeHeightRatio).clamp(0.0, imageHeight - H);

    // 水平：眼部中心居中。
    final W = H * spec.aspectRatio;
    final xCenter = eyeX * imageWidth;
    final xLeft = (xCenter - W / 2).clamp(0.0, imageWidth - W);

    return CropResult(
      rect: CropRect(
        x: xLeft.round(),
        y: yTop.round(),
        width: W.round(),
        height: H.round(),
      ),
      rule: rule,
    );
  }

  /// 手动微调：水平/垂直移动。
  CropRect shift(CropRect rect, int dx, int dy, int imageWidth, int imageHeight) {
    return rect.shiftBy(dx, dy, imageWidth, imageHeight);
  }

  /// 手动微调：缩放（保持中心，比例锁定按规格）。
  CropRect zoom(
    CropRect rect,
    double factor,
    int imageWidth,
    int imageHeight,
    IdPhotoSpec spec,
  ) {
    var nw = (rect.width * factor).round();
    var nh = (nw / spec.aspectRatio).round();
    // 超出边界时等比缩回，保持规格比例。
    final fit = math.min(1.0, math.min(imageWidth / nw, imageHeight / nh));
    nw = (nw * fit).round().clamp(20, imageWidth);
    nh = (nh * fit).round().clamp(20, imageHeight);
    final cx = rect.x + rect.width ~/ 2;
    final cy = rect.y + rect.height ~/ 2;
    return CropRect(
      x: cx - nw ~/ 2,
      y: cy - nh ~/ 2,
      width: nw,
      height: nh,
    ).clampTo(imageWidth, imageHeight);
  }

  /// 按裁剪框裁剪并缩放为目标像素尺寸。
  img.Image applyCrop(
    img.Image source,
    CropRect rect, {
    int? targetWidth,
    int? targetHeight,
  }) {
    final cropped = img.copyCrop(source,
        x: rect.x, y: rect.y, width: rect.width, height: rect.height);
    if (targetWidth == null || targetHeight == null) return cropped;
    return img.copyResize(
      cropped,
      width: targetWidth,
      height: targetHeight,
      interpolation: img.Interpolation.linear,
    );
  }
}
