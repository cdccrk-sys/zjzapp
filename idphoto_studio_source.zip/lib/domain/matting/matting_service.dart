import 'dart:math' as math;
import 'dart:typed_data';

import 'package:image/image.dart' as img;

import 'background.dart';

/// 蒙版后处理与背景合成服务（纯 Dart，可单测）。
class MattingService {
  const MattingService();

  /// 将分割结果蒙版转换为带 alpha 的 RGBA 图像。
  ///
  /// [featherRadius] 边缘羽化半径（像素，0=不羽化）。
  /// [threshold] 前景判定阈值（0-255），低于此值视为背景。
  /// [erode] 蒙版收缩像素（负数=扩张）。
  img.Image buildAlphaImage(
    img.Image source,
    Uint8List mask, {
    int featherRadius = 1,
    int threshold = 96,
    int erode = 0,
  }) {
    final w = source.width, h = source.height;
    final alpha = img.Image(width: w, height: h, numChannels: 4);

    // 阈值化 → alpha。
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final v = mask[y * w + x];
        final a = v >= threshold ? 255 : 0;
        alpha.setPixelRgba(x, y, 0, 0, 0, a);
      }
    }

    // 收缩/扩张（简易：按半径置 0/255）。
    if (erode != 0) {
      final n = math.max(1, erode.abs());
      final work = alpha.clone();
      for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++) {
          var anyFg = false, anyBg = false;
          for (var dy = -n; dy <= n && !(anyFg && anyBg); dy++) {
            for (var dx = -n; dx <= n && !(anyFg && anyBg); dx++) {
              final nx = x + dx, ny = y + dy;
              if (nx < 0 || nx >= w || ny < 0 || ny >= h) continue;
              if (work.getPixel(nx, ny).a.toInt() > 0) {
                anyFg = true;
              } else {
                anyBg = true;
              }
            }
          }
          final isFg = work.getPixel(x, y).a.toInt() > 0;
          if (erode > 0) {
            // 收缩：前景像素若邻域有背景则变背景。
            if (isFg && anyBg) alpha.setPixelRgba(x, y, 0, 0, 0, 0);
          } else {
            // 扩张：背景像素若邻域有前景则变前景。
            if (!isFg && anyFg) alpha.setPixelRgba(x, y, 0, 0, 0, 255);
          }
        }
      }
    }

    // 羽化：对 alpha 通道高斯模糊（半径 1 时约 1-2px 过渡）。
    if (featherRadius > 0) {
      final blurred = img.gaussianBlur(alpha, radius: featherRadius);
      for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++) {
          alpha.setPixelRgba(
            x,
            y,
            0,
            0,
            0,
            blurred.getPixel(x, y).a.toInt(),
          );
        }
      }
    }

    // 贴回原图颜色。
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final p = source.getPixel(x, y);
        alpha.setPixelRgba(
          x,
          y,
          p.r.toInt(),
          p.g.toInt(),
          p.b.toInt(),
          alpha.getPixel(x, y).a.toInt(),
        );
      }
    }
    return alpha;
  }

  /// 用 [alpha] 图像与 [background] 合成最终证件照。
  img.Image composite(
    img.Image source,
    Uint8List mask, {
    PhotoBackground background = const PhotoBackground(
      type: PhotoBackgroundType.solid,
      color: 0xFFFFFFFF,
    ),
    int featherRadius = 1,
    int threshold = 96,
    int erode = 0,
  }) {
    if (background.isTransparent) {
      return buildAlphaImage(
        source,
        mask,
        featherRadius: featherRadius,
        threshold: threshold,
        erode: erode,
      );
    }

    final alpha = buildAlphaImage(
      source,
      mask,
      featherRadius: featherRadius,
      threshold: threshold,
      erode: erode,
    );
    final w = source.width, h = source.height;

    // 生成背景层。
    final bg = img.Image(width: w, height: h, numChannels: 3);
    if (background.type == PhotoBackgroundType.gradient) {
      final c0 = _argbToRgb(background.color);
      final c1 = _argbToRgb(background.colorEnd ?? background.color);
      for (var y = 0; y < h; y++) {
        for (var x = 0; x < w; x++) {
          final t = background.direction == GradientDirection.topToBottom
              ? h <= 1 ? 0.0 : y / (h - 1)
              : w <= 1 ? 0.0 : x / (w - 1);
          final r = (c0.r + (c1.r - c0.r) * t).round().clamp(0, 255);
          final g = (c0.g + (c1.g - c0.g) * t).round().clamp(0, 255);
          final b = (c0.b + (c1.b - c0.b) * t).round().clamp(0, 255);
          bg.setPixelRgb(x, y, r, g, b);
        }
      }
    } else {
      final c = _argbToRgb(background.color);
      img.fill(bg, color: img.ColorRgb8(c.r, c.g, c.b));
    }

    // alpha 混合。
    final out = img.Image(width: w, height: h, numChannels: 3);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final a = alpha.getPixel(x, y).a.toInt();
        final p = source.getPixel(x, y);
        final b = bg.getPixel(x, y);
        final fa = a / 255.0;
        final r = (p.r * fa + b.r * (1 - fa)).round().clamp(0, 255);
        final g = (p.g * fa + b.g * (1 - fa)).round().clamp(0, 255);
        final bl = (p.b * fa + b.b * (1 - fa)).round().clamp(0, 255);
        out.setPixelRgb(x, y, r, g, bl);
      }
    }
    return out;
  }

  /// 手动修补：在 [mask] 上以圆心/半径画笔刷。
  ///
  /// [add] true=前景笔（涂白），false=背景笔（涂黑）。
  /// 返回新蒙版。
  Uint8List repair(
    Uint8List mask,
    int width,
    int height,
    int cx,
    int cy,
    int radius, {
    required bool add,
  }) {
    final out = Uint8List.fromList(mask);
    final r2 = radius * radius;
    final x0 = math.max(0, cx - radius), x1 = math.min(width - 1, cx + radius);
    final y0 = math.max(0, cy - radius), y1 = math.min(height - 1, cy + radius);
    for (var y = y0; y <= y1; y++) {
      for (var x = x0; x <= x1; x++) {
        final dx = x - cx, dy = y - cy;
        if (dx * dx + dy * dy <= r2) {
          out[y * width + x] = add ? 255 : 0;
        }
      }
    }
    return out;
  }

  /// 前景占比（0-1），用于检测抠图质量（如全黑=失败）。
  double foregroundRatio(Uint8List mask, int width, int height,
      {int threshold = 96}) {
    var fg = 0;
    for (var i = 0; i < mask.length; i++) {
      if (mask[i] >= threshold) fg++;
    }
    final total = width * height;
    return total == 0 ? 0 : fg / total;
  }

  static ({int r, int g, int b}) _argbToRgb(int argb) {
    return (
      r: (argb >> 16) & 0xFF,
      g: (argb >> 8) & 0xFF,
      b: argb & 0xFF,
    );
  }
}
