import 'package:flutter/services.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider/path_provider.dart';

/// 分割结果：与原图同尺寸的灰度前景蒙版（0-255）。
class SegmentationResult {
  const SegmentationResult({
    required this.mask,
    required this.width,
    required this.height,
    required this.source,
    required this.succeeded,
    this.errorHint,
  });

  /// 前景概率蒙版，逐行排列，长度 width*height，0=背景 255=前景。
  final Uint8List mask;
  final int width;
  final int height;

  /// 分割来源：'tflite'（原生 AI）或 'geometric'（几何兜底）。
  final String source;

  final bool succeeded;

  /// 失败原因（供界面诊断显示）。
  final String? errorHint;
}

/// 人像分割器抽象：输入图像，输出前景蒙版。
abstract class Segmenter {
  Future<SegmentationResult> segment(img.Image image);
}

/// 原生 ONNX Runtime 分割（Android）：
/// MethodChannel → SegmentationPlugin（BiRefNet-portrait 1024×1024 人像抠图）。
class NativeTfliteSegmenter implements Segmenter {
  NativeTfliteSegmenter({MethodChannel? channel})
      : _channel = channel ??
            const MethodChannel('idphoto/segmentation');

  final MethodChannel _channel;

  /// BiRefNet-portrait 1024×1024 输入。
  static const int _modelSize = 1024;

  bool _loaded = false;
  Future<void>? _loading;

  Future<void> _ensureLoaded() async {
    if (_loaded) return;
    _loading ??= _load();
    await _loading;
  }

  /// 后台预热：提前加载模型，首次抠图不用等待。
  Future<void> warmup() async {
    try {
      await _ensureLoaded();
    } catch (_) {
      // 预热失败不阻塞：segment 时会再次尝试并上报错误。
    }
  }

  Future<void> _load() async {
    try {
      await _channel.invokeMethod<String>('load', {
        'asset': 'assets/models/birefnet_portrait_fp16.onnx',
      });
      _loaded = true;
    } catch (e) {
      _loading = null;
      rethrow;
    }
  }

  @override
  Future<SegmentationResult> segment(img.Image image) async {
    try {
      await _ensureLoaded();
      // 将图片写为临时 PNG 后交给原生解码（避免二进制大参数）。
      final dir = await getTemporaryDirectory();
      final file = '${dir.path}/seg_input_${DateTime.now().microsecondsSinceEpoch}.png';
      await img.encodePngFile(file, image);
      final maskBytes =
          await _channel.invokeMethod<Uint8List>('segment', {'path': file}) ??
              Uint8List(0);
      if (maskBytes.length != _modelSize * _modelSize) {
        return SegmentationResult(
          mask: Uint8List(image.width * image.height),
          width: image.width,
          height: image.height,
          source: 'birefnet-portrait',
          succeeded: false,
          errorHint: 'mask 长度异常',
        );
      }
      // 模型输出 1024×1024，缩放到原图尺寸（双线性）。
      final maskImg = img.Image.fromBytes(
        width: _modelSize,
        height: _modelSize,
        bytes: maskBytes.buffer,
        numChannels: 1,
      );
      final resized = img.copyResize(
        maskImg,
        width: image.width,
        height: image.height,
        interpolation: img.Interpolation.linear,
      );
      final mask = Uint8List(image.width * image.height);
      var fg = 0;
      for (var i = 0; i < mask.length; i++) {
        final v = resized
            .getPixel(i % image.width, i ~/ image.width)
            .r
            .toInt();
        mask[i] = v;
        if (v > 127) fg++;
      }
      // 质量自检：蒙版全空/全满或前景占比极端异常 → 判定失败并回退。
      final ratio = mask.isEmpty ? 0.0 : fg / mask.length;
      if (fg == 0 || fg == mask.length || ratio < 0.02 || ratio > 0.98) {
        return SegmentationResult(
          mask: Uint8List(image.width * image.height),
          width: image.width,
          height: image.height,
          source: 'birefnet-portrait',
          succeeded: false,
          errorHint: '前景占比异常',
        );
      }
      return SegmentationResult(
        mask: mask,
        width: image.width,
        height: image.height,
        source: 'birefnet-portrait',
        succeeded: true,
      );
    } catch (e) {
      return SegmentationResult(
        mask: Uint8List(image.width * image.height),
        width: image.width,
        height: image.height,
        source: 'birefnet-portrait',
        succeeded: false,
        errorHint: e.toString(),
      );
    }
  }

  void dispose() {
    if (_loaded) {
      _channel.invokeMethod<void>('close');
      _loaded = false;
    }
  }
}

/// 几何兜底分割（Windows / 原生通道不可用 / AI 分割失败时的降级）：
/// 中心先验：证件照人像通常居中，以中心椭圆为前景种子、四边为背景种子
/// 做双向颜色生长；中心椭圆强制为前景，保证人像永远不会被整体抠除。
class GeometricFallbackSegmenter implements Segmenter {
  const GeometricFallbackSegmenter();

  @override
  Future<SegmentationResult> segment(img.Image image) async {
    final w = image.width, h = image.height;
    final n = w * h;
    // 0=未知 1=背景 2=前景
    final label = Uint8List(n);
    final queue = <int>[];

    // 四边背景种子。
    void seedBg(int x, int y) {
      final i = y * w + x;
      if (label[i] != 0) return;
      label[i] = 1;
      queue.add(i);
    }

    for (var x = 0; x < w; x++) {
      seedBg(x, 0);
      seedBg(x, h - 1);
    }
    for (var y = 0; y < h; y++) {
      seedBg(0, y);
      seedBg(w - 1, y);
    }

    // 中心椭圆前景种子（椭圆覆盖人脸+肩部区域）。
    final cx = w / 2.0, cy = h / 2.0;
    final rx = w * 0.30, ry = h * 0.36;
    final fgQueue = <int>[];
    // 初始种子索引集合：种子无条件保留为前景（中心先验保底）。
    final fgSeed = <int>{};
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final nx = (x - cx) / rx, ny = (y - cy) / ry;
        if (nx * nx + ny * ny <= 1.0 && label[y * w + x] == 0) {
          label[y * w + x] = 2;
          fgQueue.add(y * w + x);
          fgSeed.add(y * w + x);
        }
      }
    }

    // 四角平均色作为背景基准；中心椭圆平均色作为前景基准。
    final corners = [
      image.getPixel(0, 0),
      image.getPixel(w - 1, 0),
      image.getPixel(0, h - 1),
      image.getPixel(w - 1, h - 1),
    ];
    var sr = 0, sg = 0, sb = 0;
    for (final c in corners) {
      sr += c.r.toInt();
      sg += c.g.toInt();
      sb += c.b.toInt();
    }
    final baseR = sr ~/ 4, baseG = sg ~/ 4, baseB = sb ~/ 4;

    // 前景基准色取中心小块（约占椭圆 40% 半径）的平均，避免被背景色污染。
    var fr = 0, fgSum = 0, fb = 0;
    var fcnt = 0;
    final irx = rx * 0.4, iry = ry * 0.4;
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final nx = (x - cx) / irx, ny = (y - cy) / iry;
        if (nx * nx + ny * ny <= 1.0) {
          final p = image.getPixel(x, y);
          fr += p.r.toInt();
          fgSum += p.g.toInt();
          fb += p.b.toInt();
          fcnt++;
        }
      }
    }
    if (fcnt > 0) {
      fr ~/= fcnt;
      fgSum ~/= fcnt;
      fb ~/= fcnt;
    }

    // 背景生长：颜色接近四角平均色 → 背景。
    const bgTh = 42.0;
    var qi = 0;
    while (qi < queue.length) {
      final i = queue[qi++];
      if (label[i] != 1) continue;
      final p = image.getPixel(i % w, i ~/ w);
      final dr = p.r.toInt() - baseR;
      final dg = p.g.toInt() - baseG;
      final db = p.b.toInt() - baseB;
      if (dr * dr + dg * dg + db * db > bgTh * bgTh * 3) {
        label[i] = 0; // 与背景差异大：交给前景判断。
        continue;
      }
      label[i] = 1;
      final x = i % w, y = i ~/ w;
      for (final (nx, ny) in [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]) {
        if (nx >= 0 && nx < w && ny >= 0 && ny < h && label[ny * w + nx] == 0) {
          label[ny * w + nx] = 1;
          queue.add(ny * w + nx);
        }
      }
    }

    // 前景生长：从中心椭圆向外，颜色接近前景基准 → 前景；
    // 初始种子无条件保留，避免人像被整体抠除。
    const fgTh = 60.0;
    qi = 0;
    while (qi < fgQueue.length) {
      final i = fgQueue[qi++];
      if (label[i] != 2) continue;
      final p = image.getPixel(i % w, i ~/ w);
      final dr = p.r.toInt() - fr;
      final dg = p.g.toInt() - fgSum;
      final db = p.b.toInt() - fb;
      if (!fgSeed.contains(i) &&
          dr * dr + dg * dg + db * db > fgTh * fgTh * 3) {
        label[i] = 0;
        continue;
      }
      label[i] = 2;
      final x = i % w, y = i ~/ w;
      for (final (nx, ny) in [(x + 1, y), (x - 1, y), (x, y + 1), (x, y - 1)]) {
        if (nx >= 0 && nx < w && ny >= 0 && ny < h && label[ny * w + nx] == 0) {
          label[ny * w + nx] = 2;
          fgQueue.add(ny * w + nx);
        }
      }
    }

    // 输出蒙版：2=前景(255)，其余背景(0)。中心椭圆已强制前景，人像永不被整体抠除。
    final mask = Uint8List(n);
    for (var i = 0; i < n; i++) {
      mask[i] = label[i] == 2 ? 255 : 0;
    }

    return SegmentationResult(
      mask: mask,
      width: w,
      height: h,
      source: 'geometric',
      succeeded: true,
    );
  }
}

