import 'dart:ui' as ui;

import 'package:flutter/foundation.dart';

/// 背景类型。
enum PhotoBackgroundType {
  /// 纯色底。
  solid,

  /// 渐变底（上下或左右）。
  gradient,

  /// 透明底（导出透明 PNG）。
  transparent,

  /// 自定义图片底（仅作底色替换，不改变裁剪合规）。
  image,
}

/// 渐变方向。
enum GradientDirection {
  topToBottom,
  leftToRight,
}

/// 证件照背景模型（ARGB 颜色）。
@immutable
class PhotoBackground {
  const PhotoBackground({
    required this.type,
    this.color = 0xFFFFFFFF,
    this.colorEnd,
    this.direction = GradientDirection.topToBottom,
    this.imageBytes,
  });

  final PhotoBackgroundType type;

  /// 起始/主色（ARGB int）。
  final int color;

  /// 渐变终点色（仅 gradient）。
  final int? colorEnd;

  final GradientDirection direction;

  /// 自定义背景图片字节（仅 image 类型）。
  final Uint8List? imageBytes;

  /// 自定义图片背景。
  const PhotoBackground.fromImage(Uint8List bytes)
      : type = PhotoBackgroundType.image,
        color = 0xFFFFFFFF,
        colorEnd = null,
        direction = GradientDirection.topToBottom,
        imageBytes = bytes;

  /// 是否透明底。
  bool get isTransparent => type == PhotoBackgroundType.transparent;

  static const white = PhotoBackground(type: PhotoBackgroundType.solid, color: 0xFFFFFFFF);
  static const blue =
      PhotoBackground(type: PhotoBackgroundType.solid, color: 0xFF438EDB);
  static const red = PhotoBackground(type: PhotoBackgroundType.solid, color: 0xFFD9001B);
  static const gray = PhotoBackground(type: PhotoBackgroundType.solid, color: 0xFFD9D9D9);
  static const lightBlue =
      PhotoBackground(type: PhotoBackgroundType.solid, color: 0xFFB0D4F1);
  static const transparent =
      PhotoBackground(type: PhotoBackgroundType.transparent, color: 0x00000000);
  static const whiteToLightBlue = PhotoBackground(
    type: PhotoBackgroundType.gradient,
    color: 0xFFFFFFFF,
    colorEnd: 0xFFC9E2F7,
  );

  /// 常用预设列表（UI 展示顺序）。
  static const List<PhotoBackground> presets = [
    PhotoBackground(type: PhotoBackgroundType.solid, color: 0xFFFFFFFF), // 白
    PhotoBackground(type: PhotoBackgroundType.solid, color: 0xFF438EDB), // 蓝
    PhotoBackground(type: PhotoBackgroundType.solid, color: 0xFFD9001B), // 红
    PhotoBackground(type: PhotoBackgroundType.solid, color: 0xFFD9D9D9), // 灰
    PhotoBackground(type: PhotoBackgroundType.solid, color: 0xFFB0D4F1), // 浅蓝
    PhotoBackground(
      type: PhotoBackgroundType.gradient,
      color: 0xFFFFFFFF,
      colorEnd: 0xFFC9E2F7,
    ), // 渐变
    PhotoBackground(type: PhotoBackgroundType.transparent, color: 0x00000000), // 透明
  ];

  /// 预设显示名。
  String get label {
    switch (type) {
      case PhotoBackgroundType.solid:
        if (color == 0xFFFFFFFF) return '白底';
        if (color == 0xFF438EDB) return '蓝底';
        if (color == 0xFFD9001B) return '红底';
        if (color == 0xFFD9D9D9) return '灰底';
        if (color == 0xFFB0D4F1) return '浅蓝';
        return '自定义';
      case PhotoBackgroundType.gradient:
        return '渐变';
      case PhotoBackgroundType.transparent:
        return '透明';
      case PhotoBackgroundType.image:
        return '图片';
    }
  }

  PhotoBackground copyWith({
    PhotoBackgroundType? type,
    int? color,
    int? colorEnd,
    GradientDirection? direction,
    Uint8List? imageBytes,
  }) {
    return PhotoBackground(
      type: type ?? this.type,
      color: color ?? this.color,
      colorEnd: colorEnd ?? this.colorEnd,
      direction: direction ?? this.direction,
      imageBytes: imageBytes ?? this.imageBytes,
    );
  }

  /// 转为 Flutter 画刷（UI 预览用）。
  ui.Paint get paint {
    if (type == PhotoBackgroundType.transparent) {
      return ui.Paint()..color = const ui.Color(0x00000000);
    }
    if (type == PhotoBackgroundType.gradient) {
      final c0 = ui.Color(color);
      final c1 = ui.Color(colorEnd ?? color);
      const begin = ui.Offset(0, 0);
      final end = direction == GradientDirection.topToBottom
          ? const ui.Offset(0, 1)
          : const ui.Offset(1, 0);
      return ui.Paint()
        ..shader = ui.Gradient.linear(begin, end, [c0, c1]);
    }
    return ui.Paint()..color = ui.Color(color);
  }

  @override
  bool operator ==(Object other) {
    return other is PhotoBackground &&
        other.type == type &&
        other.color == color &&
        other.colorEnd == colorEnd &&
        other.direction == direction &&
        listEquals(other.imageBytes, imageBytes);
  }

  @override
  int get hashCode => Object.hash(type, color, colorEnd, direction, imageBytes);
}
