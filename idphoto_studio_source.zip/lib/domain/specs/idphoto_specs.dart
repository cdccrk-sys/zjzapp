import 'package:flutter/foundation.dart';

/// 证件照规格：物理尺寸（mm）+ 分辨率（px@300DPI）。
@immutable
class IdPhotoSpec {
  const IdPhotoSpec({
    required this.id,
    required this.name,
    required this.widthMm,
    required this.heightMm,
    this.dpi = 300,
  });

  final String id;
  final String name;

  /// 物理宽（毫米）。
  final double widthMm;

  /// 物理高（毫米）。
  final double heightMm;

  final int dpi;

  /// 目标像素宽（按 DPI 计算，四舍五入）。
  int get pixelWidth => (widthMm / 25.4 * dpi).round();

  /// 目标像素高。
  int get pixelHeight => (heightMm / 25.4 * dpi).round();

  /// 宽高比（宽/高）。
  double get aspectRatio => widthMm / heightMm;

  IdPhotoSpec copyWith({
    String? id,
    String? name,
    double? widthMm,
    double? heightMm,
    int? dpi,
  }) {
    return IdPhotoSpec(
      id: id ?? this.id,
      name: name ?? this.name,
      widthMm: widthMm ?? this.widthMm,
      heightMm: heightMm ?? this.heightMm,
      dpi: dpi ?? this.dpi,
    );
  }

  @override
  bool operator ==(Object other) =>
      other is IdPhotoSpec &&
      other.id == id &&
      other.widthMm == widthMm &&
      other.heightMm == heightMm &&
      other.dpi == dpi;

  @override
  int get hashCode => Object.hash(id, widthMm, heightMm, dpi);

  /// 内置规格库（中国常用 + 常见签证）。
  static const List<IdPhotoSpec> builtin = [
    IdPhotoSpec(id: 'inch1', name: '一寸', widthMm: 25, heightMm: 35),
    IdPhotoSpec(id: 'inch1s', name: '小一寸', widthMm: 22, heightMm: 32),
    IdPhotoSpec(id: 'inch1l', name: '大一寸', widthMm: 33, heightMm: 48),
    IdPhotoSpec(id: 'inch2', name: '二寸', widthMm: 35, heightMm: 49),
    IdPhotoSpec(id: 'inch2s', name: '小二寸', widthMm: 35, heightMm: 45),
    IdPhotoSpec(id: 'inch2l', name: '大二寸', widthMm: 35, heightMm: 53),
    IdPhotoSpec(id: 'passport', name: '护照', widthMm: 33, heightMm: 48),
    IdPhotoSpec(id: 'usvisa', name: '美国签证', widthMm: 51, heightMm: 51),
    IdPhotoSpec(id: 'jpvisa', name: '日本签证', widthMm: 45, heightMm: 45),
    IdPhotoSpec(id: 'driving', name: '驾照', widthMm: 22, heightMm: 32),
    IdPhotoSpec(id: 'social', name: '社保', widthMm: 26, heightMm: 32),
    IdPhotoSpec(id: 'resume', name: '简历', widthMm: 26, heightMm: 32),
    IdPhotoSpec(id: 'marriage', name: '结婚证', widthMm: 53, heightMm: 35),
    IdPhotoSpec(id: 'exam', name: '考试报名', widthMm: 26, heightMm: 32),
    // 常见签证与证件（35×45 为主流签证尺寸）。
    IdPhotoSpec(id: 'ukvisa', name: '英国签证', widthMm: 35, heightMm: 45),
    IdPhotoSpec(id: 'cavisas', name: '加拿大签证', widthMm: 35, heightMm: 45),
    IdPhotoSpec(id: 'schengen', name: '申根签证', widthMm: 35, heightMm: 45),
    IdPhotoSpec(id: 'auvisa', name: '澳大利亚签证', widthMm: 35, heightMm: 45),
    IdPhotoSpec(id: 'nzvisa', name: '新西兰签证', widthMm: 35, heightMm: 45),
    IdPhotoSpec(id: 'sgvisa', name: '新加坡签证', widthMm: 35, heightMm: 45),
    IdPhotoSpec(id: 'krvisa', name: '韩国签证', widthMm: 35, heightMm: 45),
    IdPhotoSpec(id: 'hkperm', name: '港澳通行证', widthMm: 33, heightMm: 48),
    IdPhotoSpec(id: 'twperm', name: '台湾通行证', widthMm: 33, heightMm: 48),
    IdPhotoSpec(id: 'teacher', name: '教师资格证', widthMm: 33, heightMm: 48),
    IdPhotoSpec(id: 'nurse', name: '护士执业证', widthMm: 25, heightMm: 35),
    IdPhotoSpec(id: 'child1', name: '儿童一寸', widthMm: 25, heightMm: 35),
  ];

  /// 按 id 查找内置规格。
  static IdPhotoSpec? byId(String id) {
    for (final s in builtin) {
      if (s.id == id) return s;
    }
    return null;
  }
}
