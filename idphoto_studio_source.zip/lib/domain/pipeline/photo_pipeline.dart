import 'package:image/image.dart' as img;

import '../dress/dress_service.dart';
import '../enhance/enhance_service.dart';
import '../face/face_models.dart';
import '../matting/background.dart';

/// 蒙版类型别名（与分割结果一致：每像素 0-255）。
typedef Uint8List8 = List<int>;

/// 抠图数据（蒙版 + 背景）。
class MattingData {
  const MattingData({required this.mask, required this.background});

  final Uint8List8 mask;
  final PhotoBackground background;
}

/// 证件照统一处理管线：
/// 换底（蒙版合成）→ 换装（贴图）→ 色彩优化 → 返回结果图。
///
/// 所有步骤均不改变图像尺寸，因此裁剪坐标在整条链路保持有效。
class PhotoPipeline {
  const PhotoPipeline();

  img.Image process({
    required img.Image source,
    Uint8List8? mattingMask,
    PhotoBackground? background,
    EnhancementParams enhancement = const EnhancementParams(),
    DressTemplate dress = DressTemplate.none,
    FaceInfo? face,
  }) {
    var image = source;

    // 1. 换底（有蒙版时）。
    if (mattingMask != null && background != null) {
      image = _composeBackground(image, mattingMask, background);
    }

    // 2. 换装（贴图式，默认关闭）。
    if (dress != DressTemplate.none && face != null) {
      image = const DressService().dress(
        image,
        dress,
        faceTop: face.boundingBox.top,
        faceBottom: face.boundingBox.bottom,
        faceCenterX: face.boundingBox.centerX,
        faceWidth: face.boundingBox.width,
      );
    }

    // 3. 色彩优化。
    if (!enhancement.isIdentity) {
      image = const ColorEnhanceService().enhance(image, enhancement);
    }
    return image;
  }

  /// 用蒙版把 [source] 合成到背景上。
  ///
  /// 支持纯色与渐变背景；透明背景退化为白色合成
  /// （真正的透明 PNG 导出需 RGBA 编码，属后续增强）。
  img.Image _composeBackground(
    img.Image source,
    Uint8List8 mask,
    PhotoBackground bg,
  ) {
    final out = img.Image.from(source);
    final w = source.width;
    final h = source.height;
    // 图片背景预先解码一次（失败回退纯白）。
    img.Image? bgImage;
    if (bg.type == PhotoBackgroundType.image && bg.imageBytes != null) {
      bgImage = img.decodeImage(bg.imageBytes!);
    }
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        final idx = y * w + x;
        final a = mask[idx] / 255.0;
        if (a >= 1.0) continue;
        final src = source.getPixel(x, y);
        final bgc = _bgColorAt(bg, x, y, w, h, bgImage);
        out.setPixelRgb(
          x,
          y,
          (src.r.toInt() * a + bgc.r * (1 - a)).round().clamp(0, 255),
          (src.g.toInt() * a + bgc.g * (1 - a)).round().clamp(0, 255),
          (src.b.toInt() * a + bgc.b * (1 - a)).round().clamp(0, 255),
        );
      }
    }
    return out;
  }

  img.Color _bgColorAt(
    PhotoBackground bg,
    int x,
    int y,
    int w,
    int h,
    [img.Image? bgImage,
  ]) {
    if (bg.type == PhotoBackgroundType.image) {
      if (bgImage != null) {
        final px = (x * bgImage.width / w).floor().clamp(0, bgImage.width - 1);
        final py = (y * bgImage.height / h).floor().clamp(0, bgImage.height - 1);
        final c = bgImage.getPixel(px, py);
        return img.ColorRgb8(c.r.toInt(), c.g.toInt(), c.b.toInt());
      }
      return img.ColorRgb8(255, 255, 255); // 解码失败回退白
    }
    if (bg.isTransparent) return img.ColorRgb8(255, 255, 255);
    final c = bg.color;
    var r = (c >> 16) & 0xFF;
    var g = (c >> 8) & 0xFF;
    var b = c & 0xFF;
    final end = bg.colorEnd;
    if (bg.type == PhotoBackgroundType.gradient && end != null) {
      final t = bg.direction == GradientDirection.topToBottom
          ? (h <= 1 ? 0.0 : y / (h - 1))
          : (w <= 1 ? 0.0 : x / (w - 1));
      final r2 = (end >> 16) & 0xFF;
      final g2 = (end >> 8) & 0xFF;
      final b2 = end & 0xFF;
      r = (r + (r2 - r) * t).round();
      g = (g + (g2 - g) * t).round();
      b = (b + (b2 - b) * t).round();
    }
    return img.ColorRgb8(r, g, b);
  }
}
