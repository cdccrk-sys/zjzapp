#!/usr/bin/env bash
# 本地验证：依赖解析 → 静态分析 → 全部测试。
# 用法：tools/validate_project.sh
set -euo pipefail

cd "$(dirname "${BASH_SOURCE[0]}")/.."

echo "==> flutter pub get"
flutter pub get

echo "==> flutter analyze"
flutter analyze --no-fatal-infos

echo "==> flutter test"
flutter test
