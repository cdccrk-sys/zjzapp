#!/usr/bin/env python3
"""
准备 Android 离线抠图模型。

推荐直接下载与 ZhengPeng7/BiRefNet-portrait 对应的官方 ONNX 转换：
  onnx-community/BiRefNet-portrait-ONNX/onnx/model_fp16.onnx

该 ONNX 权重是由 ZhengPeng7/BiRefNet-portrait 转换得到的部署格式，
不是另一个训练模型。下载后复制为：
  assets/models/birefnet_portrait_fp16.onnx

如果必须从用户指定的 safetensors 原始权重自行转换，请使用：
  ZhengPeng7/BiRefNet-portrait
并按照其仓库提供的 ONNX conversion notebook / scripts 导出。
"""
from pathlib import Path
import urllib.request

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "assets" / "models" / "birefnet_portrait_fp16.onnx"
URL = "https://huggingface.co/onnx-community/BiRefNet-portrait-ONNX/resolve/main/onnx/model_fp16.onnx"

OUT.parent.mkdir(parents=True, exist_ok=True)
print("Downloading ~490 MB ONNX model...")
urllib.request.urlretrieve(URL, OUT)
print(f"Saved: {OUT}")
