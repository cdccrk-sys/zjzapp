#!/usr/bin/env bash
# 下载可选模型资产到 assets/models/。
# 说明（M1-2 起）：
#   - 人脸检测 / 人脸关键点 / blendshapes 模型已随 mediapipe_face_mesh 包内置，
#     无需下载。
#   - 本脚本仅保留 M1-3「AI 抠图」所需的人像分割模型。
# 许可证：全部为 Apache-2.0，可商用（详见 assets/models/README.md）。
set -euo pipefail

DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"
TARGET="$DIR/assets/models"
mkdir -p "$TARGET"

BASE="https://storage.googleapis.com/mediapipe-models"

declare -A MODELS=(
  # 人像分割（AI 抠图，M1-3 起使用）
  ["selfie_segmentation.tflite"]="$BASE/selfie_segmentation/selfie_segmentation/float16/latest/selfie_segmentation.tflite"
)

for name in "${!MODELS[@]}"; do
  url="${MODELS[$name]}"
  if [[ -f "$TARGET/$name" ]]; then
    echo "已存在: $name (跳过)"
    continue
  fi
  echo "下载: $name"
  curl -fL --retry 3 -o "$TARGET/$name" "$url"
done

echo "完成。模型文件："
ls -lh "$TARGET"
