# 证件照工坊 IDPhoto Studio

操作简单、效果专业、隐私安全的证件照制作软件。**全程离线本地处理**，
支持 Android 与 Windows 双平台，8 步向导：导入 → 矫正 → 抠图 → 换背景 →
裁剪 → 优化 → 排版 → 导出。

## 功能总览

- **导入**：JPG/PNG/WEBP/HEIC，拖拽/文件夹/相册导入，EXIF 自动纠正
- **自动矫正**：人脸/眼睛关键点检测，自动旋转、水平校正、居中，侧脸/遮挡/多人脸/模糊提示
- **AI 抠图**：本地 TensorFlow Lite 人像分割（内置模型 ~250KB，Apache-2.0），发丝级边缘，画笔修补
- **换背景**：白/蓝/红/灰/浅蓝/渐变/透明/自定义颜色/自定义图片
- **规格裁剪**：26 种内置规格（一寸/二寸/护照/多国签证/港澳台通行证/教师资格证等），自定义 mm/px/DPI，头部占比/留白/肩线微调
- **色彩优化**：白平衡/亮度/对比/饱和/色温/锐化/磨皮/降噪，5 套预设，肤色保护
- **换装**（默认关闭）：贴图式正装模板，不改变五官比例
- **排版打印**：5/6/7 寸与 A4 相纸，自动网格（1 寸 8 张、A4 一寸 50 张等），JPG/PNG/PDF 导出，300DPI
- **批量处理**：批量抠图、批量换底、统一规格、统一命名
- **导出**：JPG/PNG/透明 PNG/PDF，质量与 DPI 可调
- **隐私**：完全离线、不收集照片，一键清除导出缓存
- **设置与帮助**：主题切换（浅色/深色/跟随系统）、新手引导、FAQ

## 技术栈

Flutter（Android + Windows 双平台）· flutter_riverpod · image · exif ·
MediaPipe FaceMesh（人脸关键点）· TensorFlow Lite（人像分割）· pdf · file_picker

模型许可：`selfie_segmenter.tflite` 来自 MediaPipe（Apache-2.0，可商用）。
本工程无 GPL/AGPL 依赖。

## 目录结构

```
lib/
  app/                 应用根组件、主题、新手引导接线
  domain/
    import/            导入服务（EXIF 校正、降采样、缩略图）
    face/              人脸检测与关键点（MediaPipe + 几何回退）
    matting/           人像分割（TFLite 通道 + 蒙版 + 背景模型）
    pipeline/          统一管线：换底 → 换装 → 优化
    enhance/           色彩优化（预设/白平衡/磨皮/锐化等）
    dress/             贴图式换装
    specs/             证件照规格库（26 种 + 自定义）
    layout/            相纸排版网格
    export/            单张导出 + 排版导出（位图/PDF）
    privacy/           隐私清理
  state/               Riverpod 状态（各步骤 Notifier）
  ui/
    wizard/            8 步向导
    settings/          设置与帮助
    onboarding/        新手引导
  platform/            平台通道（TFLite 原生调用）
```

## 构建

### Android

```bash
flutter pub get
flutter test
flutter build apk --release
# 产物：build/app/outputs/flutter-apk/app-release.apk
```

### Windows

```powershell
powershell -ExecutionPolicy Bypass -File build/windows_build.ps1
```

详见 `docs/WINDOWS_BUILD.md`；CI 双平台构建见 `.github/workflows/build.yml`。

## 测试

```bash
flutter analyze   # 0 issues
flutter test      # 全量测试（领域层/状态层/UI 冒烟）
```

测试覆盖：导入 EXIF、矫正、人脸分析、分割服务、背景合成、裁剪、
增强/换装/管线、排版网格、位图与 PDF 导出、批量抠图、多照片排版、
设置与引导、隐私清理。

## 文档

- 用户手册：`docs/用户手册.md`
- Windows 打包指南：`docs/WINDOWS_BUILD.md`

## 隐私承诺

- 所有图像处理在本机完成，不上传云端
- 不收集照片、不发送统计数据，断网可用
- 「设置 → 清除导出缓存」可删除应用生成的导出文件

## 许可证

项目代码与依赖均兼容商用：Flutter（BSD-3）、MediaPipe（Apache-2.0）、
本项目（MIT）。模型清单与许可见 `assets/models/README.md`。
