import 'dart:io';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/app/app.dart';
import 'package:idphoto_studio/platform/picker/import_picker.dart';
import 'package:idphoto_studio/state/import_state.dart';
import 'package:image/image.dart' as img;
import 'package:integration_test/integration_test.dart';

/// 端到端冒烟测试：真实设备/桌面端运行（Android / Windows CI）。
/// 选择器使用假实现，避免人工交互；其余链路（解码→EXIF→缩略图→UI）全真。
class _FakePicker implements ImportPicker {
  _FakePicker(this.path);

  final String path;

  @override
  Future<List<String>> pickImages() async => [path];

  @override
  Future<String?> pickFolder() async => null;
}

void main() {
  IntegrationTestWidgetsFlutterBinding.ensureInitialized();

  testWidgets('全流程冒烟：导入一张照片并进入下一步', (tester) async {
    final tmp = await Directory.systemTemp.createTemp('idphoto_e2e_');
    addTearDown(() => tmp.delete(recursive: true));

    final image = img.Image(width: 120, height: 160, numChannels: 3);
    img.fill(image, color: img.ColorRgb8(50, 120, 200));
    final file = File('${tmp.path}/e2e.png');
    await file.writeAsBytes(img.encodePng(image));

    await tester.pumpWidget(ProviderScope(
      overrides: [importPickerProvider.overrideWithValue(_FakePicker(file.path))],
      child: const IDPhotoApp(),
    ));
    await tester.pumpAndSettle();

    await tester.tap(find.text('选择照片'));
    await tester.pumpAndSettle();

    expect(find.textContaining('e2e.png'), findsOneWidget);
    expect(find.text('下一步：矫正'), findsOneWidget);

    // 进入矫正步骤：真实 MediaPipe 分析器对纯色图应返回"未检测到人脸"。
    await tester.tap(find.text('下一步：矫正'));
    await tester.pumpAndSettle();
    var detected = false;
    for (var i = 0; i < 60 && !detected; i++) {
      await tester.pump(const Duration(milliseconds: 250));
      detected =
          find.textContaining('未检测到人脸').evaluate().isNotEmpty ||
              find.textContaining('分析器不可用').evaluate().isNotEmpty;
    }
    expect(detected, isTrue, reason: '纯色图应提示未检测到人脸（或分析器降级提示）');
  });
}
