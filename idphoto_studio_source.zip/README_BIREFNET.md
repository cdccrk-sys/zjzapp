# BiRefNet-portrait 抠图模型

已将 Android 抠图后端从旧的 U2Net/TFLite 改为 **BiRefNet-portrait + ONNX Runtime**。

原始模型：
https://huggingface.co/ZhengPeng7/BiRefNet-portrait/resolve/main/model.safetensors

该 safetensors 文件约 885 MB，是 PyTorch 权重，Android 的 ONNX Runtime 不能直接读取。因此项目使用它的 ONNX 部署转换格式 `model_fp16.onnx`。官方/社区提供的对应 ONNX 仓库为：

https://huggingface.co/onnx-community/BiRefNet-portrait-ONNX

## 准备模型

在项目根目录执行：

```bash
python tools/prepare_birefnet_android.py
```

下载后应存在：

```text
assets/models/birefnet_portrait_fp16.onnx
```

然后：

```bash
flutter pub get
flutter build apk --release
```

## 注意

- ONNX 模型约 490 MB，加入 APK 后体积会明显增加。
- 当前推理尺寸为 1024×1024，与 BiRefNet 官方建议的输入分辨率一致。
- 输出是 raw logits，原生层执行 sigmoid 后生成 0~255 mask。
- Windows 仍保留现有几何兜底；Android 优先使用 BiRefNet-portrait。
