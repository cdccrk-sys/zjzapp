# 模型资产目录

本目录存放运行时可选模型文件，由 `tools/download_models.sh` 下载。
为满足"完全离线"需求，模型应随安装包内置（M4 打包阶段固化）。

## 模型清单（M1-3 AI 抠图起使用）

| 文件 | 用途 | 来源 | 许可证 |
| --- | --- | --- | --- |
| `selfie_segmentation.tflite` | 人像分割（AI 抠图） | MediaPipe Selfie Segmentation | Apache-2.0 |

> **M1-2 变更说明**：人脸检测 / 人脸关键点（478 点）/ blendshapes 模型
> 已随 `mediapipe_face_mesh` 包内置（位于
> `packages/mediapipe_face_mesh/assets/models/`），无需再下载，
> 故从本脚本中移除。CI 中该脚本仅用于拉取抠图模型。

## 许可证说明（商用合规）

- 以上模型全部为 **Apache-2.0** 许可，可商用、可再分发，无需付费。
- MediaPipe 本身为 Apache-2.0；`mediapipe_face_mesh` 依赖仅 ffi（BSD/MIT 兼容）。
- 本项目不引入 GPL/AGPL 传染性依赖。

## 体积与下载

- 抠图模型约 5–10MB（float16），相比 rembg（170MB+）显著更小，
  符合移动端安装包体积要求。
- 模型下载后可删除压缩缓存；`.gitignore` 已排除模型文件（不入库，CI 内下载）。

## 验证

```bash
bash tools/download_models.sh
```
