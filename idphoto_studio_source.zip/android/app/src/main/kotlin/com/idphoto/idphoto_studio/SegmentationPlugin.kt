package com.idphoto.idphoto_studio

import ai.onnxruntime.*
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import io.flutter.plugin.common.MethodCall
import io.flutter.plugin.common.MethodChannel
import java.io.File
import java.io.FileOutputStream
import java.nio.FloatBuffer

/**
 * BiRefNet-portrait 人像抠图原生插件。
 *
 * Android 使用 ONNX Runtime CPU 推理，模型输入 [1,3,1024,1024]，
 * 输出 [1,1,1024,1024] raw logits；sigmoid 后转换为 0~255 蒙版。
 *
 * 模型来源：
 * ZhengPeng7/BiRefNet-portrait
 * https://huggingface.co/ZhengPeng7/BiRefNet-portrait
 *
 * Android 不直接读取 .safetensors：safetensors 是 PyTorch 权重格式，
 * 需要先转换为 ONNX。项目随附的模型文件名为：
 * assets/models/birefnet_portrait_fp16.onnx
 */
class SegmentationPlugin(private val context: android.content.Context) :
    MethodChannel.MethodCallHandler {

    companion object {
        const val CHANNEL = "idphoto/segmentation"
        private const val MODEL_SIZE = 1024
        private val MEAN = floatArrayOf(0.485f, 0.456f, 0.406f)
        private val STD = floatArrayOf(0.229f, 0.224f, 0.225f)
    }

    private var env: OrtEnvironment? = null
    private var session: OrtSession? = null

    override fun onMethodCall(call: MethodCall, result: MethodChannel.Result) {
        when (call.method) {
            "load" -> load(call.argument<String>("asset") ?: "", result)
            "segment" -> segment(call.argument<String>("path"), result)
            "close" -> {
                close()
                result.success(null)
            }
            else -> result.notImplemented()
        }
    }

    private fun load(asset: String, result: MethodChannel.Result) {
        if (session != null) {
            result.success("ok")
            return
        }
        synchronized(this) {
            if (session != null) {
                result.success("ok")
                return
            }
            try {
                val modelFile = copyAssetToCache(
                    if (asset.isBlank()) "assets/models/birefnet_portrait_fp16.onnx" else asset
                )
                val e = OrtEnvironment.getEnvironment()
                val options = OrtSession.SessionOptions().apply {
                    setIntraOpNumThreads(2)
                    setInterOpNumThreads(1)
                }
                env = e
                session = e.createSession(modelFile.absolutePath, options)
                options.close()
                result.success("ok")
            } catch (e: Exception) {
                result.error("LOAD_FAIL", e.stackTraceToString(), null)
            }
        }
    }

    private fun segment(path: String?, result: MethodChannel.Result) {
        if (path.isNullOrEmpty()) {
            result.error("BAD_ARG", "path is required", null)
            return
        }
        val sess = session
        val e = env
        if (sess == null || e == null) {
            result.error("NOT_LOADED", "model not loaded", null)
            return
        }
        Thread {
            try {
                val mask = runInference(e, sess, path)
                context.mainExecutor.execute { result.success(mask) }
            } catch (ex: Exception) {
                context.mainExecutor.execute {
                    result.error("SEG_FAIL", ex.stackTraceToString(), null)
                }
            }
        }.start()
    }

    private fun runInference(
        env: OrtEnvironment,
        sess: OrtSession,
        path: String,
    ): ByteArray {
        val bounds = BitmapFactory.Options().apply { inJustDecodeBounds = true }
        BitmapFactory.decodeFile(path, bounds)
        var sample = 1
        while (maxOf(bounds.outWidth, bounds.outHeight) / sample > 2048) sample *= 2
        val opts = BitmapFactory.Options().apply {
            inSampleSize = sample
            inPreferredConfig = Bitmap.Config.ARGB_8888
        }
        val src = BitmapFactory.decodeFile(path, opts)
            ?: throw IllegalStateException("cannot decode image")

        val inputBitmap = Bitmap.createScaledBitmap(src, MODEL_SIZE, MODEL_SIZE, true)
        val pixels = IntArray(MODEL_SIZE * MODEL_SIZE)
        inputBitmap.getPixels(
            pixels, 0, MODEL_SIZE, 0, 0, MODEL_SIZE, MODEL_SIZE
        )
        src.recycle()
        inputBitmap.recycle()

        // NCHW float32. BiRefNet 使用 ImageNet normalization。
        val floats = FloatArray(1 * 3 * MODEL_SIZE * MODEL_SIZE)
        val plane = MODEL_SIZE * MODEL_SIZE
        for (y in 0 until MODEL_SIZE) {
            for (x in 0 until MODEL_SIZE) {
                val p = pixels[y * MODEL_SIZE + x]
                val r = ((p ushr 16) and 0xFF) / 255.0f
                val g = ((p ushr 8) and 0xFF) / 255.0f
                val b = (p and 0xFF) / 255.0f
                val i = y * MODEL_SIZE + x
                floats[i] = (r - MEAN[0]) / STD[0]
                floats[plane + i] = (g - MEAN[1]) / STD[1]
                floats[2 * plane + i] = (b - MEAN[2]) / STD[2]
            }
        }

        val input = OnnxTensor.createTensor(
            env,
            FloatBuffer.wrap(floats),
            longArrayOf(1, 3, MODEL_SIZE.toLong(), MODEL_SIZE.toLong())
        )

        input.use {
            sess.run(mapOf("input_image" to input)).use { outputs ->
                val raw = outputs[0].value
                val logits = flattenFloatArray(raw)
                val expected = MODEL_SIZE * MODEL_SIZE
                if (logits.size != expected) {
                    throw IllegalStateException(
                        "unexpected output size: ${logits.size}, expected: $expected"
                    )
                }

                val mask = ByteArray(MODEL_SIZE * MODEL_SIZE)
                var min = Float.POSITIVE_INFINITY
                var max = Float.NEGATIVE_INFINITY
                for (i in logits.indices) {
                    val x = logits[i]
                    if (x < min) min = x
                    if (x > max) max = x
                    val p = if (x >= 0f) {
                        1f / (1f + kotlin.math.exp(-x))
                    } else {
                        val ex = kotlin.math.exp(x)
                        ex / (1f + ex)
                    }
                    mask[i] = kotlin.math.round(p * 255f).toInt().coerceIn(0, 255).toByte()
                }
                return mask
            }
        }
    }


    private fun flattenFloatArray(value: Any?): FloatArray {
        val out = FloatArray(MODEL_SIZE * MODEL_SIZE)
        var pos = 0

        fun visit(v: Any?) {
            when (v) {
                is FloatArray -> {
                    for (x in v) {
                        if (pos >= out.size) {
                            throw IllegalStateException("output tensor is larger than expected")
                        }
                        out[pos++] = x
                    }
                }
                is Array<*> -> {
                    for (x in v) visit(x)
                }
                else -> throw IllegalStateException(
                    "unexpected output element type: ${v?.javaClass}"
                )
            }
        }

        visit(value)
        if (pos != out.size) {
            throw IllegalStateException(
                "output tensor has $pos float values, expected ${out.size}"
            )
        }
        return out
    }

    private fun copyAssetToCache(asset: String): File {
        val target = File(context.cacheDir, asset.substringAfterLast('/'))
        if (target.exists() && target.length() > 0) return target
        val candidates = listOf(asset, "flutter_assets/$asset")
        for (candidate in candidates) {
            try {
                context.assets.open(candidate).use { input ->
                    FileOutputStream(target).use { output -> input.copyTo(output) }
                }
                if (target.length() > 0) return target
            } catch (_: Exception) {
            }
        }
        throw IllegalStateException("asset not found: $asset")
    }

    private fun close() {
        synchronized(this) {
            try { session?.close() } catch (_: Exception) {}
            session = null
            env = null
        }
    }
}
