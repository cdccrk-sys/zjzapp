package com.idphoto.idphoto_studio

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import io.flutter.embedding.android.FlutterActivity
import io.flutter.embedding.engine.FlutterEngine
import io.flutter.plugin.common.MethodChannel
import java.io.ByteArrayOutputStream

/**
 * 证件照工坊 Android 入口。
 *
 * 注册 HEIC 解码通道（idphoto/heic）：使用系统解码器（BitmapFactory，
 * Android 9+/API 28+ 原生支持 HEIF）将 HEIC 解码为 PNG 字节返回 Dart 层。
 * 注意：系统解码器会应用 HEIF 方向元数据，Dart 侧不再二次矫正。
 */
class MainActivity : FlutterActivity() {
    override fun configureFlutterEngine(flutterEngine: FlutterEngine) {
        super.configureFlutterEngine(flutterEngine)
        MethodChannel(flutterEngine.dartExecutor.binaryMessenger, CHANNEL)
            .setMethodCallHandler { call, result ->
                when (call.method) {
                    "decode" -> decodeHeic(call.argument<String>("path"), result)
                    else -> result.notImplemented()
                }
            }
        // AI 人像分割（TensorFlow Lite，离线）
        MethodChannel(
            flutterEngine.dartExecutor.binaryMessenger,
            SegmentationPlugin.CHANNEL,
        ).setMethodCallHandler(SegmentationPlugin(this))
    }

    private fun decodeHeic(path: String?, result: MethodChannel.Result) {
        if (path == null) {
            result.error("BAD_ARG", "path is required", null)
            return
        }
        try {
            val bmp = BitmapFactory.decodeFile(path)
                ?: run {
                    result.error("DECODE_FAIL", "system decoder returned null", null)
                    return
                }
            val out = ByteArrayOutputStream()
            bmp.compress(Bitmap.CompressFormat.PNG, 100, out)
            bmp.recycle()
            result.success(out.toByteArray())
        } catch (e: Exception) {
            result.error("DECODE_FAIL", e.message, null)
        }
    }

    companion object {
        private const val CHANNEL = "idphoto/heic"
    }
}
