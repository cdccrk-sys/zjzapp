# 证件照工坊 Windows 桌面版构建指南

本指南面向需要在 Windows 上构建/打包证件照工坊的用户。
Android APK 的构建请直接使用 `flutter build apk --release`（或提交到本仓库的 CI）。

## 环境要求

| 项 | 版本 |
| --- | --- |
| Windows | 10 / 11（64 位） |
| Flutter SDK | 3.27 及以上（stable 渠道，含 Windows 桌面支持） |
| Visual Studio | 2022（安装「使用 C++ 的桌面开发」工作负载） |
| 可选 | Inno Setup 6（制作安装包） |

## 构建步骤

1. 安装 Flutter SDK 并执行 `flutter doctor`，确认 `Windows desktop` 与 `Visual Studio` 均为绿色。
2. 在项目根目录运行：

   ```powershell
   powershell -ExecutionPolicy Bypass -File build/windows_build.ps1
   ```

   脚本会自动完成：启用桌面支持 → pub get → 测试 → `flutter build windows --release`。

3. 产物位于 `build/windows/x64/runner/Release/`：
   - `idphoto_studio.exe`（主程序）
   - 若干 DLL（Flutter 引擎、tensorflow lite 等）
   - `data/`（含内置分割模型与资源）

## 分发方式

### 便携版
将整个 `Release/` 目录压缩为 zip 即可分发，用户解压后双击 exe 使用。

### 安装包（Inno Setup）
新建 `installer.iss`（示例）：

```ini
[Setup]
AppName=证件照工坊
AppVersion=0.5.0
DefaultDirName={autopf}\IDPhotoStudio
OutputDir=output

[Files]
Source: "build\windows\x64\runner\Release\*"; DestDir: "{app}"; Flags: recursesubdirs
```

执行 `ISCC.exe installer.iss` 生成安装包。

## 说明

- 应用默认完全离线：分割模型内置于 `data/flutter_assets/assets/models/`，
  不依赖网络与第三方服务。
- 若需要数字签名，请使用代码签名证书对 exe 签名后再分发。
