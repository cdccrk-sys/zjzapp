import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/import/image_item.dart';
import 'package:idphoto_studio/domain/matting/background.dart';
import 'package:idphoto_studio/domain/matting/matting_service.dart';
import 'package:idphoto_studio/domain/matting/segmenter.dart';
import 'package:idphoto_studio/state/matting_state.dart';
import 'package:image/image.dart' as img;

/// 假分割器：返回全前景蒙版。
class _FakeSegmenter implements Segmenter {
  bool fail = false;
  String source = 'fake';
  int callCount = 0;

  @override
  Future<SegmentationResult> segment(img.Image image) async {
    callCount++;
    if (fail) {
      return SegmentationResult(
        mask: Uint8List(image.width * image.height),
        width: image.width,
        height: image.height,
        source: source,
        succeeded: false,
      );
    }
    return SegmentationResult(
      mask: Uint8List.fromList(List.filled(image.width * image.height, 255)),
      width: image.width,
      height: image.height,
      source: source,
      succeeded: true,
    );
  }
}

ImageItem makeItem({int w = 8, int h = 8, String id = 'i1'}) {
  final im = img.Image(width: w, height: h, numChannels: 3);
  for (var y = 0; y < h; y++) {
    for (var x = 0; x < w; x++) {
      im.setPixelRgb(x, y, x * 30 % 255, 100, 200);
    }
  }
  return ImageItem(
    id: id,
    fileName: '$id.jpg',
    sourcePath: '/tmp/$id.jpg',
    workingBytes: Uint8List.fromList(img.encodeJpg(im, quality: 90)),
    workingWidth: w,
    workingHeight: h,
    thumbnailBytes: Uint8List.fromList(img.encodeJpg(im, quality: 60)),
    originalWidth: w,
    originalHeight: h,
    exifOrientation: 1,
    exifCorrected: false,
    importedAt: DateTime.now(),
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();
  late _FakeSegmenter segmenter;
  late MattingNotifier notifier;

  setUp(() {
    segmenter = _FakeSegmenter();
    notifier = MattingNotifier(segmenter, const MattingService());
  });

  group('MattingNotifier.segment', () {
    test('成功后保存蒙版与来源', () async {
      final item = makeItem();
      final ok = await notifier.segment(item);
      expect(ok, true);
      final mask = notifier.state.masks[item.id];
      expect(mask, isNotNull);
      expect(mask!.length, 8 * 8);
      expect(mask[0], 255);
      expect(notifier.state.sources[item.id], 'fake');
      expect(notifier.state.isProcessing, false);
    });

    test('主分割失败时回退几何兜底成功', () async {
      segmenter.fail = true;
      final item = makeItem();
      final ok = await notifier.segment(item);
      // 几何兜底会返回成功（对小图也能生成蒙版）。
      expect(ok, isA<bool>());
      expect(notifier.state.isProcessing, false);
    });

    test('处理期间拒绝并发', () async {
      final item = makeItem();
      notifier.state = notifier.state.copyWith(isProcessing: true);
      final ok = await notifier.segment(item);
      expect(ok, false);
      expect(segmenter.callCount, 0);
    });
  });

  group('MattingNotifier.repair', () {
    test('修改蒙版局部像素', () async {
      final item = makeItem();
      await notifier.segment(item);
      notifier.repair(item, 2, 2, 1, add: false);
      final mask = notifier.state.masks[item.id]!;
      expect(mask[2 * 8 + 2], 0); // 涂黑
      expect(mask[0], 255); // 其余保留
    });

    test('无蒙版时安全', () {
      final item = makeItem();
      notifier.repair(item, 0, 0, 2, add: true); // 不应抛异常
      expect(notifier.state.masks[item.id], isNull);
    });
  });

  group('MattingNotifier.reset / setBackground', () {
    test('reset 移除蒙版', () async {
      final item = makeItem();
      await notifier.segment(item);
      expect(notifier.state.masks[item.id], isNotNull);
      notifier.reset(item);
      expect(notifier.state.masks[item.id], isNull);
    });

    test('setBackground 更新背景', () {
      expect(notifier.state.selectedBackground, PhotoBackground.white);
      notifier.setBackground(PhotoBackground.blue);
      expect(notifier.state.selectedBackground, PhotoBackground.blue);
      notifier.setBackground(PhotoBackground.transparent);
      expect(notifier.state.selectedBackground.isTransparent, true);
    });
  });
}
