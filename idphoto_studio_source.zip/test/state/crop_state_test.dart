import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/crop/crop_service.dart';
import 'package:idphoto_studio/domain/face/face_models.dart';
import 'package:idphoto_studio/domain/import/image_item.dart';
import 'package:idphoto_studio/domain/specs/idphoto_specs.dart';
import 'package:idphoto_studio/state/crop_state.dart';
import 'package:image/image.dart' as img;

ImageItem makeItem({int w = 300, int h = 400, String id = 'c1'}) {
  final im = img.Image(width: w, height: h, numChannels: 3);
  img.fill(im, color: img.ColorRgb8(150, 170, 200));
  return ImageItem(
    id: id,
    fileName: '$id.jpg',
    sourcePath: '/tmp/$id.jpg',
    workingBytes: Uint8List.fromList(img.encodeJpg(im, quality: 90)),
    workingWidth: w,
    workingHeight: h,
    thumbnailBytes: Uint8List.fromList(img.encodeJpg(im, quality: 60)),
    originalWidth: w,
    originalHeight: h,
    exifOrientation: 1,
    exifCorrected: false,
    importedAt: DateTime.now(),
  );
}

const _face = FaceInfo(
  boundingBox: NormalizedRect(left: 0.2, top: 0.1, right: 0.8, bottom: 0.9),
  leftEye: FacePoint(0.4, 0.35),
  rightEye: FacePoint(0.6, 0.35),
  nose: FacePoint(0.5, 0.48),
  chin: FacePoint(0.5, 0.62),
);

FaceAnalysisResult _analysis(img.Image image) => FaceAnalysisResult(
      faces: const [_face],
      imageWidth: image.width,
      imageHeight: image.height,
      blurScore: 100,
    );

void main() {
  late CropNotifier notifier;

  setUp(() {
    notifier = CropNotifier(const CropService());
  });

  group('CropNotifier.selectSpec', () {
    test('切换规格并清空裁剪框', () async {
      final item = makeItem();
      await notifier.autoCrop(item, _analysis(img.decodeImage(item.workingBytes)!));
      expect(notifier.state.rects[item.id], isNotNull);
      notifier.selectSpec(IdPhotoSpec.byId('inch2')!);
      expect(notifier.state.selectedSpecId, 'inch2');
      expect(notifier.state.rects, isEmpty);
    });
  });

  group('CropNotifier.autoCrop', () {
    test('有分析结果时生成规格比例裁框', () async {
      final item = makeItem();
      await notifier.autoCrop(item, _analysis(img.decodeImage(item.workingBytes)!));
      final rect = notifier.state.rects[item.id]!;
      final spec = notifier.state.selectedSpec;
      expect(rect.aspectError(spec.aspectRatio), lessThan(0.02));
    });

    test('无分析结果时居中裁框', () async {
      final item = makeItem();
      await notifier.autoCrop(item, null);
      final rect = notifier.state.rects[item.id]!;
      expect(rect.x, greaterThanOrEqualTo(0));
      expect(rect.width, greaterThan(0));
    });

    test('处理中拒绝并发', () async {
      final item = makeItem();
      notifier.state = notifier.state.copyWith(isApplying: true);
      await notifier.autoCrop(item, null);
      expect(notifier.state.rects[item.id], isNull);
    });
  });

  group('CropNotifier.shift / zoom', () {
    test('平移更新坐标并 clamp 到图像边界', () async {
      final item = makeItem();
      await notifier.autoCrop(item, null);
      final before = notifier.state.rects[item.id]!;
      // 初始框贴近左上角：向左上移动会被 clamp 到 0,0。
      notifier.shift(item, -20, -10);
      final clamped = notifier.state.rects[item.id]!;
      expect(clamped.x, 0);
      expect(clamped.y, 0);
      expect(clamped.width, before.width);
      // 向右移动应生效（x 上限=300-286=14；y 满高不可移）。
      notifier.shift(item, 10, 10);
      final moved = notifier.state.rects[item.id]!;
      expect(moved.x, 10);
      expect(moved.y, 0);
    });

    test('缩放保持比例并可缩小放大', () async {
      final item = makeItem();
      await notifier.autoCrop(item, null);
      final before = notifier.state.rects[item.id]!;
      // 缩小。
      notifier.zoom(item, 0.8);
      final smaller = notifier.state.rects[item.id]!;
      expect(smaller.width, lessThan(before.width));
      expect(smaller.aspectError(notifier.state.selectedSpec.aspectRatio),
          lessThan(0.02));
      // 等比例放大回原尺寸。
      notifier.zoom(item, 1.25);
      final restored = notifier.state.rects[item.id]!;
      expect(restored.width, before.width);
      expect(restored.aspectError(notifier.state.selectedSpec.aspectRatio),
          lessThan(0.02));
    });

    test('无裁框时安全', () {
      final item = makeItem();
      notifier.shift(item, 10, 10);
      notifier.zoom(item, 1.2);
      expect(notifier.state.rects[item.id], isNull);
    });
  });
}
