import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/export/print_export_service.dart';
import 'package:idphoto_studio/domain/specs/idphoto_specs.dart';
import 'package:idphoto_studio/state/print_state.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';

class _FakePathProvider extends PathProviderPlatform {
  @override
  Future<String> getApplicationDocumentsPath() async {
    return Directory.systemTemp.path;
  }

  @override
  Future<String> getTemporaryPath() async {
    return Directory.systemTemp.path;
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late PrintNotifier notifier;

  setUp(() {
    PathProviderPlatform.instance = _FakePathProvider();
    notifier = PrintNotifier(PrintExportService());
  });

  img.Image makePhoto() {
    final im = img.Image(width: 295, height: 413, numChannels: 3);
    img.fill(im, color: img.ColorRgb8(180, 200, 220));
    return im;
  }

  group('PrintNotifier', () {
    test('computeLayout 生成排版（5 寸一寸 8 张）', () {
      final spec = IdPhotoSpec.byId('inch1')!;
      notifier.computeLayout(spec, count: 8);
      final l = notifier.state.layout!;
      expect(l.paper.id, 'photo6'); // 默认 6 寸
      expect(l.total, 8);
      expect(l.perPage, greaterThanOrEqualTo(8));
    });

    test('切换相纸后需重算（layout 清空）', () {
      final spec = IdPhotoSpec.byId('inch1')!;
      notifier.computeLayout(spec, count: 8);
      expect(notifier.state.layout, isNotNull);
      notifier.setPaper('a4');
      expect(notifier.state.layout, isNull);
    });

    test('设置间距/边距/选项', () {
      notifier.setGap(4);
      notifier.setMargin(12);
      notifier.setOptions(const PrintExportOptions(showBleed: true));
      expect(notifier.state.gapMm, 4);
      expect(notifier.state.marginMm, 12);
      expect(notifier.state.options.showBleed, true);
    });

    test('无排版时导出安全', () async {
      await notifier.exportSheet(makePhoto(), IdPhotoSpec.byId('inch1')!);
      expect(notifier.state.results, isEmpty);
      expect(notifier.state.failures, isEmpty);
    });

    test('exportSheet 成功写出排版图', () async {
      final spec = IdPhotoSpec.byId('inch1')!;
      notifier.computeLayout(spec, count: 8);
      await notifier.exportSheet(makePhoto(), spec);
      expect(notifier.state.results.length, 1);
      expect(notifier.state.failures, isEmpty);
      expect(File(notifier.state.results.first.path).existsSync(), true);
    });

    test('exportPdf 成功写出 PDF', () async {
      final spec = IdPhotoSpec.byId('inch1')!;
      notifier.computeLayout(spec, count: 8);
      await notifier.exportPdf(makePhoto(), spec);
      expect(notifier.state.results.length, 1);
      expect(notifier.state.results.first.fileName, endsWith('.pdf'));
      expect(File(notifier.state.results.first.path).existsSync(), true);
    });
  });
}
