import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/dress/dress_service.dart';
import 'package:idphoto_studio/domain/enhance/enhance_service.dart';
import 'package:idphoto_studio/state/enhance_state.dart';
import 'package:idphoto_studio/state/settings_state.dart';

void main() {
  group('EnhanceNotifier', () {
    test('默认自然预设且不换装', () {
      final n = EnhanceNotifier();
      expect(n.state.preset, EnhancementPreset.natural);
      expect(n.state.dress, DressTemplate.none);
      expect(n.state.params.whiteBalance, true);
    });

    test('切换预设重置参数', () {
      final n = EnhanceNotifier();
      n.setPreset(EnhancementPreset.hd);
      expect(n.state.params.sharpen, 50);
      n.setBrightness(20);
      expect(n.state.params.brightness, 20);
      // 再切预设参数复位。
      n.setPreset(EnhancementPreset.soft);
      expect(n.state.params.brightness, 0);
      expect(n.state.params.smooth, 30);
    });

    test('滑杆参数与换装', () {
      final n = EnhanceNotifier();
      n.setContrast(1.3);
      n.setSaturation(0.8);
      n.setDress(DressTemplate.menSuit);
      expect(n.state.params.contrast, 1.3);
      expect(n.state.params.saturation, 0.8);
      expect(n.state.dress, DressTemplate.menSuit);
    });

    test('reset 恢复默认', () {
      final n = EnhanceNotifier();
      n.setPreset(EnhancementPreset.bright);
      n.setDress(DressTemplate.whiteShirt);
      n.reset();
      expect(n.state.preset, EnhancementPreset.natural);
      expect(n.state.dress, DressTemplate.none);
      expect(n.state.params.brightness, 0);
    });
  });

  group('SettingsNotifier', () {
    test('主题切换', () {
      final n = SettingsNotifier();
      expect(n.state.themeMode.name, 'system');
      n.setThemeMode(ThemeMode.dark);
      expect(n.state.themeMode, ThemeMode.dark);
    });

    test('自动更新默认关闭可切换', () {
      final n = SettingsNotifier();
      expect(n.state.checkUpdate, false);
      n.setCheckUpdate(true);
      expect(n.state.checkUpdate, true);
    });
  });
}
