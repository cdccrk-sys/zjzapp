import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/export/export_service.dart';
import 'package:idphoto_studio/state/export_state.dart';

void main() {
  late ExportNotifier notifier;

  setUp(() {
    notifier = ExportNotifier(ExportService());
  });

  group('ExportNotifier', () {
    test('setResults 写入结果与失败', () {
      notifier.setResults(
        const [
          ExportResultItem(
            path: '/tmp/a.jpg',
            fileName: 'a.jpg',
            sizeBytes: 1024,
            width: 295,
            height: 413,
          ),
        ],
        const ['bad.png'],
        DateTime(2026, 9, 17),
      );
      expect(notifier.state.results.length, 1);
      expect(notifier.state.results.first.fileName, 'a.jpg');
      expect(notifier.state.failures, ['bad.png']);
      expect(notifier.state.exportedAt, DateTime(2026, 9, 17));
      expect(notifier.state.isExporting, false);
    });

    test('reset 清空', () async {
      notifier.setResults(const [], const ['x'], null);
      await notifier.reset();
      expect(notifier.state.results, isEmpty);
      expect(notifier.state.failures, isEmpty);
    });

    test('shareAll 无结果时安全', () async {
      await notifier.shareAll(); // 不应抛异常
      expect(notifier.state.results, isEmpty);
    });
  });
}
