import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/specs/idphoto_specs.dart';

void main() {
  group('IdPhotoSpec 像素换算', () {
    test('一寸 25×35mm @300DPI = 295×413px', () {
      final s = IdPhotoSpec.byId('inch1')!;
      expect(s.pixelWidth, 295);
      expect(s.pixelHeight, 413);
      expect(s.aspectRatio, closeTo(25 / 35, 0.001));
    });

    test('二寸 35×49mm @300DPI = 413×579px', () {
      final s = IdPhotoSpec.byId('inch2')!;
      expect(s.pixelWidth, 413);
      expect(s.pixelHeight, 579);
    });

    test('美国签证 51×51 方形', () {
      final s = IdPhotoSpec.byId('usvisa')!;
      expect(s.pixelWidth, 602);
      expect(s.pixelHeight, 602);
      expect(s.aspectRatio, 1.0);
    });

    test('自定义规格与 DPI 生效', () {
      const s = IdPhotoSpec(
        id: 'custom',
        name: '自定义',
        widthMm: 30,
        heightMm: 40,
        dpi: 600,
      );
      expect(s.pixelWidth, 709); // 30/25.4*600 = 708.66 → 709
      expect(s.pixelHeight, 945);
    });
  });

  group('IdPhotoSpec 规格库', () {
    test('内置规格 id 唯一', () {
      final ids = IdPhotoSpec.builtin.map((e) => e.id).toSet();
      expect(ids.length, IdPhotoSpec.builtin.length);
    });

    test('byId 命中与未命中', () {
      expect(IdPhotoSpec.byId('passport')?.name, '护照');
      expect(IdPhotoSpec.byId('nope'), isNull);
    });

    test('所有规格尺寸为正', () {
      for (final s in IdPhotoSpec.builtin) {
        expect(s.widthMm, greaterThan(0));
        expect(s.heightMm, greaterThan(0));
        expect(s.pixelWidth, greaterThan(0));
        expect(s.pixelHeight, greaterThan(0));
      }
    });
  });
}
