import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/matting/background.dart';
import 'package:idphoto_studio/domain/matting/matting_service.dart';
import 'package:image/image.dart' as img;

void main() {
  const service = MattingService();

  /// 构造 4x4 测试图：左半白、右半黑。
  img.Image makeSource({int w = 4, int h = 4}) {
    final im = img.Image(width: w, height: h, numChannels: 3);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        im.setPixelRgb(x, y, x < w ~/ 2 ? 255 : 0, x < w ~/ 2 ? 255 : 0,
            x < w ~/ 2 ? 255 : 0);
      }
    }
    return im;
  }

  /// 构造蒙版：左半 255（前景），右半 0（背景）。
  Uint8List makeMask(int w, int h) {
    final m = Uint8List(w * h);
    for (var y = 0; y < h; y++) {
      for (var x = 0; x < w; x++) {
        m[y * w + x] = x < w ~/ 2 ? 255 : 0;
      }
    }
    return m;
  }

  group('MattingService.buildAlphaImage', () {
    test('阈值化：前景保留原色且 alpha=255，背景 alpha=0', () {
      final src = makeSource();
      final mask = makeMask(4, 4);
      final alpha = service.buildAlphaImage(src, mask, threshold: 128);
      expect(alpha.width, 4);
      expect(alpha.height, 4);
      // 前景 (0,0) alpha=255、颜色=255
      expect(alpha.getPixel(0, 0).a.toInt(), 255);
      expect(alpha.getPixel(0, 0).r.toInt(), 255);
      // 背景 (3,0) alpha=0
      expect(alpha.getPixel(3, 0).a.toInt(), 0);
      // alpha=0 的像素颜色应为 0（不显示）
      expect(alpha.getPixel(3, 0).r.toInt(), 0);
    });

    test('羽化后前景与背景边界出现中间 alpha', () {
      final src = makeSource();
      final mask = makeMask(4, 4);
      final alpha = service.buildAlphaImage(src, mask,
          featherRadius: 2, threshold: 128);
      // 边界像素 alpha 应介于 0 与 255 之间（羽化过渡）
      final boundary = alpha.getPixel(2, 1).a.toInt();
      expect(boundary, greaterThan(0));
      expect(boundary, lessThan(255));
    });

    test('收缩：前景边缘向内收缩 1px', () {
      final src = makeSource(w: 6, h: 6);
      final mask = makeMask(6, 6); // 左 3 列前景
      final alpha = service.buildAlphaImage(src, mask,
          threshold: 128, erode: 1, featherRadius: 0);
      // 收缩后 x=2（原前景边界列）应变为背景 alpha=0
      expect(alpha.getPixel(2, 3).a.toInt(), 0);
      expect(alpha.getPixel(1, 3).a.toInt(), 255);
    });

    test('扩张：背景边缘向外扩张 1px', () {
      final src = makeSource(w: 6, h: 6);
      final mask = makeMask(6, 6); // 右 3 列背景
      final alpha = service.buildAlphaImage(src, mask,
          threshold: 128, erode: -1, featherRadius: 0);
      // 扩张后 x=3（原背景边界列）应变为前景 alpha=255
      expect(alpha.getPixel(3, 3).a.toInt(), 255);
      expect(alpha.getPixel(5, 3).a.toInt(), 0);
    });
  });

  group('MattingService.composite', () {
    test('白底合成：背景区域为纯白，前景保留原色', () {
      final src = makeSource();
      final mask = makeMask(4, 4);
      final out = service.composite(src, mask, threshold: 128);
      // 前景 (0,0)：白
      expect(out.getPixel(0, 0).r.toInt(), 255);
      // 背景 (3,0)：白底混合 = 白
      expect(out.getPixel(3, 0).r.toInt(), 255);
    });

    test('蓝底合成：背景区域为纯蓝', () {
      final src = makeSource();
      final mask = makeMask(4, 4);
      final out = service.composite(src, mask,
          background: PhotoBackground.blue, threshold: 128);
      // 背景 (3,0)：纯蓝 #438EDB → r=0x43, g=0x8E, b=0xDB
      expect(out.getPixel(3, 0).r.toInt(), 0x43);
      expect(out.getPixel(3, 0).g.toInt(), 0x8E);
      expect(out.getPixel(3, 0).b.toInt(), 0xDB);
    });

    test('透明底：输出 RGBA 且背景 alpha=0', () {
      final src = makeSource();
      final mask = makeMask(4, 4);
      final out = service.composite(src, mask,
          background: PhotoBackground.transparent, threshold: 128);
      expect(out.numChannels, 4);
      expect(out.getPixel(3, 0).a.toInt(), 0);
      expect(out.getPixel(0, 0).a.toInt(), 255);
    });

    test('渐变底：顶部与底部颜色不同', () {
      final src = makeSource();
      final mask = makeMask(4, 4);
      final out = service.composite(src, mask,
          background: PhotoBackground.whiteToLightBlue, threshold: 128);
      // 背景列 x=3：顶行纯白(255,255,255)，底行浅蓝(201,226,247)
      // 红色分量递减体现蓝色渐变。
      final topR = out.getPixel(3, 0).r.toInt();
      final bottomR = out.getPixel(3, 3).r.toInt();
      expect(topR, 255);
      expect(bottomR, lessThan(topR));
    });
  });

  group('MattingService.repair', () {
    test('背景笔：圆心半径内涂黑', () {
      final mask = Uint8List(100); // 10x10 全 0（全背景）
      for (var i = 0; i < 100; i++) {
        mask[i] = 255;
      }
      final out = service.repair(mask, 10, 10, 4, 4, 2, add: false);
      // (4,4) 被涂黑
      expect(out[4 * 10 + 4], 0);
      // (0,0) 不受影响
      expect(out[0], 255);
      // 远处 (9,9) 不受影响
      expect(out[9 * 10 + 9], 255);
    });

    test('前景笔：在背景区域画白', () {
      final mask = Uint8List(100);
      final out = service.repair(mask, 10, 10, 2, 2, 3, add: true);
      expect(out[2 * 10 + 2], 255);
      // (0,0) 与圆心距离 sqrt(8)≈2.83 ≤ 3，也在圆内。
      expect(out[0], 255);
      // (9,9) 远在圆外。
      expect(out[9 * 10 + 9], 0);
    });

    test('半径越界安全', () {
      final mask = Uint8List(100);
      final out = service.repair(mask, 10, 10, 0, 0, 5, add: true);
      expect(out[0], 255); // 左上角被涂
      expect(out[9 * 10 + 9], 0);
    });
  });

  group('MattingService.foregroundRatio', () {
    test('全前景占比 1，全背景占比 0', () {
      final allFg = Uint8List.fromList(List.filled(16, 255));
      final allBg = Uint8List.fromList(List.filled(16, 0));
      expect(service.foregroundRatio(allFg, 4, 4), 1.0);
      expect(service.foregroundRatio(allBg, 4, 4), 0.0);
    });

    test('阈值以下不计入前景', () {
      final m = Uint8List.fromList(List.filled(16, 100));
      expect(service.foregroundRatio(m, 4, 4, threshold: 128), 0.0);
    });
  });
}
