import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/matting/segmenter.dart';
import 'package:image/image.dart' as img;

void main() {
  test('几何兜底：纯色背景人像不会被整体抠除（中心先验保底）', () async {
    // 构造 200x300 测试图：纯白背景 + 中心肤色椭圆（模拟证件照自拍）。
    final image = img.Image(width: 200, height: 300, numChannels: 3);
    img.fill(image, color: img.ColorRgb8(255, 255, 255));
    img.fillCircle(
      image,
      x: 100,
      y: 130,
      radius: 50,
      color: img.ColorRgb8(235, 180, 150),
    );

    const s = GeometricFallbackSegmenter();
    final r = await s.segment(image);
    expect(r.succeeded, true);
    expect(r.width, 200);
    expect(r.height, 300);
    expect(r.mask.length, 200 * 300);

    // 中心（人像）必须为前景。
    final center = r.mask[130 * 200 + 100];
    expect(center, 255, reason: '中心人像必须保留为前景');
    // 角落（背景）应为背景。
    final corner = r.mask[0];
    expect(corner, 0, reason: '四角背景应为背景');
    // 前景占比合理：既不全抠（>0）也不全保留（<100%）。
    var fg = 0;
    for (var i = 0; i < r.mask.length; i++) {
      if (r.mask[i] > 127) fg++;
    }
    final ratio = fg / r.mask.length;
    expect(ratio > 0.05, true, reason: '前景占比不应接近 0（不能被整体抠除）');
    expect(ratio < 0.95, true, reason: '前景占比不应接近 100%（背景应被抠除）');
  });

  test('几何兜底：不同四角颜色下中心椭圆仍保底为前景', () async {
    final image = img.Image(width: 120, height: 160, numChannels: 3);
    // 四角不同颜色（模拟复杂背景）。
    img.fill(image, color: img.ColorRgb8(90, 140, 200));
    img.fillRect(image,
        x1: 0, y1: 0, x2: 119, y2: 79, color: img.ColorRgb8(150, 200, 230));
    img.fillCircle(
      image,
      x: 60,
      y: 70,
      radius: 25,
      color: img.ColorRgb8(30, 30, 30),
    );

    final r = await const GeometricFallbackSegmenter().segment(image);
    final center = r.mask[70 * 120 + 60];
    expect(center, 255, reason: '复杂背景下中心人像仍应保留');
  });
}
