import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/crop/crop_service.dart';
import 'package:idphoto_studio/domain/export/export_service.dart';
import 'package:idphoto_studio/domain/specs/idphoto_specs.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';

/// 假 PathProvider：文档目录指向系统临时目录。
class _FakePathProvider extends PathProviderPlatform {
  @override
  Future<String> getApplicationDocumentsPath() async {
    return Directory.systemTemp.path;
  }

  @override
  Future<String> getTemporaryPath() async {
    return Directory.systemTemp.path;
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late ExportService service;
  late Directory tempDocs;

  setUp(() async {
    PathProviderPlatform.instance = _FakePathProvider();
    service = ExportService();
    tempDocs = Directory('${Directory.systemTemp.path}/idphoto_test_exports');
    if (tempDocs.existsSync()) tempDocs.deleteSync(recursive: true);
  });

  tearDown(() async {
    if (tempDocs.existsSync()) tempDocs.deleteSync(recursive: true);
  });

  img.Image makeSrc({int w = 600, int h = 800}) {
    final im = img.Image(width: w, height: h, numChannels: 3);
    img.fill(im, color: img.ColorRgb8(180, 200, 220));
    return im;
  }

  group('ExportService.exportOne', () {
    test('导出 JPG：文件存在、尺寸正确、扩展名正确', () async {
      final src = makeSrc();
      const rect = CropRect(x: 50, y: 50, width: 300, height: 400);
      final spec = IdPhotoSpec.byId('inch1')!;
      final item = await service.exportOne(
        src,
        rect,
        spec,
        format: ExportFormat.jpg,
        customName: 'test_jpg',
      );
      expect(item.width, spec.pixelWidth);
      expect(item.height, spec.pixelHeight);
      expect(item.fileName, 'test_jpg.jpg');
      expect(item.sizeBytes, greaterThan(0));
      final f = File(item.path);
      expect(f.existsSync(), true);
      // 回读验证可解码。
      final back = img.decodeImage(f.readAsBytesSync());
      expect(back, isNotNull);
      expect(back!.width, spec.pixelWidth);
      expect(back.height, spec.pixelHeight);
    });

    test('导出 PNG：magic 字节正确', () async {
      final src = makeSrc();
      const rect = CropRect(x: 0, y: 0, width: 200, height: 300);
      final spec = IdPhotoSpec.byId('usvisa')!;
      final item = await service.exportOne(
        src,
        rect,
        spec,
        format: ExportFormat.png,
        customName: 'test_png',
      );
      expect(item.fileName, 'test_png.png');
      final bytes = File(item.path).readAsBytesSync();
      expect(bytes.sublist(0, 4), [0x89, 0x50, 0x4E, 0x47]); // PNG magic
    });

    test('默认文件名包含规格名与时间戳', () async {
      final src = makeSrc();
      const rect = CropRect(x: 0, y: 0, width: 200, height: 300);
      final spec = IdPhotoSpec.byId('inch2')!;
      final item = await service.exportOne(
        src,
        rect,
        spec,
        timestamp: DateTime(2026, 9, 17, 10, 30, 0),
      );
      expect(item.fileName, contains('二寸'));
      expect(item.fileName, contains('20260917_103000'));
    });
  });

  group('ExportService.exportMany', () {
    test('批量导出成功且命名递增', () async {
      final src = makeSrc();
      const rect = CropRect(x: 0, y: 0, width: 200, height: 300);
      final spec = IdPhotoSpec.byId('inch1')!;
      final results = await service.exportMany([
        (source: src, rect: rect, spec: spec),
        (source: src, rect: rect, spec: spec),
      ]);
      expect(results.length, 2);
      expect(results[0].fileName, '一寸_1.jpg');
      expect(results[1].fileName, '一寸_2.jpg');
      expect(File(results[1].path).existsSync(), true);
    });
  });
}
