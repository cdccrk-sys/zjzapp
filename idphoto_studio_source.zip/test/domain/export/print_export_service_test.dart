import 'dart:io';

import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/export/export_service.dart';
import 'package:idphoto_studio/domain/export/print_export_service.dart';
import 'package:idphoto_studio/domain/layout/print_layout.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';

class _FakePathProvider extends PathProviderPlatform {
  @override
  Future<String> getApplicationDocumentsPath() async {
    return Directory.systemTemp.path;
  }

  @override
  Future<String> getTemporaryPath() async {
    return Directory.systemTemp.path;
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  late PrintExportService service;
  late Directory tempDocs;

  setUp(() async {
    PathProviderPlatform.instance = _FakePathProvider();
    service = PrintExportService();
    tempDocs = Directory('${Directory.systemTemp.path}/idphoto_test_prints');
    if (tempDocs.existsSync()) tempDocs.deleteSync(recursive: true);
  });

  tearDown(() async {
    if (tempDocs.existsSync()) tempDocs.deleteSync(recursive: true);
  });

  img.Image makePhoto({int w = 295, int h = 413}) {
    final im = img.Image(width: w, height: h, numChannels: 3);
    img.fill(im, color: img.ColorRgb8(180, 200, 220));
    return im;
  }

  PrintLayout makeLayout() {
    return const LayoutService().layout(
      PaperSpec.byId('photo5')!,
      25,
      35,
      count: 8,
    );
  }

  group('PrintExportService.exportPrintSheet', () {
    test('导出 JPG：纸张像素尺寸正确、可回读', () async {
      final layout = makeLayout();
      final item = await service.exportPrintSheet(
        makePhoto(),
        layout,
        format: ExportFormat.jpg,
        customName: 'sheet_test',
      );
      expect(item.width, layout.paper.pixelWidth);
      expect(item.height, layout.paper.pixelHeight);
      expect(item.fileName, 'sheet_test.jpg');
      final back = img.decodeImage(File(item.path).readAsBytesSync());
      expect(back, isNotNull);
      expect(back!.width, layout.paper.pixelWidth);
      expect(back.height, layout.paper.pixelHeight);
    });

    test('导出 PNG：magic 正确', () async {
      final item = await service.exportPrintSheet(
        makePhoto(),
        makeLayout(),
        format: ExportFormat.png,
        customName: 'sheet_png',
      );
      final bytes = File(item.path).readAsBytesSync();
      expect(bytes.sublist(0, 4), [0x89, 0x50, 0x4E, 0x47]);
    });

    test('关闭所有标注时仍成功导出', () async {
      final item = await service.exportPrintSheet(
        makePhoto(),
        makeLayout(),
        options: const PrintExportOptions(
          showCutMarks: false,
          showBleed: false,
          showNumbering: false,
          showDate: false,
        ),
        customName: 'sheet_plain',
      );
      expect(File(item.path).existsSync(), true);
    });
  });

  group('PrintExportService.exportPrintPdf', () {
    test('导出 PDF：%PDF magic、多页', () async {
      final layout = const LayoutService().layout(
        PaperSpec.byId('a4')!,
        25,
        35,
        count: 20, // 2 页
      );
      final item = await service.exportPrintPdf(
        makePhoto(),
        layout,
        customName: 'pdf_test',
      );
      expect(item.fileName, 'pdf_test.pdf');
      final bytes = File(item.path).readAsBytesSync();
      expect(String.fromCharCodes(bytes.sublist(0, 4)), '%PDF');
      expect(bytes.length, greaterThan(1000));
    });
  });
}
