import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/import/supported_formats.dart';

void main() {
  test('受支持扩展名集合', () {
    expect(kSupportedExtensions, containsAll(['jpg', 'jpeg', 'png', 'webp', 'heic', 'heif']));
    expect(isSupportedExtension('JPG'), isTrue);
    expect(isSupportedExtension('PNG'), isTrue);
    expect(isSupportedExtension('gif'), isFalse);
  });

  test('HEIC 判断', () {
    expect(isHeicExtension('heic'), isTrue);
    expect(isHeicExtension('HEIF'), isTrue);
    expect(isHeicExtension('jpg'), isFalse);
  });

  test('扩展名显示名称', () {
    expect(extensionDisplayName('heic'), 'HEIC');
    expect(extensionDisplayName('jpg'), 'JPG');
  });
}
