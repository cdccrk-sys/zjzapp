import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:idphoto_studio/domain/import/exif_orientation.dart';

void main() {
  group('rotationDegrees', () {
    test('按 EXIF 标准返回顺时针旋转度数', () {
      expect(rotationDegrees(1), 0);
      expect(rotationDegrees(2), 0);
      expect(rotationDegrees(3), 180);
      expect(rotationDegrees(4), 0);
      expect(rotationDegrees(5), 270);
      expect(rotationDegrees(6), 90);
      expect(rotationDegrees(7), 90);
      expect(rotationDegrees(8), 270);
      expect(rotationDegrees(0), 0);
      expect(rotationDegrees(9), 0);
    });
  });

  group('needsHorizontalFlip', () {
    test('仅 2/5/7 需要水平翻转', () {
      expect(needsHorizontalFlip(2), isTrue);
      expect(needsHorizontalFlip(5), isTrue);
      expect(needsHorizontalFlip(7), isTrue);
      for (final v in [1, 3, 4, 6, 8]) {
        expect(needsHorizontalFlip(v), isFalse, reason: 'orientation=$v');
      }
    });
  });

  group('needsCorrection', () {
    test('1 为正常，2-8 均需矫正', () {
      expect(needsCorrection(1), isFalse);
      for (var v = 2; v <= 8; v++) {
        expect(needsCorrection(v), isTrue, reason: 'orientation=$v');
      }
    });
  });

  group('parseOrientationString', () {
    test('解析数字与常见描述', () {
      expect(parseOrientationString('6'), 6);
      expect(parseOrientationString(' 3 '), 3);
      expect(parseOrientationString('Rotate 90 CW'), 6);
      expect(parseOrientationString('Horizontal (normal)'), 1);
      expect(parseOrientationString('Left bottom'), 8);
      expect(parseOrientationString('abc'), isNull);
      expect(parseOrientationString(''), isNull);
      expect(parseOrientationString(null), isNull);
      expect(parseOrientationString('0'), isNull);
      expect(parseOrientationString('9'), isNull);
    });
  });

  group('applyExifCorrection', () {
    /// 生成 5x3 图像，在 (1,0) 放置唯一标记点，其余像素全黑。
    (img.Image, int, int) markerImage() {
      final src = img.Image(width: 5, height: 3, numChannels: 3);
      src.setPixelRgb(1, 0, 255, 0, 0);
      return (src, 5, 3);
    }

    /// 断言标记点位于 (x,y)，且该位置为红色、其余位置为黑色。
    void expectMarkerAt(img.Image out, int x, int y) {
      expect(out.getPixel(x, y).r, 255, reason: '标记点应在 ($x,$y)');
      expect(out.getPixel(x, y).g, 0);
      // 抽查两个非标记点仍为黑
      final w = out.width;
      final h = out.height;
      final other = <(int, int)>[(0, 0), (w - 1, h - 1)];
      for (final p in other) {
        if (p.$1 == x && p.$2 == y) continue;
        expect(out.getPixel(p.$1, p.$2).r, 0, reason: '(${p.$1},${p.$2}) 应为黑');
      }
    }

    test('Orientation 1：原样返回', () {
      final (src, w, h) = markerImage();
      final out = applyExifCorrection(src, 1);
      expect(out.width, w);
      expect(out.height, h);
      expectMarkerAt(out, 1, 0);
    });

    test('Orientation 2：水平翻转 (1,0) → (3,0)', () {
      final (src, _, _) = markerImage();
      final out = applyExifCorrection(src, 2);
      expect(out.width, 5);
      expect(out.height, 3);
      expectMarkerAt(out, 3, 0);
    });

    test('Orientation 3：旋转 180° (1,0) → (3,2)', () {
      final (src, _, _) = markerImage();
      final out = applyExifCorrection(src, 3);
      expect(out.width, 5);
      expect(out.height, 3);
      expectMarkerAt(out, 3, 2);
    });

    test('Orientation 4：垂直翻转 (1,0) → (1,2)', () {
      final (src, _, _) = markerImage();
      final out = applyExifCorrection(src, 4);
      expect(out.width, 5);
      expect(out.height, 3);
      expectMarkerAt(out, 1, 2);
    });

    test('Orientation 5：主对角线转置 (1,0) → (0,1)', () {
      final (src, _, _) = markerImage();
      final out = applyExifCorrection(src, 5);
      expect(out.width, 3);
      expect(out.height, 5);
      expectMarkerAt(out, 0, 1);
    });

    test('Orientation 6：顺时针 90° (1,0) → (2,1)', () {
      final (src, _, _) = markerImage();
      final out = applyExifCorrection(src, 6);
      expect(out.width, 3);
      expect(out.height, 5);
      expectMarkerAt(out, 2, 1);
    });

    test('Orientation 7：反对角线转置 (1,0) → (2,3)', () {
      final (src, _, _) = markerImage();
      final out = applyExifCorrection(src, 7);
      expect(out.width, 3);
      expect(out.height, 5);
      expectMarkerAt(out, 2, 3);
    });

    test('Orientation 8：顺时针 270° (1,0) → (0,3)', () {
      final (src, _, _) = markerImage();
      final out = applyExifCorrection(src, 8);
      expect(out.width, 3);
      expect(out.height, 5);
      expectMarkerAt(out, 0, 3);
    });
  });
}
