import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:idphoto_studio/domain/import/exif_orientation.dart';
import 'package:idphoto_studio/domain/import/heic_decoder.dart';
import 'package:idphoto_studio/domain/import/image_item.dart';
import 'package:idphoto_studio/domain/import/import_service_impl.dart';

class _FakeExifReader implements ExifReader {
  _FakeExifReader(this.value);

  final int? value;

  @override
  Future<int?> readOrientation(Uint8List bytes) async => value;
}

class _FakeHeicDecoder implements HeicDecoder {
  _FakeHeicDecoder(this.pngBytes, {this.supported = true});

  final Uint8List pngBytes;
  final bool supported;

  @override
  bool get isSupported => supported;

  @override
  Future<Uint8List> decodeToPngBytes(String filePath) async {
    if (!supported) {
      throw HeicDecodeException('not supported', code: 'heic_not_supported');
    }
    return pngBytes;
  }
}

void main() {
  late Directory tmp;

  setUp(() async {
    tmp = await Directory.systemTemp.createTemp('idphoto_import_test_');
  });

  tearDown(() async {
    await tmp.delete(recursive: true);
  });

  Future<String> writeImage(
    String name,
    img.Image image, {
    String format = 'png',
  }) async {
    final bytes = switch (format) {
      'png' => img.encodePng(image),
      'jpg' => img.encodeJpg(image, quality: 90),
      'webp' => img.encodeWebP(image),
      _ => throw ArgumentError('unknown format $format'),
    };
    final file = File('${tmp.path}/$name');
    await file.writeAsBytes(bytes);
    return file.path;
  }

  img.Image solidImage(int w, int h, {int r = 30, int g = 120, int b = 200}) {
    final image = img.Image(width: w, height: h, numChannels: 3);
    img.fill(image, color: img.ColorRgb8(r, g, b));
    return image;
  }

  group('导入成功路径', () {
    test('PNG：尺寸、缩略图、EXIF 标记正确', () async {
      final path = await writeImage('a.png', solidImage(600, 800));
      final service = LocalImportService(exifReader: _FakeExifReader(null));

      final result = await service.importFile(path);

      expect(result.failures, isEmpty);
      expect(result.items, hasLength(1));
      final item = result.items.single;
      expect(item.fileName, 'a.png');
      expect(item.originalWidth, 600);
      expect(item.originalHeight, 800);
      expect(item.workingWidth, 600);
      expect(item.workingHeight, 800);
      expect(item.exifCorrected, isFalse);
      expect(item.exifOrientation, 1);

      final working = img.decodeImage(item.workingBytes);
      expect(working, isNotNull);
      expect(working!.width, 600);
      expect(working.height, 800);

      final thumb = img.decodeImage(item.thumbnailBytes);
      expect(thumb, isNotNull);
    });

    test('JPEG 与 WEBP 均可导入', () async {
      final service = LocalImportService(exifReader: _FakeExifReader(null));
      final jpg = await writeImage('b.jpg', solidImage(100, 120), format: 'jpg');
      final webp = await writeImage('c.webp', solidImage(100, 120), format: 'webp');

      final result = await service.importFiles([jpg, webp]);

      expect(result.failures, isEmpty);
      expect(result.items, hasLength(2));
    });

    test('EXIF Orientation 6：自动矫正为 90° 顺时针，尺寸互换', () async {
      final path = await writeImage('rot.jpg', solidImage(600, 800), format: 'jpg');
      final service = LocalImportService(exifReader: _FakeExifReader(6));

      final result = await service.importFile(path);

      expect(result.failures, isEmpty);
      final item = result.items.single;
      expect(item.exifCorrected, isTrue);
      expect(item.exifOrientation, 6);
      expect(item.workingWidth, 800);
      expect(item.workingHeight, 600);
    });

    test('EXIF Orientation 1：不矫正', () async {
      final path = await writeImage('no.jpg', solidImage(600, 800), format: 'jpg');
      final service = LocalImportService(exifReader: _FakeExifReader(1));

      final item = (await service.importFile(path)).items.single;

      expect(item.exifCorrected, isFalse);
      expect(item.workingWidth, 600);
    });

    test('大图降采样：4000x3000 → 处理图 ≤2000px，原图尺寸保留', () async {
      final path = await writeImage('big.png', solidImage(4000, 3000));
      final service = LocalImportService(exifReader: _FakeExifReader(null));

      final item = (await service.importFile(path)).items.single;

      expect(item.originalWidth, 4000);
      expect(item.originalHeight, 3000);
      expect(item.workingWidth, 2000);
      expect(item.workingHeight, 1500);
      final thumb = img.decodeImage(item.thumbnailBytes)!;
      expect(thumb.width, 320);
      expect(thumb.height, 240);
    });

    test('HEIC：走平台解码器得到 PNG 字节', () async {
      final pngBytes = img.encodePng(solidImage(300, 400));
      final path = '${tmp.path}/d.heic';
      File(path).writeAsBytesSync([0, 1, 2]); // 内容不影响，解码器为假实现
      final service = LocalImportService(
        exifReader: _FakeExifReader(null),
        heicDecoder: _FakeHeicDecoder(pngBytes),
      );

      final item = (await service.importFile(path)).items.single;

      expect(item.originalWidth, 300);
      expect(item.originalHeight, 400);
    });
  });

  group('失败路径', () {
    test('不支持格式 → unsupportedFormat', () async {
      final path = '${tmp.path}/x.txt';
      File(path).writeAsBytesSync([1, 2, 3]);
      final service = LocalImportService(exifReader: _FakeExifReader(null));

      final result = await service.importFile(path);

      expect(result.items, isEmpty);
      expect(result.failures.single.code, ImportFailureCode.unsupportedFormat);
    });

    test('文件不存在 → fileNotFound', () async {
      final service = LocalImportService(exifReader: _FakeExifReader(null));

      final result = await service.importFile('${tmp.path}/missing.png');

      expect(result.failures.single.code, ImportFailureCode.fileNotFound);
    });

    test('损坏文件 → decodeFailed', () async {
      final path = '${tmp.path}/bad.png';
      File(path).writeAsBytesSync([0, 1, 2, 3, 4, 5, 6, 7, 8, 9]);
      final service = LocalImportService(exifReader: _FakeExifReader(null));

      final result = await service.importFile(path);

      expect(result.failures.single.code, ImportFailureCode.decodeFailed);
    });

    test('超过大小上限 → tooLarge', () async {
      final path = await writeImage('big2.png', solidImage(300, 300));
      final service = LocalImportService(
        exifReader: _FakeExifReader(null),
        maxFileBytes: 100,
      );

      final result = await service.importFile(path);

      expect(result.failures.single.code, ImportFailureCode.tooLarge);
    });

    test('HEIC 平台不支持 → heicNotSupported', () async {
      final path = '${tmp.path}/e.heic';
      File(path).writeAsBytesSync([1]);
      final service = LocalImportService(
        exifReader: _FakeExifReader(null),
        heicDecoder: _FakeHeicDecoder(Uint8List(0), supported: false),
      );

      final result = await service.importFile(path);

      expect(result.failures.single.code, ImportFailureCode.heicNotSupported);
    });
  });

  group('目录导入', () {
    test('只导入受支持格式，按文件名排序，静默跳过其他文件', () async {
      final dir = Directory('${tmp.path}/photos')..createSync();
      final a = await writeImage('a.jpg', solidImage(10, 10), format: 'jpg');
      final b = await writeImage('b.png', solidImage(10, 10));
      final c = await writeImage('c.webp', solidImage(10, 10), format: 'webp');
      for (final src in [a, b, c]) {
        final name = File(src).uri.pathSegments.last;
        File('${dir.path}/$name').writeAsBytesSync(File(src).readAsBytesSync());
      }
      File('${dir.path}/note.txt').writeAsBytesSync([1]);
      final service = LocalImportService(exifReader: _FakeExifReader(null));

      final result = await service.importDirectory(dir.path);

      expect(result.failures, isEmpty);
      expect(result.items.map((e) => e.fileName), ['a.jpg', 'b.png', 'c.webp']);
    });
  });
}
