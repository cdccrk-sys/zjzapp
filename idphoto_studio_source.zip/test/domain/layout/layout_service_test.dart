import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/layout/print_layout.dart';

void main() {
  const service = LayoutService();

  group('LayoutService 网格计算', () {
    test('5 寸纸排一寸照：4 列 × 2 行 = 每页 8 张', () {
      final l = service.layout(
        PaperSpec.byId('photo5')!,
        25,
        35,
        count: 8,
      );
      expect(l.cols, 4);
      expect(l.rows, 2);
      expect(l.perPage, 8);
      expect(l.pages.length, 1);
      expect(l.total, 8);
    });

    test('6 寸纸排二寸照：每页 4 张', () {
      final l = service.layout(
        PaperSpec.byId('photo6')!,
        35,
        49,
        count: 4,
      );
      expect(l.perPage, 4);
      expect(l.total, 4);
    });

    test('A4 纸排一寸照：每页 50 张（横排 5×10）', () {
      final l = service.layout(
        PaperSpec.byId('a4')!,
        25,
        35,
        count: 60,
      );
      expect(l.cols, 5);
      expect(l.rows, 10);
      expect(l.perPage, 50);
      expect(l.pages.length, 2);
      expect(l.total, 60); // 最后一页 10 张
      expect(l.pages.last.cells.length, 10);
    });

    test('数量不足一页时只排需要的张数', () {
      final l = service.layout(
        PaperSpec.byId('photo5')!,
        25,
        35,
        count: 3,
      );
      expect(l.pages.length, 1);
      expect(l.total, 3);
    });

    test('网格内容居中于纸张', () {
      final l = service.layout(
        PaperSpec.byId('photo5')!,
        25,
        35,
        count: 8,
      );
      final first = l.pages.first.cells.first;
      final last = l.pages.first.cells.last;
      // 左侧留白 = 右侧留白。
      final left = first.xMm;
      final right = l.paper.widthMm - (last.xMm + last.widthMm);
      expect(left, closeTo(right, 0.01));
    });

    test('增大间距减少每页数量', () {
      final tight = service.layout(
        PaperSpec.byId('photo5')!,
        25,
        35,
        count: 8,
        gapMm: 0,
        marginMm: 0,
      );
      final loose = service.layout(
        PaperSpec.byId('photo5')!,
        25,
        35,
        count: 8,
        gapMm: 6,
        marginMm: 10,
      );
      expect(loose.perPage, lessThanOrEqualTo(tight.perPage));
    });

    test('照片与纸尺寸异常时不崩溃', () {
      final l = service.layout(
        PaperSpec.byId('a4')!,
        5,
        5,
        count: 1,
      );
      expect(l.perPage, greaterThan(0));
      expect(l.pages.length, 1);
    });
  });

  group('PaperSpec', () {
    test('内置相纸像素尺寸 @300DPI', () {
      final p = PaperSpec.byId('photo5')!;
      expect(p.pixelWidth, (127 / 25.4 * 300).round());
      expect(p.pixelHeight, (89 / 25.4 * 300).round());
    });

    test('byId 未命中返回 null', () {
      expect(PaperSpec.byId('nope'), isNull);
    });
  });
}
