import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/crop/crop_service.dart';
import 'package:idphoto_studio/domain/face/face_models.dart';
import 'package:idphoto_studio/domain/specs/idphoto_specs.dart';
import 'package:image/image.dart' as img;

void main() {
  const service = CropService();
  final spec = IdPhotoSpec.byId('inch1')!; // 25×35mm, 295×413px

  /// 标准正面证件照人脸：眼睛在 y=0.35，下巴 y=0.62。
  const face = FaceInfo(
    boundingBox: NormalizedRect(left: 0.25, top: 0.15, right: 0.75, bottom: 0.85),
    leftEye: FacePoint(0.4, 0.35),
    rightEye: FacePoint(0.6, 0.35),
    nose: FacePoint(0.5, 0.48),
    chin: FacePoint(0.5, 0.62),
  );

  group('CropService.autoCrop', () {
    test('裁框宽高比与规格一致', () {
      final r = service.autoCrop(face, spec, 1000, 1200);
      expect(r.rect.aspectError(spec.aspectRatio), lessThan(0.02));
    });

    test('眼睛位于照片高度约 58% 处', () {
      final r = service.autoCrop(face, spec, 1000, 1200);
      const eyeY = 0.35 * 1200; // 源图眼睛 y（像素）
      final eyeRatio = (eyeY - r.rect.y) / r.rect.height;
      expect(eyeRatio, closeTo(0.58, 0.03));
    });

    test('裁框在图像范围内', () {
      final r = service.autoCrop(face, spec, 1000, 1200);
      expect(r.rect.x, greaterThanOrEqualTo(0));
      expect(r.rect.y, greaterThanOrEqualTo(0));
      expect(r.rect.x + r.rect.width, lessThanOrEqualTo(1000));
      expect(r.rect.y + r.rect.height, lessThanOrEqualTo(1200));
    });

    test('头部居中：裁框中心接近脸部中心', () {
      final r = service.autoCrop(face, spec, 1000, 1200);
      const faceCenterX = 0.5 * 1000;
      final rectCenterX = r.rect.x + r.rect.width / 2;
      expect((rectCenterX - faceCenterX).abs(), lessThan(60));
    });

    test('异常人脸数据（空框）不崩溃并给出合理框', () {
      const bad = FaceInfo(
        boundingBox: NormalizedRect(left: 0, top: 0, right: 0.1, bottom: 0.1),
        leftEye: FacePoint(0.05, 0.05),
        rightEye: FacePoint(0.05, 0.05),
        nose: FacePoint(0.05, 0.05),
        chin: FacePoint(0.05, 0.05),
      );
      final r = service.autoCrop(bad, spec, 100, 100);
      expect(r.rect.width, greaterThan(0));
      expect(r.rect.height, greaterThan(0));
      expect(r.rect.x + r.rect.width, lessThanOrEqualTo(100));
      expect(r.rect.y + r.rect.height, lessThanOrEqualTo(100));
    });

    test('自定义裁剪规则生效（眼睛比例更高）', () {
      final r = service.autoCrop(
        face,
        spec,
        1000,
        1200,
        rule: const CropRule(eyeHeightRatio: 0.6),
      );
      const eyeY = 0.35 * 1200;
      final eyeRatio = (eyeY - r.rect.y) / r.rect.height;
      expect(eyeRatio, closeTo(0.6, 0.03));
    });
  });

  group('CropService.shift / zoom', () {
    const rect = CropRect(x: 100, y: 100, width: 300, height: 400);

    test('平移后保持尺寸并 clamp 在界内', () {
      final moved = service.shift(rect, 30, -20, 1000, 1200);
      expect(moved.x, 130);
      expect(moved.y, 80);
      expect(moved.width, 300);
      expect(moved.height, 400);
      // 移出边界时 clamp。
      final out = service.shift(rect, -500, -500, 1000, 1200);
      expect(out.x, 0);
      expect(out.y, 0);
    });

    test('缩放保持中心且比例锁定规格', () {
      final z = service.zoom(rect, 1.2, 1000, 1200, spec);
      expect(z.width, (300 * 1.2).round());
      expect(z.height, (z.width / spec.aspectRatio).round());
      final cx = z.x + z.width ~/ 2;
      expect(cx, 100 + 150);
    });

    test('缩放 clamp 到图像尺寸', () {
      final z = service.zoom(rect, 10, 1000, 1200, spec);
      expect(z.width, lessThanOrEqualTo(1000));
      expect(z.height, lessThanOrEqualTo(1200));
    });
  });

  group('CropService.applyCrop', () {
    test('裁剪并缩放到目标像素', () {
      final src = img.Image(width: 1000, height: 1200, numChannels: 3);
      img.fill(src, color: img.ColorRgb8(200, 200, 200));
      const rect = CropRect(x: 100, y: 100, width: 300, height: 400);
      final out = service.applyCrop(
        src,
        rect,
        targetWidth: spec.pixelWidth,
        targetHeight: spec.pixelHeight,
      );
      expect(out.width, spec.pixelWidth);
      expect(out.height, spec.pixelHeight);
      expect(out.getPixel(0, 0).r.toInt(), 200);
    });

    test('不指定目标尺寸时保持裁框尺寸', () {
      final src = img.Image(width: 1000, height: 1200, numChannels: 3);
      const rect = CropRect(x: 10, y: 20, width: 300, height: 400);
      final out = service.applyCrop(src, rect);
      expect(out.width, 300);
      expect(out.height, 400);
    });
  });
}
