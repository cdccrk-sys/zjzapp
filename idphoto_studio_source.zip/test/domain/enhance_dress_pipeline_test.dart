import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/dress/dress_service.dart';
import 'package:idphoto_studio/domain/enhance/enhance_service.dart';
import 'package:idphoto_studio/domain/face/face_models.dart';
import 'package:idphoto_studio/domain/matting/background.dart';
import 'package:idphoto_studio/domain/pipeline/photo_pipeline.dart';
import 'package:image/image.dart' as img;

img.Image makeGray({int w = 60, int h = 80, int v = 128}) {
  final im = img.Image(width: w, height: h, numChannels: 3);
  img.fill(im, color: img.ColorRgb8(v, v, v));
  return im;
}

void main() {
  const enhance = ColorEnhanceService();
  const pipeline = PhotoPipeline();

  group('ColorEnhanceService', () {
    test('identity 参数返回同尺寸图', () {
      final src = makeGray();
      final out = enhance.enhance(src, const EnhancementParams());
      expect(out.width, src.width);
      expect(out.height, src.height);
      expect(out.getPixel(0, 0).r.toInt(), 128);
    });

    test('亮度 +50 提亮', () {
      final out = enhance.enhance(
        makeGray(v: 100),
        const EnhancementParams(whiteBalance: false, brightness: 50),
      );
      expect(out.getPixel(0, 0).r.toInt(), greaterThan(120));
    });

    test('饱和度降低使彩色变灰', () {
      final im = img.Image(width: 20, height: 20, numChannels: 3);
      img.fill(im, color: img.ColorRgb8(200, 40, 40));
      final out = enhance.enhance(
        im,
        const EnhancementParams(
          whiteBalance: false,
          saturation: 0.0,
        ),
      );
      final c = out.getPixel(5, 5);
      final spread = (c.r.toInt() - c.b.toInt()).abs();
      expect(spread, lessThan(15));
    });

    test('白平衡校正偏色图', () {
      final im = img.Image(width: 30, height: 30, numChannels: 3);
      img.fill(im, color: img.ColorRgb8(180, 128, 128)); // 偏红
      final out = enhance.enhance(
        im,
        const EnhancementParams(whiteBalance: true),
      );
      final c = out.getPixel(5, 5);
      expect((c.r.toInt() - c.g.toInt()).abs(), lessThan(20));
    });

    test('色温 +50 偏暖（R 升 B 降）', () {
      final out = enhance.enhance(
        makeGray(v: 150),
        const EnhancementParams(whiteBalance: false, warmth: 50),
      );
      final c = out.getPixel(5, 5);
      expect(c.r.toInt(), greaterThan(c.b.toInt()));
    });

    test('锐化与磨皮不改变尺寸且不崩溃', () {
      final src = makeGray();
      final sharp = enhance.enhance(
        src,
        const EnhancementParams(whiteBalance: false, sharpen: 50),
      );
      final smooth = enhance.enhance(
        src,
        const EnhancementParams(whiteBalance: false, smooth: 50),
      );
      expect(sharp.width, src.width);
      expect(smooth.width, src.width);
    });

    test('预设均可用', () {
      for (final p in EnhancementPreset.values) {
        final out = enhance.enhance(makeGray(), EnhancementParams.ofPreset(p));
        expect(out.width, 60);
        expect(out.height, 80);
      }
    });
  });

  group('DressService', () {
    test('none 模板返回原图', () {
      final src = makeGray(v: 100);
      final out = const DressService().dress(
        src,
        DressTemplate.none,
        faceTop: 0.1,
        faceBottom: 0.5,
        faceCenterX: 0.5,
        faceWidth: 0.4,
      );
      expect(out.getPixel(30, 40).r.toInt(), 100);
    });

    test('menSuit 在身体区域产生服装色', () {
      final src = makeGray(v: 100);
      final out = const DressService().dress(
        src,
        DressTemplate.menSuit,
        faceTop: 0.1,
        faceBottom: 0.4,
        faceCenterX: 0.5,
        faceWidth: 0.4,
      );
      // 肩线下方身体区（避开中央领带区）应接近深蓝。
      final c = out.getPixel(18, 60);
      expect(c.b.toInt(), greaterThan(c.r.toInt()));
      // 衣服区与原始背景色明显不同。
      expect((c.r.toInt() - 100).abs(), greaterThan(10));
    });

    test('异常人脸框不崩溃', () {
      final src = makeGray();
      final out = const DressService().dress(
        src,
        DressTemplate.whiteShirt,
        faceTop: 0,
        faceBottom: 1,
        faceCenterX: 0,
        faceWidth: 1,
      );
      expect(out.width, src.width);
    });
  });

  group('PhotoPipeline', () {
    test('无蒙版时原样输出', () {
      final src = makeGray(v: 120);
      final out = pipeline.process(source: src);
      expect(out.getPixel(0, 0).r.toInt(), 120);
    });

    test('白底合成：前景蒙版区域保留、背景区域变白', () {
      final src = makeGray(v: 200);
      // 全 0 蒙版 → 全背景。
      final mask = List<int>.filled(src.width * src.height, 0);
      final out = pipeline.process(
        source: src,
        mattingMask: mask,
        background: PhotoBackground.white,
      );
      expect(out.getPixel(5, 5).r.toInt(), 255);
    });

    test('前景蒙版全 1 → 保留原图', () {
      final src = makeGray(v: 90);
      final mask = List<int>.filled(src.width * src.height, 255);
      final out = pipeline.process(
        source: src,
        mattingMask: mask,
        background: PhotoBackground.blue,
      );
      expect(out.getPixel(5, 5).r.toInt(), 90);
    });

    test('蓝底合成：背景像素变蓝', () {
      final src = makeGray(v: 200);
      final mask = List<int>.filled(src.width * src.height, 0);
      final out = pipeline.process(
        source: src,
        mattingMask: mask,
        background: PhotoBackground.blue,
      );
      final c = out.getPixel(5, 5);
      expect(c.b.toInt(), greaterThan(180));
    });

    test('渐变背景两端颜色不同', () {
      final src = makeGray(v: 200);
      final mask = List<int>.filled(src.width * src.height, 0);
      final out = pipeline.process(
        source: src,
        mattingMask: mask,
        background: PhotoBackground.whiteToLightBlue,
      );
      final top = out.getPixel(5, 2); // 白色端
      final bottom = out.getPixel(5, src.height - 3); // 浅蓝端
      expect(bottom.b.toInt(), lessThan(top.b.toInt()));
      expect(bottom.b.toInt(), greaterThan(bottom.r.toInt()));
    });

    test('自定义图片背景合成', () {
      final src = makeGray(v: 200);
      final mask = List<int>.filled(src.width * src.height, 0);
      // 全红背景图。
      final bgImage = img.Image(width: 10, height: 10, numChannels: 3);
      img.fill(bgImage, color: img.ColorRgb8(200, 20, 20));
      final bytes = Uint8List.fromList(img.encodePng(bgImage));
      final out = pipeline.process(
        source: src,
        mattingMask: mask,
        background: PhotoBackground.fromImage(bytes),
      );
      final c = out.getPixel(5, 5);
      expect(c.r.toInt(), greaterThan(c.b.toInt()));
    });

    test('全链路：换底+换装+优化 输出尺寸不变', () {
      final src = makeGray(v: 150);
      final mask = List<int>.filled(src.width * src.height, 255);
      final out = pipeline.process(
        source: src,
        mattingMask: mask,
        background: PhotoBackground.white,
        enhancement: const EnhancementParams(contrast: 1.1, saturation: 1.1),
        dress: DressTemplate.menSuit,
        face: const FaceInfo(
          boundingBox: NormalizedRect(left: 0.2, top: 0.1, right: 0.8, bottom: 0.6),
          leftEye: FacePoint(0.4, 0.3),
          rightEye: FacePoint(0.6, 0.3),
          nose: FacePoint(0.5, 0.42),
          chin: FacePoint(0.5, 0.55),
        ),
      );
      expect(out.width, src.width);
      expect(out.height, src.height);
    });
  });
}
