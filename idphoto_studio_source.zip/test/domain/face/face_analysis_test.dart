import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:idphoto_studio/domain/face/face_analysis.dart';
import 'package:idphoto_studio/domain/face/face_models.dart';

void main() {
  group('角度与旋转', () {
    test('lineAngleDegrees 在 y 向下坐标系中正确', () {
      expect(lineAngleDegrees(const FacePoint(0, 0), const FacePoint(1, 0)), 0);
      expect(
        lineAngleDegrees(const FacePoint(0, 0), const FacePoint(0, 1)),
        90,
      );
      expect(
        lineAngleDegrees(const FacePoint(0, 0), const FacePoint(1, 0.5)),
        closeTo(26.565, 1e-3),
      );
    });

    test('computeEyeLevelRotation：旋转后眼睛连线水平', () {
      const left = FacePoint(0.35, 0.25);
      const right = FacePoint(0.65, 0.4);
      final r = computeEyeLevelRotation(left, right);
      // 期望旋转方向与线角相反。
      expect(r, closeTo(-lineAngleDegrees(left, right), 1e-9));
      // 应用旋转后（绕归一化空间中心 0.5）线角归零。
      final l2 = rotatePointCw(left, r, 1, 1);
      final r2 = rotatePointCw(right, r, 1, 1);
      expect(lineAngleDegrees(l2, r2).abs(), lessThan(1e-6));
    });

    test('computeEyeLevelRotation：竖直眼线需要 ±90°', () {
      const left = FacePoint(0.5, 0.2);
      const right = FacePoint(0.5, 0.8);
      final r = computeEyeLevelRotation(left, right);
      expect(r.abs(), closeTo(90, 1e-9));
      final l2 = rotatePointCw(left, r, 1, 1);
      final r2 = rotatePointCw(right, r, 1, 1);
      expect(lineAngleDegrees(l2, r2).abs(), lessThan(1e-6));
    });

    test('computeShoulderLevelRotation：语义与眼线一致', () {
      const ls = FacePoint(0.2, 0.8);
      const rs = FacePoint(0.8, 0.7);
      final r = computeShoulderLevelRotation(ls, rs);
      final l2 = rotatePointCw(ls, r, 1, 1);
      final r2 = rotatePointCw(rs, r, 1, 1);
      expect(lineAngleDegrees(l2, r2).abs(), lessThan(1e-6));
    });

    test('rotatePointCw：90° 相对映射 (dx,dy)→(-dy,dx)', () {
      // 绕中心 (2.5, 1.5)：(1,0) 相对 (-1.5,-1.5) → (1.5,-1.5) → 绝对 (4,0)。
      final p = rotatePointCw(const FacePoint(1, 0), 90, 5, 3);
      expect(p.x, closeTo(4, 1e-9));
      expect(p.y, closeTo(0, 1e-9));
    });

    test('rotatePointCw 与 copyRotate+裁剪回的实测落点一致（覆盖叠加对齐）', () {
      // 200x300 图像、标记点 (60,90)，旋转后中心裁剪回原尺寸。
      final src = img.Image(width: 200, height: 300, numChannels: 3);
      img.fill(src, color: img.ColorRgb8(0, 0, 0));
      for (var dy = -1; dy <= 1; dy++) {
        for (var dx = -1; dx <= 1; dx++) {
          src.setPixelRgb(60 + dx, 90 + dy, 255, 255, 255);
        }
      }
      for (final deg in [-20.556, 8.0, 15.0]) {
        final out = img.copyRotate(
          src,
          angle: deg,
          interpolation: img.Interpolation.linear,
        );
        final crop = img.copyCrop(
          out,
          x: ((out.width - 200) / 2).floor(),
          y: ((out.height - 300) / 2).floor(),
          width: 200,
          height: 300,
        );
        // 实测白色标记质心。
        var sx = 0.0, sy = 0.0, n = 0.0;
        for (var y = 0; y < crop.height; y++) {
          for (var x = 0; x < crop.width; x++) {
            if (crop.getPixel(x, y).r > 200) {
              sx += x;
              sy += y;
              n++;
            }
          }
        }
        final cx = sx / n, cy = sy / n;
        // 预测：绕中心 (100,150) 旋转。
        final predicted = rotatePointCw(const FacePoint(60, 90), deg, 200, 300);
        expect((predicted.x - cx).abs(), lessThan(2.0), reason: 'deg=$deg');
        expect((predicted.y - cy).abs(), lessThan(2.0), reason: 'deg=$deg');
      }
    });
  });

  group('头部中心与侧脸', () {
    test('computeHeadCenter：两眼 + 鼻尖均值', () {
      const face = FaceInfo(
        boundingBox: NormalizedRect(left: 0.2, top: 0.1, right: 0.8, bottom: 0.9),
        leftEye: FacePoint(0.4, 0.35),
        rightEye: FacePoint(0.6, 0.35),
        nose: FacePoint(0.5, 0.5),
        chin: FacePoint(0.5, 0.75),
      );
      final c = computeHeadCenter(face);
      expect(c.x, closeTo(0.5, 1e-9));
      expect(c.y, closeTo(0.4, 1e-9));
    });

    test('isSideFaceByGeometry：正面脸不误报', () {
      expect(
        isSideFaceByGeometry(
          leftEye: const FacePoint(0.4, 0.35),
          rightEye: const FacePoint(0.6, 0.35),
          nose: const FacePoint(0.5, 0.5),
        ),
        isFalse,
      );
    });

    test('isSideFaceByGeometry：明显侧脸命中', () {
      // 眼距 0.3，鼻子偏向左侧眼 0.158 / 右侧眼 0.291 → 比值 0.443 > 0.35。
      expect(
        isSideFaceByGeometry(
          leftEye: const FacePoint(0.4, 0.35),
          rightEye: const FacePoint(0.7, 0.35),
          nose: const FacePoint(0.45, 0.5),
        ),
        isTrue,
      );
    });

    test('isEyesClosed 阈值', () {
      expect(isEyesClosed(0.9, 0.1), isTrue);
      expect(isEyesClosed(0.1, 0.85), isTrue);
      expect(isEyesClosed(0.5, 0.5), isFalse);
    });
  });

  group('模糊评分', () {
    img.Image checkerboard(int cell) {
      final image = img.Image(width: 160, height: 160, numChannels: 3);
      for (var y = 0; y < 160; y++) {
        for (var x = 0; x < 160; x++) {
          final v = ((x ~/ cell) + (y ~/ cell)) % 2 == 0 ? 220 : 20;
          image.setPixelRgb(x, y, v, v, v);
        }
      }
      return image;
    }

    test('清晰图像评分远高于强模糊图像', () {
      final sharp = checkerboard(10);
      // gaussianBlur 会原地修改传入图像，必须使用独立棋盘。
      final blurred = img.gaussianBlur(checkerboard(10), radius: 8);

      final sharpScore = computeBlurScore(sharp);
      final blurScore = computeBlurScore(blurred);

      expect(sharpScore, greaterThan(5000));
      expect(blurScore, lessThan(kBlurThreshold));
      expect(sharpScore, greaterThan(blurScore * 10));
      expect(isBlurry(sharpScore), isFalse);
      expect(isBlurry(blurScore), isTrue);
    });

    test('大图自动降采样后再评分', () {
      final image = checkerboard(10);
      final big = img.copyResize(image, width: 1600, height: 1600);
      final score = computeBlurScore(big);
      expect(score, greaterThan(5000));
    });
  });

  group('FaceAnalysisResult 质量提示组装', () {
    FaceInfo face({
      double? yaw,
      double? roll,
      double blinkL = 0,
      double blinkR = 0,
      FacePoint? leftEye,
      FacePoint? rightEye,
      FacePoint? nose,
    }) {
      return FaceInfo(
        boundingBox: const NormalizedRect(left: 0.2, top: 0.1, right: 0.8, bottom: 0.9),
        leftEye: leftEye ?? const FacePoint(0.4, 0.35),
        rightEye: rightEye ?? const FacePoint(0.6, 0.35),
        nose: nose ?? const FacePoint(0.5, 0.5),
        chin: const FacePoint(0.5, 0.75),
        yawDegrees: yaw,
        rollDegrees: roll,
        eyeBlinkLeft: blinkL,
        eyeBlinkRight: blinkR,
      );
    }

    test('无脸 + 模糊 → noFace + blurry', () {
      final result = FaceAnalysisResult(
        faces: [],
        imageWidth: 100,
        imageHeight: 100,
        blurScore: 20,
      );
      expect(result.hasIssue(FaceIssueType.noFace), isTrue);
      expect(result.hasIssue(FaceIssueType.blurry), isTrue);
    });

    test('多人脸 → multipleFaces', () {
      final result = FaceAnalysisResult(
        faces: [face(), face(yaw: 30)],
        imageWidth: 100,
        imageHeight: 100,
        blurScore: 500,
      );
      expect(result.hasIssue(FaceIssueType.multipleFaces), isTrue);
    });

    test('侧脸（几何）→ sideFace', () {
      final result = FaceAnalysisResult(
        faces: [
          face(
            leftEye: const FacePoint(0.4, 0.35),
            rightEye: const FacePoint(0.7, 0.35),
            nose: const FacePoint(0.45, 0.5),
          ),
        ],
        imageWidth: 100,
        imageHeight: 100,
        blurScore: 500,
      );
      expect(result.hasIssue(FaceIssueType.sideFace), isTrue);
    });

    test('侧脸（姿态 yaw）→ sideFace', () {
      final result = FaceAnalysisResult(
        faces: [face(yaw: 35)],
        imageWidth: 100,
        imageHeight: 100,
        blurScore: 500,
      );
      expect(result.hasIssue(FaceIssueType.sideFace), isTrue);
    });

    test('闭眼 → occluded', () {
      final result = FaceAnalysisResult(
        faces: [face(blinkL: 0.95)],
        imageWidth: 100,
        imageHeight: 100,
        blurScore: 500,
      );
      expect(result.hasIssue(FaceIssueType.occluded), isTrue);
    });

    test('头部倾斜 → tilted 提示', () {
      final result = FaceAnalysisResult(
        faces: [face(roll: 15)],
        imageWidth: 100,
        imageHeight: 100,
        blurScore: 500,
      );
      expect(result.hasIssue(FaceIssueType.tilted), isTrue);
    });

    test('合格照片 → 无提示', () {
      final result = FaceAnalysisResult(
        faces: [face()],
        imageWidth: 100,
        imageHeight: 100,
        blurScore: 500,
      );
      expect(result.issues, isEmpty);
    });

    test('分析器不可用 → analyzerAvailable=false 且无脸', () {
      final result = FaceAnalysisResult(
        faces: [],
        imageWidth: 100,
        imageHeight: 100,
        blurScore: 0,
        analyzerUnavailableReason: 'native lib missing',
      );
      expect(result.analyzerAvailable, isFalse);
      expect(result.issues, isNotEmpty);
    });
  });

  group('buildCorrectionPlan', () {
    test('返回眼睛水平旋转与头部中心', () {
      const face = FaceInfo(
        boundingBox: NormalizedRect(left: 0.2, top: 0.1, right: 0.8, bottom: 0.9),
        leftEye: FacePoint(0.35, 0.25),
        rightEye: FacePoint(0.65, 0.4),
        nose: FacePoint(0.5, 0.5),
        chin: FacePoint(0.5, 0.75),
      );
      final plan = buildCorrectionPlan(face);
      expect(
        plan.rotationDegrees,
        closeTo(-lineAngleDegrees(face.leftEye, face.rightEye), 1e-9),
      );
      expect(plan.shoulderRotationDegrees, isNull);
      expect(plan.headCenter.x, closeTo(0.5, 1e-9));
      expect(plan.faceBox.width, closeTo(0.6, 1e-9));
    });

    test('肩膀可用时给出肩膀旋转角', () {
      const face = FaceInfo(
        boundingBox: NormalizedRect(left: 0.2, top: 0.1, right: 0.8, bottom: 0.9),
        leftEye: FacePoint(0.4, 0.35),
        rightEye: FacePoint(0.6, 0.35),
        nose: FacePoint(0.5, 0.5),
        chin: FacePoint(0.5, 0.75),
        leftShoulder: FacePoint(0.25, 0.85),
        rightShoulder: FacePoint(0.75, 0.8),
      );
      final plan = buildCorrectionPlan(face);
      expect(plan.shoulderRotationDegrees, isNotNull);
      expect(plan.shoulderRotationDegrees!.abs(), greaterThan(0));
    });
  });
}
