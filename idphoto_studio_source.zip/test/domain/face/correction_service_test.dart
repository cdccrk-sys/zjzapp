import 'dart:typed_data';

import 'package:flutter_test/flutter_test.dart';
import 'package:image/image.dart' as img;
import 'package:idphoto_studio/domain/face/correction_service.dart';
import 'package:idphoto_studio/domain/face/face_models.dart';

void main() {
  group('CorrectionService', () {
    const service = CorrectionService();

    img.Image solid(int w, int h) {
      final image = img.Image(width: w, height: h, numChannels: 3);
      img.fill(image, color: img.ColorRgb8(30, 120, 200));
      return image;
    }

    test('applyRotation：90° 旋转后尺寸互换且字节可解码', () {
      final result = service.applyRotation(
        source: solid(400, 600),
        rotationDegrees: 90,
      );
      expect(result.corrected, isTrue);
      expect(result.width, 600);
      expect(result.height, 400);

      final decoded = img.decodeImage(result.correctedBytes);
      expect(decoded, isNotNull);
      expect(decoded!.width, 600);
      expect(decoded.height, 400);
    });

    test('applyRotation：0° 不旋转，尺寸不变', () {
      final result = service.applyRotation(
        source: solid(400, 600),
        rotationDegrees: 0,
      );
      expect(result.corrected, isFalse);
      expect(result.width, 400);
      expect(result.height, 600);
    });

    test('applyRotation：非整数角度可用（小数精度）', () {
      final result = service.applyRotation(
        source: solid(400, 600),
        rotationDegrees: -3.7,
      );
      expect(result.rotationDegrees, closeTo(-3.7, 1e-9));
      final decoded = img.decodeImage(result.correctedBytes);
      expect(decoded, isNotNull);
    });

    test('applyAutoCorrection：按眼睛水平自动旋转', () {
      // 眼线夹角 atan2(0.15, 0.4) ≈ 20.56°，应顺时针旋转 -20.56°。
      const face = FaceInfo(
        boundingBox: NormalizedRect(left: 0.2, top: 0.1, right: 0.8, bottom: 0.9),
        leftEye: FacePoint(0.3, 0.2),
        rightEye: FacePoint(0.7, 0.35),
        nose: FacePoint(0.5, 0.45),
        chin: FacePoint(0.5, 0.7),
      );
      final result = service.applyAutoCorrection(
        source: solid(400, 600),
        face: face,
      );
      expect(result.autoCorrected, isTrue);
      expect(result.rotationDegrees, closeTo(-20.556, 0.01));
      final decoded = img.decodeImage(result.correctedBytes);
      expect(decoded, isNotNull);
      expect(decoded!.width, 400);
    });

    test('applyAutoCorrection：眼线已水平时不旋转', () {
      const face = FaceInfo(
        boundingBox: NormalizedRect(left: 0.2, top: 0.1, right: 0.8, bottom: 0.9),
        leftEye: FacePoint(0.3, 0.3),
        rightEye: FacePoint(0.7, 0.3),
        nose: FacePoint(0.5, 0.45),
        chin: FacePoint(0.5, 0.7),
      );
      final result = service.applyAutoCorrection(
        source: solid(400, 600),
        face: face,
      );
      expect(result.autoCorrected, isTrue);
      expect(result.rotationDegrees.abs(), lessThan(1e-6));
    });
  });

  test('CorrectionResult 默认值', () {
    final result = CorrectionResult(
      rotationDegrees: 0,
      autoCorrected: false,
      correctedBytes: Uint8List(0),
      width: 0,
      height: 0,
    );
    expect(result.corrected, isFalse);
  });
}
