import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/app/app.dart';
import 'package:idphoto_studio/domain/import/import_service.dart';
import 'package:idphoto_studio/domain/import/image_item.dart';
import 'package:idphoto_studio/domain/matting/segmenter.dart';
import 'package:idphoto_studio/platform/picker/import_picker.dart';
import 'package:idphoto_studio/state/artifact_state.dart';
import 'package:idphoto_studio/state/import_state.dart';
import 'package:idphoto_studio/state/matting_state.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';

import '../helpers/fake_artifact_store.dart';

class _FakePicker implements ImportPicker {
  _FakePicker(this.paths);

  final List<String> paths;

  @override
  Future<List<String>> pickImages() async => paths;

  @override
  Future<String?> pickFolder() async => null;
}

class _FakeImportService implements ImportService {
  _FakeImportService(this.item);

  final ImageItem item;

  @override
  Future<ImportResult> importFile(String path) => importFiles([path]);

  @override
  Future<ImportResult> importFiles(List<String> paths) async {
    return ImportResult(items: [item], failures: const []);
  }

  @override
  Future<ImportResult> importDirectory(String directoryPath) async {
    return ImportResult(items: [item], failures: const []);
  }
}

class _FakeSegmenter implements Segmenter {
  int callCount = 0;

  @override
  Future<SegmentationResult> segment(img.Image image) async {
    callCount++;
    return SegmentationResult(
      mask: Uint8List.fromList(
        List.generate(image.width * image.height, (i) {
          // 上半部分前景（模拟人像），下半部分背景。
          final y = i ~/ image.width;
          return y < image.height * 2 ~/ 3 ? 255 : 0;
        }),
      ),
      width: image.width,
      height: image.height,
      source: 'fake',
      succeeded: true,
    );
  }
}

ImageItem _buildItem() {
  final image = img.Image(width: 120, height: 160, numChannels: 3);
  img.fill(image, color: img.ColorRgb8(120, 160, 200));
  return ImageItem(
    id: 'id-matting-1',
    sourcePath: '/tmp/matting.png',
    fileName: 'matting.png',
    workingBytes: Uint8List.fromList(img.encodeJpg(image, quality: 92)),
    workingWidth: 120,
    workingHeight: 160,
    thumbnailBytes: Uint8List.fromList(img.encodeJpg(image, quality: 80)),
    originalWidth: 120,
    originalHeight: 160,
    exifOrientation: 1,
    exifCorrected: false,
    importedAt: DateTime.now(),
  );
}

Future<void> scrollTo(WidgetTester tester, Finder finder) async {
  await tester.scrollUntilVisible(
    finder,
    200,
    scrollable: find.byType(Scrollable).last,
  );
  await tester.pumpAndSettle();
}

class _FakePathProvider extends PathProviderPlatform {
  @override
  Future<String> getApplicationDocumentsPath() async =>
      Directory.systemTemp.path;

  @override
  Future<String> getTemporaryPath() async => Directory.systemTemp.path;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    PathProviderPlatform.instance = _FakePathProvider();
  });

  /// 导入 → 保存 → 回主页 → 进入「抠图」功能页。
  Future<void> enterMatting(WidgetTester tester) async {
    await tester.tap(find.text('导入照片'));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('抠图'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('抠图'));
    await tester.pumpAndSettle();
  }

  testWidgets('抠图步骤：自动抠图后显示结果与画笔', (tester) async {
    final item = _buildItem();
    final segmenter = _FakeSegmenter();
    await tester.pumpWidget(ProviderScope(
      overrides: [
        artifactStoreProvider.overrideWithValue(InMemoryArtifactStore()),
        importPickerProvider.overrideWithValue(_FakePicker(['/tmp/matting.png'])),
        importServiceProvider.overrideWithValue(_FakeImportService(item)),
        segmenterProvider.overrideWithValue(segmenter),
      ],
      child: const IDPhotoApp(),
    ));

    await enterMatting(tester);

    expect(segmenter.callCount, 1);
    // 显示原图/结果切换。
    expect(find.text('原图'), findsOneWidget);
    expect(find.text('抠图结果'), findsOneWidget);
    // 画笔控件（滚动到可见）。
    await scrollTo(tester, find.text('前景笔'));
    expect(find.text('前景笔'), findsOneWidget);
    expect(find.text('背景笔'), findsOneWidget);
    // 提示卡：换背景独立。
    await scrollTo(tester, find.textContaining('换背景'));
    expect(find.textContaining('换背景'), findsOneWidget);
  });

  testWidgets('换背景页选择蓝底后状态更新', (tester) async {
    final item = _buildItem();
    final container = ProviderContainer(overrides: [
      artifactStoreProvider.overrideWithValue(InMemoryArtifactStore()),
      importPickerProvider.overrideWithValue(_FakePicker(['/tmp/matting.png'])),
      importServiceProvider.overrideWithValue(_FakeImportService(item)),
      segmenterProvider.overrideWithValue(_FakeSegmenter()),
    ]);
    addTearDown(container.dispose);
    await tester.pumpWidget(UncontrolledProviderScope(
      container: container,
      child: const IDPhotoApp(),
    ));

    // 导入保存回主页，进入「换背景」功能页。
    await tester.tap(find.text('导入照片'));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('换背景'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('换背景'));
    await tester.pumpAndSettle();

    await scrollTo(tester, find.text('蓝底'));
    await tester.tap(find.text('蓝底'));
    await tester.pumpAndSettle();

    expect(container.read(mattingStateProvider).selectedBackground.color,
        0xFF438EDB);
  });

  testWidgets('主页空态显示导入提示', (tester) async {
    await tester.pumpWidget(ProviderScope(
      overrides: [
        artifactStoreProvider.overrideWithValue(InMemoryArtifactStore()),
        importPickerProvider.overrideWithValue(_FakePicker([])),
        importServiceProvider.overrideWithValue(_FakeImportService(_buildItem())),
        segmenterProvider.overrideWithValue(_FakeSegmenter()),
      ],
      child: const IDPhotoApp(),
    ));
    expect(find.text('请先导入照片'), findsOneWidget);
    expect(find.text('导入照片'), findsOneWidget);
  });
}
