import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/foundation.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/app/app.dart';
import 'package:idphoto_studio/domain/face/face_analyzer.dart';
import 'package:idphoto_studio/domain/face/face_models.dart';
import 'package:idphoto_studio/domain/import/import_service.dart';
import 'package:idphoto_studio/domain/import/image_item.dart';
import 'package:idphoto_studio/domain/matting/segmenter.dart';
import 'package:idphoto_studio/platform/picker/import_picker.dart';
import 'package:idphoto_studio/state/artifact_state.dart';
import 'package:idphoto_studio/state/correction_state.dart';
import 'package:idphoto_studio/state/crop_state.dart';
import 'package:idphoto_studio/state/import_state.dart';
import 'package:idphoto_studio/state/matting_state.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';

import '../helpers/fake_artifact_store.dart';

class _FakePicker implements ImportPicker {
  _FakePicker(this.paths);

  final List<String> paths;

  @override
  Future<List<String>> pickImages() async => paths;

  @override
  Future<String?> pickFolder() async => null;
}

class _FakeImportService implements ImportService {
  _FakeImportService(this.item);

  final ImageItem item;

  @override
  Future<ImportResult> importFile(String path) => importFiles([path]);

  @override
  Future<ImportResult> importFiles(List<String> paths) async {
    return ImportResult(items: [item], failures: const []);
  }

  @override
  Future<ImportResult> importDirectory(String directoryPath) async {
    return ImportResult(items: [item], failures: const []);
  }
}

/// 假分析器：返回合格正脸。
class _FakeAnalyzer implements FaceAnalyzer {
  @override
  Future<FaceAnalysisResult> analyze(img.Image image) async {
    return FaceAnalysisResult(
      faces: const [
        FaceInfo(
          boundingBox: NormalizedRect(left: 0.2, top: 0.1, right: 0.8, bottom: 0.9),
          leftEye: FacePoint(0.4, 0.35),
          rightEye: FacePoint(0.6, 0.35),
          nose: FacePoint(0.5, 0.5),
          chin: FacePoint(0.5, 0.75),
        ),
      ],
      imageWidth: 300,
      imageHeight: 400,
      blurScore: 500,
    );
  }
}

class _FakeSegmenter implements Segmenter {
  @override
  Future<SegmentationResult> segment(img.Image image) async {
    return SegmentationResult(
      mask: Uint8List.fromList(
        List.generate(image.width * image.height, (i) => 255),
      ),
      width: image.width,
      height: image.height,
      source: 'fake',
      succeeded: true,
    );
  }
}

ImageItem _buildItem() {
  final image = img.Image(width: 300, height: 400, numChannels: 3);
  img.fill(image, color: img.ColorRgb8(120, 160, 200));
  return ImageItem(
    id: 'id-flow-1',
    sourcePath: '/tmp/flow.png',
    fileName: 'flow.png',
    workingBytes: Uint8List.fromList(img.encodeJpg(image, quality: 92)),
    workingWidth: 300,
    workingHeight: 400,
    thumbnailBytes: Uint8List.fromList(img.encodeJpg(image, quality: 80)),
    originalWidth: 300,
    originalHeight: 400,
    exifOrientation: 1,
    exifCorrected: false,
    importedAt: DateTime.now(),
  );
}

/// 放大测试视口，使裁剪步骤全部控件一次可见（避免滚动定位歧义）。
void useTallViewport(WidgetTester tester) {
  tester.view.physicalSize = const Size(900, 1600);
  tester.view.devicePixelRatio = 1.0;
  addTearDown(tester.view.reset);
}

class _FakePathProvider extends PathProviderPlatform {
  @override
  Future<String> getApplicationDocumentsPath() async =>
      Directory.systemTemp.path;

  @override
  Future<String> getTemporaryPath() async => Directory.systemTemp.path;
}

Future<ProviderContainer> pumpApp(WidgetTester tester, ImageItem item) async {
  useTallViewport(tester);
  final container = ProviderContainer(overrides: [
    artifactStoreProvider.overrideWithValue(InMemoryArtifactStore()),
    importPickerProvider.overrideWithValue(_FakePicker(['/tmp/flow.png'])),
    importServiceProvider.overrideWithValue(_FakeImportService(item)),
    faceAnalyzerProvider.overrideWithValue(_FakeAnalyzer()),
    segmenterProvider.overrideWithValue(_FakeSegmenter()),
  ]);
  addTearDown(container.dispose);
  await tester.pumpWidget(UncontrolledProviderScope(
    container: container,
    child: const IDPhotoApp(),
  ));
  return container;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    PathProviderPlatform.instance = _FakePathProvider();
  });

  /// 导入 → 保存 → 回主页 → 进入「裁剪」功能页。
  Future<void> enterCrop(WidgetTester tester) async {
    await tester.tap(find.text('导入照片'));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('裁剪'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('裁剪'));
    await tester.pumpAndSettle();
  }

  testWidgets('裁剪步骤：选择规格、自动构图并显示规格列表', (tester) async {
    final item = _buildItem();
    final container = await pumpApp(tester, item);

    await enterCrop(tester);

    // 规格选择器可见。
    expect(find.text('证件照规格'), findsOneWidget);
    expect(find.textContaining('一寸'), findsWidgets);
    // 自动构图后出现裁框控制。
    expect(find.text('重新自动构图'), findsOneWidget);
    expect(container.read(cropStateProvider).rects[item.id], isNotNull);
  });

  testWidgets('切换规格后自动重新构图', (tester) async {
    final item = _buildItem();
    final container = await pumpApp(tester, item);

    await enterCrop(tester);

    await tester.tap(find.textContaining('二寸').first);
    await tester.pumpAndSettle();

    expect(container.read(cropStateProvider).selectedSpecId, 'inch2');
    // 切换后自动重算裁剪框。
    expect(
      container.read(cropStateProvider).rects[item.id],
      isNotNull,
    );
  });

  testWidgets('导出步骤：显示导出设置与已就绪数量', (tester) async {
    final item = _buildItem();
    final container = await pumpApp(tester, item);

    await enterCrop(tester);
    // 保存裁剪结果，回主页进「导出」。
    await tester.ensureVisible(find.text('确定并保存'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('确定并保存'));
    await tester.pumpAndSettle();
    // 等保存 SnackBar 消失，避免遮挡底部按钮栏。
    await tester.pump(const Duration(seconds: 5));
    await tester.pumpAndSettle();
    await tester.tap(find.text('导出'));
    await tester.pumpAndSettle();

    expect(find.text('导出设置'), findsOneWidget);
    expect(find.text('JPG'), findsOneWidget);
    expect(find.text('PNG'), findsOneWidget);
    expect(find.textContaining('已就绪'), findsOneWidget);
    expect(container.read(cropStateProvider).rects[item.id], isNotNull);
  });
}
