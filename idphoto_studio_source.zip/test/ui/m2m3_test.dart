import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/app/app.dart';
import 'package:idphoto_studio/domain/export/export_service.dart';
import 'package:idphoto_studio/domain/export/print_export_service.dart';
import 'package:idphoto_studio/domain/face/face_analyzer.dart';
import 'package:idphoto_studio/domain/face/face_models.dart';
import 'package:idphoto_studio/domain/import/import_service.dart';
import 'package:idphoto_studio/domain/import/image_item.dart';
import 'package:idphoto_studio/domain/layout/print_layout.dart';
import 'package:idphoto_studio/domain/matting/matting_service.dart';
import 'package:idphoto_studio/domain/matting/segmenter.dart';
import 'package:idphoto_studio/platform/picker/import_picker.dart';
import 'package:idphoto_studio/state/artifact_state.dart';
import 'package:idphoto_studio/state/correction_state.dart';
import 'package:idphoto_studio/state/enhance_state.dart';
import '../helpers/fake_artifact_store.dart';
import 'package:idphoto_studio/state/import_state.dart';
import 'package:idphoto_studio/state/matting_state.dart';
import 'package:idphoto_studio/ui/settings/settings_page.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';

class _FakePathProvider extends PathProviderPlatform {
  @override
  Future<String> getApplicationDocumentsPath() async =>
      Directory.systemTemp.path;
  @override
  Future<String> getTemporaryPath() async => Directory.systemTemp.path;
}

class _FakePicker implements ImportPicker {
  @override
  Future<List<String>> pickImages() async => ['/tmp/f.png'];
  @override
  Future<String?> pickFolder() async => null;
}

class _FakeImport implements ImportService {
  _FakeImport(this.items);
  final List<ImageItem> items;
  @override
  Future<ImportResult> importFile(String p) => importFiles([p]);
  @override
  Future<ImportResult> importFiles(List<String> p) async =>
      ImportResult(items: items, failures: const []);
  @override
  Future<ImportResult> importDirectory(String d) async =>
      ImportResult(items: items, failures: const []);
}

class _FakeAna implements FaceAnalyzer {
  @override
  Future<FaceAnalysisResult> analyze(img.Image image) async =>
      FaceAnalysisResult(
        faces: const [
          FaceInfo(
            boundingBox:
                NormalizedRect(left: .2, top: .1, right: .8, bottom: .9),
            leftEye: FacePoint(.4, .35),
            rightEye: FacePoint(.6, .35),
            nose: FacePoint(.5, .48),
            chin: FacePoint(.5, .62),
          ),
        ],
        imageWidth: image.width,
        imageHeight: image.height,
        blurScore: 100,
      );
}

class _FakeSeg implements Segmenter {
  @override
  Future<SegmentationResult> segment(img.Image image) async =>
      SegmentationResult(
        mask: Uint8List.fromList(List.filled(image.width * image.height, 255)),
        width: image.width,
        height: image.height,
        source: 'fake',
        succeeded: true,
      );
}

class _FailingSeg implements Segmenter {
  @override
  Future<SegmentationResult> segment(img.Image image) async =>
      SegmentationResult(
        mask: Uint8List(0),
        width: 0,
        height: 0,
        source: 'fake',
        succeeded: false,
      );
}

ImageItem _item(String id) {
  final im = img.Image(width: 240, height: 320, numChannels: 3);
  img.fill(im, color: img.ColorRgb8(140, 160, 190));
  return ImageItem(
    id: id,
    sourcePath: '/tmp/$id.png',
    fileName: '$id.png',
    workingBytes: Uint8List.fromList(img.encodeJpg(im, quality: 92)),
    workingWidth: 240,
    workingHeight: 320,
    thumbnailBytes: Uint8List.fromList(img.encodeJpg(im, quality: 80)),
    originalWidth: 240,
    originalHeight: 320,
    exifOrientation: 1,
    exifCorrected: false,
    importedAt: DateTime.now(),
  );
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('MattingNotifier.segmentAll', () {
    test('批量抠图成功并记录进度', () async {
      PathProviderPlatform.instance = _FakePathProvider();
      final n = MattingNotifier(_FakeSeg(), const MattingService());
      final items = [_item('a'), _item('b'), _item('c')];
      final ok = await n.segmentAll(items);
      expect(ok, 3);
      for (final it in items) {
        expect(n.state.masks.containsKey(it.id), true);
      }
      // 进度归零。
      expect(n.state.isProcessing, false);
      expect(n.state.batchDone, 0);
    });

    test('失败项回退几何兜底后仍可能成功', () async {
      PathProviderPlatform.instance = _FakePathProvider();
      final n = MattingNotifier(_FailingSeg(), const MattingService());
      final items = [_item('x')];
      final ok = await n.segmentAll(items);
      // 主分割失败后回退几何兜底，返回 0 或更多均可。
      expect(ok, greaterThanOrEqualTo(0));
      expect(n.state.isProcessing, false);
    });
  });

  group('PrintExportService 多照片排版', () {
    test('多照片循环铺排', () async {
      PathProviderPlatform.instance = _FakePathProvider();
      final service = PrintExportService();
      final layout = const LayoutService().layout(
        PaperSpec.byId('photo5')!,
        25,
        35,
        count: 6,
      );
      img.Image photo(int v) {
        final im = img.Image(width: 60, height: 84, numChannels: 3);
        img.fill(im, color: img.ColorRgb8(v, v, v));
        return im;
      }

      final item = await service.exportPrintSheet(
        photo(100),
        layout,
        photos: [photo(10), photo(200)],
        format: ExportFormat.png,
        customName: 'multi',
      );
      expect(File(item.path).existsSync(), true);
      // 回读并验证：格子 1 用照片 1（暗 10），格子 2 用照片 2（亮 200）。
      // 5 寸纸：边距 8mm≈94px，格子 25×35mm≈295×413px。
      final back = img.decodeImage(File(item.path).readAsBytesSync())!;
      final c1 = back.getPixel(94 + 147, 100 + 206); // 格子 1 中心
      final c2 = back.getPixel(94 + 295 + 24 + 147, 100 + 206); // 格子 2 中心
      expect(c2.r.toInt(), greaterThan(c1.r.toInt() + 100));
    });
  });

void markOnboarded() {
  File('${Directory.systemTemp.path}/.onboarded').writeAsStringSync('1');
}

  testWidgets('优化步骤：预设切换与换装开关', (tester) async {
    tester.view.physicalSize = const Size(900, 1800);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);

    markOnboarded();
    final item = _item('e1');
    final container = ProviderContainer(overrides: [
      artifactStoreProvider.overrideWithValue(InMemoryArtifactStore()),
      importPickerProvider.overrideWithValue(_FakePicker()),
      importServiceProvider.overrideWithValue(_FakeImport([item])),
      faceAnalyzerProvider.overrideWithValue(_FakeAna()),
      segmenterProvider.overrideWithValue(_FakeSeg()),
    ]);
    addTearDown(container.dispose);
    await tester.pumpWidget(UncontrolledProviderScope(
      container: container,
      child: const IDPhotoApp(),
    ));

    // 导入 → 保存 → 主页 → 进入「优化」功能页。
    await tester.tap(find.text('导入照片'));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('优化'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('优化'));
    await tester.pumpAndSettle();

    expect(find.text('色彩预设'), findsOneWidget);
    expect(find.text('高清'), findsOneWidget);
    // 切换预设。
    await tester.tap(find.text('明亮'));
    await tester.pumpAndSettle();
    expect(container.read(enhanceStateProvider).preset.name, 'bright');
    // 换装区默认关闭。
    expect(find.textContaining('已关闭'), findsOneWidget);
    await tester.tap(find.text('男式西装（深蓝）'));
    await tester.pumpAndSettle();
    expect(container.read(enhanceStateProvider).dress.name, 'menSuit');
    expect(find.textContaining('已开启'), findsOneWidget);
  });

  testWidgets('设置页：主题切换与常见问题', (tester) async {
    tester.view.physicalSize = const Size(900, 2400);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);
    final container = ProviderContainer();
    addTearDown(container.dispose);
    await tester.pumpWidget(UncontrolledProviderScope(
      container: container,
      child: const MaterialApp(home: SettingsPage()),
    ));
    expect(find.text('设置与帮助'), findsOneWidget);
    expect(find.text('完全本地处理'), findsOneWidget);
    expect(find.text('跟随系统'), findsOneWidget);
    expect(find.text('自动检查更新'), findsOneWidget);
    // FAQ 展开。
    await tester.scrollUntilVisible(
      find.textContaining('为什么提示'),
      200,
      scrollable: find.byType(Scrollable).first,
    );
    await tester.tap(find.textContaining('为什么提示'));
    await tester.pumpAndSettle();
    expect(find.textContaining('请确保照片正面清晰'), findsOneWidget);
  });
}
