import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/material.dart';
import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/app/app.dart';
import 'package:idphoto_studio/state/artifact_state.dart';
import '../helpers/fake_artifact_store.dart';
import 'package:idphoto_studio/domain/face/face_analyzer.dart';
import 'package:idphoto_studio/domain/face/face_models.dart';
import 'package:idphoto_studio/domain/import/import_service.dart';
import 'package:idphoto_studio/domain/import/image_item.dart';
import 'package:idphoto_studio/platform/picker/import_picker.dart';
import 'package:idphoto_studio/domain/matting/segmenter.dart';
import 'package:idphoto_studio/state/correction_state.dart';
import 'package:idphoto_studio/state/matting_state.dart';
import 'package:idphoto_studio/state/import_state.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';

class _FakePicker implements ImportPicker {
  _FakePicker(this.paths);

  final List<String> paths;

  @override
  Future<List<String>> pickImages() async => paths;

  @override
  Future<String?> pickFolder() async => null;
}

class _FakeImportService implements ImportService {
  _FakeImportService(this.item);

  final ImageItem item;

  @override
  Future<ImportResult> importFile(String path) => importFiles([path]);

  @override
  Future<ImportResult> importFiles(List<String> paths) async {
    return ImportResult(items: [item], failures: const []);
  }

  @override
  Future<ImportResult> importDirectory(String directoryPath) async {
    return ImportResult(items: [item], failures: const []);
  }
}

/// 假分析器：返回一张倾斜 20.56°、roll=12°、清晰的正脸。
class _FakeAnalyzer implements FaceAnalyzer {
  int callCount = 0;

  @override
  Future<FaceAnalysisResult> analyze(img.Image image) async {
    callCount++;
    return FaceAnalysisResult(
      faces: const [
        FaceInfo(
          boundingBox: NormalizedRect(left: 0.2, top: 0.1, right: 0.8, bottom: 0.9),
          leftEye: FacePoint(0.3, 0.2),
          rightEye: FacePoint(0.7, 0.35),
          nose: FacePoint(0.5, 0.45),
          chin: FacePoint(0.5, 0.7),
          yawDegrees: 0,
          pitchDegrees: 0,
          rollDegrees: 12,
        ),
      ],
      imageWidth: image.width,
      imageHeight: image.height,
      blurScore: 500,
    );
  }
}

class _FakeSegmenter implements Segmenter {
  @override
  Future<SegmentationResult> segment(img.Image image) async {
    return SegmentationResult(
      mask: Uint8List.fromList(List.filled(image.width * image.height, 255)),
      width: image.width,
      height: image.height,
      source: 'fake',
      succeeded: true,
    );
  }
}

ImageItem _buildItem() {
  final image = img.Image(width: 300, height: 400, numChannels: 3);
  img.fill(image, color: img.ColorRgb8(40, 140, 200));
  return ImageItem(
    id: 'id-correction-1',
    sourcePath: '/tmp/face.png',
    fileName: 'face.png',
    workingBytes: Uint8List.fromList(img.encodeJpg(image, quality: 92)),
    workingWidth: 300,
    workingHeight: 400,
    thumbnailBytes: Uint8List.fromList(img.encodeJpg(image, quality: 80)),
    originalWidth: 300,
    originalHeight: 400,
    exifOrientation: 1,
    exifCorrected: false,
    importedAt: DateTime.now(),
  );
}


/// 在主 ListView 中滚动到目标控件（第一个 Scrollable 为主内容列表）。
Future<void> scrollTo(WidgetTester tester, Finder finder) async {
  await tester.scrollUntilVisible(
    finder,
    200,
    scrollable: find.byType(Scrollable).first,
  );
  await tester.pumpAndSettle();
}

class _FakePathProvider extends PathProviderPlatform {
  @override
  Future<String> getApplicationDocumentsPath() async =>
      Directory.systemTemp.path;

  @override
  Future<String> getTemporaryPath() async => Directory.systemTemp.path;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    PathProviderPlatform.instance = _FakePathProvider();
  });

  /// 导入 → 保存 → 回主页 → 进入「矫正」功能页。
  Future<void> enterCorrection(
      WidgetTester tester, FaceAnalyzer analyzer, {Segmenter? segmenter}) async {
    await tester.tap(find.text('导入照片'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('矫正'));
    await tester.pumpAndSettle();
  }

  testWidgets('矫正步骤：分析后展示质量提示与倾斜信息', (tester) async {
    final item = _buildItem();
    await tester.pumpWidget(ProviderScope(
      overrides: [
        artifactStoreProvider.overrideWithValue(InMemoryArtifactStore()),
        importPickerProvider.overrideWithValue(_FakePicker(['/tmp/face.png'])),
        importServiceProvider.overrideWithValue(_FakeImportService(item)),
        faceAnalyzerProvider.overrideWithValue(_FakeAnalyzer()),
      ],
      child: const IDPhotoApp(),
    ));

    // 导入保存后进入矫正功能页。
    await enterCorrection(tester, _FakeAnalyzer());

    // 自动分析触发：质量提示在顶部，矫正控件需滚动到可见。
    expect(find.textContaining('头部倾斜 12°'), findsOneWidget);
    expect(find.textContaining('矫正前'), findsOneWidget);
    expect(find.textContaining('矫正后'), findsOneWidget);
    await scrollTo(tester, find.text('自动矫正'));
    expect(find.text('自动矫正'), findsOneWidget);
  });

  testWidgets('自动矫正后显示已矫正角度并进入下一步', (tester) async {
    final item = _buildItem();
    final analyzer = _FakeAnalyzer();
    await tester.pumpWidget(ProviderScope(
      overrides: [
        artifactStoreProvider.overrideWithValue(InMemoryArtifactStore()),
        importPickerProvider.overrideWithValue(_FakePicker(['/tmp/face.png'])),
        importServiceProvider.overrideWithValue(_FakeImportService(item)),
        faceAnalyzerProvider.overrideWithValue(analyzer),
        segmenterProvider.overrideWithValue(_FakeSegmenter()),
      ],
      child: const IDPhotoApp(),
    ));

    await enterCorrection(tester, analyzer, segmenter: _FakeSegmenter());

    await scrollTo(tester, find.text('自动矫正'));
    await tester.tap(find.text('自动矫正'));
    await tester.pumpAndSettle();

    expect(find.textContaining('已自动矫正'), findsOneWidget);
    expect(analyzer.callCount, greaterThan(0));

    // 保存矫正结果并进入「抠图」功能页。
    await tester.ensureVisible(find.text('确定并保存'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('确定并保存'));
    await tester.pumpAndSettle();
    // 等保存 SnackBar 消失，避免遮挡底部按钮栏。
    await tester.pump(const Duration(seconds: 5));
    await tester.pumpAndSettle();
    await tester.tap(find.text('抠图'));
    await tester.pumpAndSettle();
    expect(find.text('原图'), findsOneWidget);
    expect(find.text('抠图结果'), findsOneWidget);
  });

  testWidgets('分析器不可用时给出降级提示', (tester) async {
    final item = _buildItem();
    await tester.pumpWidget(ProviderScope(
      overrides: [
        artifactStoreProvider.overrideWithValue(InMemoryArtifactStore()),
        importPickerProvider.overrideWithValue(_FakePicker(['/tmp/face.png'])),
        importServiceProvider.overrideWithValue(_FakeImportService(item)),
        faceAnalyzerProvider.overrideWithValue(_UnavailableAnalyzer()),
      ],
      child: const IDPhotoApp(),
    ));

    await enterCorrection(tester, _UnavailableAnalyzer());

    expect(find.textContaining('分析器不可用'), findsOneWidget);
    await scrollTo(tester, find.text('手动旋转'));
    expect(find.text('手动旋转'), findsOneWidget);
  });
}

class _UnavailableAnalyzer implements FaceAnalyzer {
  @override
  Future<FaceAnalysisResult> analyze(img.Image image) async {
    return FaceAnalysisResult(
      faces: const [],
      imageWidth: 100,
      imageHeight: 100,
      blurScore: 0,
      analyzerUnavailableReason: '原生库缺失（测试）',
    );
  }
}
