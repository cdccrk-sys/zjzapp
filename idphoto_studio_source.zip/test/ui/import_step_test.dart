import 'dart:io';
import 'dart:typed_data';

import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/app/app.dart';
import 'package:idphoto_studio/state/artifact_state.dart';
import '../helpers/fake_artifact_store.dart';
import 'package:idphoto_studio/domain/face/face_analyzer.dart';
import 'package:idphoto_studio/domain/face/face_models.dart';
import 'package:idphoto_studio/domain/import/import_service.dart';
import 'package:idphoto_studio/domain/import/image_item.dart';
import 'package:idphoto_studio/platform/picker/import_picker.dart';
import 'package:idphoto_studio/state/correction_state.dart';
import 'package:idphoto_studio/state/import_state.dart';
import 'package:image/image.dart' as img;
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';

/// 假分析器：返回合格正脸，避免触发真实原生库。
class _FakeAnalyzer implements FaceAnalyzer {
  @override
  Future<FaceAnalysisResult> analyze(img.Image image) async {
    return FaceAnalysisResult(
      faces: const [
        FaceInfo(
          boundingBox: NormalizedRect(left: 0.2, top: 0.1, right: 0.8, bottom: 0.9),
          leftEye: FacePoint(0.4, 0.35),
          rightEye: FacePoint(0.6, 0.35),
          nose: FacePoint(0.5, 0.5),
          chin: FacePoint(0.5, 0.75),
        ),
      ],
      imageWidth: 300,
      imageHeight: 400,
      blurScore: 500,
    );
  }
}

class _FakePicker implements ImportPicker {
  _FakePicker(this.paths);

  final List<String> paths;
  int pickCount = 0;

  @override
  Future<List<String>> pickImages() async {
    pickCount++;
    return paths;
  }

  @override
  Future<String?> pickFolder() async => null;
}

/// 假导入服务：立即返回预设结果，避免真实文件 I/O 在 fake async 测试环境下挂起。
class _FakeImportService implements ImportService {
  _FakeImportService({this.item, this.failure});

  final ImageItem? item;
  final ImportFailure? failure;

  @override
  Future<ImportResult> importFile(String path) => importFiles([path]);

  @override
  Future<ImportResult> importFiles(List<String> paths) async {
    if (failure != null) {
      return ImportResult(items: const [], failures: [failure!]);
    }
    return ImportResult(
      items: item == null ? const [] : [item!],
      failures: const [],
    );
  }

  @override
  Future<ImportResult> importDirectory(String directoryPath) async {
    return ImportResult(
      items: item == null ? const [] : [item!],
      failures: const [],
    );
  }
}

ImageItem _buildItem(String name, {int w = 300, int h = 400}) {
  final image = img.Image(width: w, height: h, numChannels: 3);
  img.fill(image, color: img.ColorRgb8(40, 140, 200));
  return ImageItem(
    id: 'id-1',
    sourcePath: '/tmp/$name',
    fileName: name,
    workingBytes: Uint8List.fromList(img.encodeJpg(image, quality: 92)),
    workingWidth: w,
    workingHeight: h,
    thumbnailBytes: Uint8List.fromList(img.encodeJpg(image, quality: 80)),
    originalWidth: w,
    originalHeight: h,
    exifOrientation: 1,
    exifCorrected: false,
    importedAt: DateTime.now(),
  );
}

class _FakePathProvider extends PathProviderPlatform {
  @override
  Future<String> getApplicationDocumentsPath() async {
    return Directory.systemTemp.path;
  }

  @override
  Future<String> getTemporaryPath() async {
    return Directory.systemTemp.path;
  }
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  setUp(() {
    PathProviderPlatform.instance = _FakePathProvider();
  });

  Widget buildApp({ImportPicker? picker, ImportService? service}) {
    return ProviderScope(
      overrides: [
        artifactStoreProvider.overrideWithValue(InMemoryArtifactStore()),
        if (picker != null) importPickerProvider.overrideWithValue(picker),
        if (service != null) importServiceProvider.overrideWithValue(service),
        faceAnalyzerProvider.overrideWithValue(_FakeAnalyzer()),
      ],
      child: const IDPhotoApp(),
    );
  }

  /// 首页直接导入：空态点「导入照片」，直接打开选择器并导入。
  Future<void> openImport(WidgetTester tester) async {
    await tester.tap(find.text('导入照片'));
    await tester.pumpAndSettle();
  }

  testWidgets('主页显示 8 个独立功能卡片与导入提示', (tester) async {
    await tester.pumpWidget(buildApp(
      picker: _FakePicker(const []),
      service: _FakeImportService(),
    ));

    expect(find.text('请先导入照片'), findsOneWidget);
    expect(find.text('导入照片'), findsOneWidget);
  });

  testWidgets('首页直接导入后进入功能界面（不再经过导入页）', (tester) async {
    await tester.pumpWidget(buildApp(
      picker: _FakePicker(['/tmp/selfie.png']),
      service: _FakeImportService(item: _buildItem('selfie.png')),
    ));

    await openImport(tester);

    // 直接进入功能界面：底部功能按钮栏可见，导入页元素不存在。
    expect(find.text('矫正'), findsOneWidget);
    expect(find.text('选择照片'), findsNothing);
    expect(find.text('确定并保存'), findsNothing);
    expect(find.text('已导入 1 张'), findsNothing);
  });

  testWidgets('导入失败时展示失败清单', (tester) async {
    await tester.pumpWidget(buildApp(
      picker: _FakePicker(['/tmp/bad.png']),
      service: _FakeImportService(
        failure: ImportFailure(
          filePath: '/tmp/bad.png',
          fileName: 'bad.png',
          code: ImportFailureCode.decodeFailed,
          message: '图片解码失败，文件可能已损坏或不是有效图片',
        ),
      ),
    ));

    await openImport(tester);

    // 导入失败：仍停留在空态导入界面，不崩溃。
    expect(find.text('请先导入照片'), findsOneWidget);
    expect(find.text('导入照片'), findsOneWidget);
  });

  testWidgets('导入保存后回主页，点「矫正」卡进入矫正页', (tester) async {
    await tester.pumpWidget(buildApp(
      picker: _FakePicker(['/tmp/ok.png']),
      service: _FakeImportService(item: _buildItem('ok.png')),
    ));

    await openImport(tester);

    // 导入后直接进入功能主页：底部功能按钮栏。
    expect(find.text('矫正'), findsOneWidget);

    await tester.tap(find.text('矫正'));
    await tester.pumpAndSettle();

    // 进入矫正步骤：显示分析结果与矫正控件（矫正控件需滚动到可见）。
    expect(find.textContaining('矫正前'), findsOneWidget);
    expect(find.textContaining('矫正后'), findsOneWidget);
    await tester.scrollUntilVisible(
      find.text('自动矫正'),
      200,
      scrollable: find.byType(Scrollable).last,
    );
    expect(find.text('自动矫正'), findsOneWidget);
  });

  testWidgets('导入后再次导入新照片（单张替换）', (tester) async {
    await tester.pumpWidget(buildApp(
      picker: _FakePicker(['/tmp/one.png']),
      service: _FakeImportService(item: _buildItem('one.png')),
    ));

    await openImport(tester);
    expect(find.text('矫正'), findsOneWidget);

    // 再次导入另一张：单张替换，仍正常显示功能主页。
    await tester.tap(find.text('矫正'));
    await tester.pumpAndSettle();
    await tester.pageBack();
    await tester.pumpAndSettle();

    // 已有照片时：通过 AppBar 导入图标再次导入。
    await tester.tap(find.byIcon(Icons.add_photo_alternate_outlined));
    await tester.pumpAndSettle();
    expect(find.text('矫正'), findsOneWidget);
  });
}
