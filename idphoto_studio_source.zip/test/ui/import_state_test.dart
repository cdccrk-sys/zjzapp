import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/domain/import/image_item.dart';
import 'package:idphoto_studio/state/import_state.dart';

void main() {
  group('导入状态管理', () {
    test('ImportState.copyWith 默认保持原值', () {
      const state = ImportState();
      final next = state.copyWith(isLoading: true);
      expect(next.isLoading, isTrue);
      expect(next.items, isEmpty);
      expect(next.failures, isEmpty);
    });

    test('向导步骤固定为 8 步', () {
      expect(kWizardSteps, hasLength(8));
      expect(kWizardSteps.first, '导入');
      expect(kWizardSteps.last, '导出');
    });

    test('ImportFailure 分类枚举完整', () {
      expect(ImportFailureCode.values, containsAll([
        ImportFailureCode.unsupportedFormat,
        ImportFailureCode.fileNotFound,
        ImportFailureCode.tooLarge,
        ImportFailureCode.decodeFailed,
        ImportFailureCode.heicNotSupported,
        ImportFailureCode.permissionDenied,
        ImportFailureCode.unknown,
      ]));
    });

    test('ImportResult.hasFailures', () {
      final failure = ImportFailure(
        filePath: 'x.jpg',
        fileName: 'x.jpg',
        code: ImportFailureCode.decodeFailed,
        message: 'bad',
      );
      expect(ImportResult(items: const [], failures: [failure]).hasFailures, isTrue);
      expect(ImportResult(items: const [], failures: const []).hasFailures, isFalse);
    });
  });
}
