import 'dart:io';

import 'package:flutter/material.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/app/app.dart';
import 'package:idphoto_studio/domain/privacy/cleanup_service.dart';
import 'package:idphoto_studio/ui/onboarding/onboarding_page.dart';
import 'package:path/path.dart' as p;
import 'package:path_provider_platform_interface/path_provider_platform_interface.dart';

class _FakePathProvider extends PathProviderPlatform {
  @override
  Future<String> getApplicationDocumentsPath() async =>
      Directory.systemTemp.path;
  @override
  Future<String> getTemporaryPath() async => Directory.systemTemp.path;
}

void main() {
  TestWidgetsFlutterBinding.ensureInitialized();

  group('CleanupService', () {
    test('清除导出缓存并返回删除数', () async {
      final docs = await Directory.systemTemp.createTemp('cleanup_test');
      final exports = Directory(p.join(docs.path, 'exports'));
      final prints = Directory(p.join(docs.path, 'prints'));
      await exports.create(recursive: true);
      await prints.create(recursive: true);
      await File(p.join(exports.path, 'a.jpg')).writeAsString('x');
      await File(p.join(prints.path, 'b.png')).writeAsString('y');
      await File(p.join(docs.path, 'keep.txt')).writeAsString('keep');

      final removed = await const CleanupService().clearExportCache(
        docsPath: docs.path,
      );
      expect(removed, 2);
      expect(File(p.join(docs.path, 'keep.txt')).existsSync(), true);
      expect(File(p.join(exports.path, 'a.jpg')).existsSync(), false);
      await docs.delete(recursive: true);
    });
  });

  group('Onboarding', () {
    testWidgets('引导组件可翻页并在完成时回调', (tester) async {
      var finished = false;
      await tester.pumpWidget(MaterialApp(
        home: OnboardingPage(onFinish: () => finished = true),
      ));
      expect(find.text('隐私安全，全程离线'), findsOneWidget);

      await tester.tap(find.text('下一步'));
      await tester.pumpAndSettle();
      expect(find.text('8 步轻松出片'), findsOneWidget);

      await tester.tap(find.text('下一步'));
      await tester.pumpAndSettle();
      expect(find.text('换装功能默认关闭'), findsOneWidget);
      expect(finished, false);

      await tester.tap(find.text('开始使用'));
      await tester.pumpAndSettle();
      expect(finished, true);
    });

    test('引导标记可读写', () async {
      PathProviderPlatform.instance = _FakePathProvider();
      final flag = File(p.join(Directory.systemTemp.path, kOnboardedFileName));
      if (flag.existsSync()) await flag.delete();

      expect(await IDPhotoApp.hasOnboarded(), false);
      await IDPhotoApp.markOnboarded();
      expect(await IDPhotoApp.hasOnboarded(), true);
      await flag.delete();
    });
  });
}
