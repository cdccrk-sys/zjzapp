import 'dart:io';
import 'dart:typed_data';

import 'package:flutter/widgets.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:flutter_test/flutter_test.dart';
import 'package:idphoto_studio/app/app.dart';
import 'package:idphoto_studio/domain/face/face_analyzer.dart';
import 'package:idphoto_studio/domain/face/face_models.dart';
import 'package:idphoto_studio/domain/import/import_service.dart';
import 'package:idphoto_studio/domain/import/image_item.dart';
import 'package:idphoto_studio/domain/matting/segmenter.dart';
import 'package:idphoto_studio/platform/picker/import_picker.dart';
import 'package:idphoto_studio/state/artifact_state.dart';
import 'package:idphoto_studio/state/correction_state.dart';
import '../helpers/fake_artifact_store.dart';
import 'package:idphoto_studio/state/crop_state.dart';
import 'package:idphoto_studio/state/import_state.dart';
import 'package:idphoto_studio/state/matting_state.dart';
import 'package:idphoto_studio/state/print_state.dart';
import 'package:image/image.dart' as img;

class _FakePicker implements ImportPicker {
  @override
  Future<List<String>> pickImages() async => ['/tmp/f.png'];
  @override
  Future<String?> pickFolder() async => null;
}

class _FakeImport implements ImportService {
  _FakeImport(this.item);
  final ImageItem item;
  @override
  Future<ImportResult> importFile(String p) => importFiles([p]);
  @override
  Future<ImportResult> importFiles(List<String> p) async =>
      ImportResult(items: [item], failures: const []);
  @override
  Future<ImportResult> importDirectory(String d) async =>
      ImportResult(items: [item], failures: const []);
}

class _FakeAna implements FaceAnalyzer {
  @override
  Future<FaceAnalysisResult> analyze(img.Image image) async =>
      FaceAnalysisResult(
        faces: const [
          FaceInfo(
            boundingBox:
                NormalizedRect(left: .2, top: .1, right: .8, bottom: .9),
            leftEye: FacePoint(.4, .35),
            rightEye: FacePoint(.6, .35),
            nose: FacePoint(.5, .48),
            chin: FacePoint(.5, .62),
          ),
        ],
        imageWidth: image.width,
        imageHeight: image.height,
        blurScore: 100,
      );
}

class _FakeSeg implements Segmenter {
  @override
  Future<SegmentationResult> segment(img.Image image) async =>
      SegmentationResult(
        mask: Uint8List.fromList(
            List.filled(image.width * image.height, 255)),
        width: image.width,
        height: image.height,
        source: 'f',
        succeeded: true,
      );
}

ImageItem _item() {
  final im = img.Image(width: 300, height: 400, numChannels: 3);
  img.fill(im, color: img.ColorRgb8(140, 160, 190));
  return ImageItem(
    id: 'p1',
    sourcePath: '/tmp/f.png',
    fileName: 'f.png',
    workingBytes: Uint8List.fromList(img.encodeJpg(im, quality: 92)),
    workingWidth: 300,
    workingHeight: 400,
    thumbnailBytes: Uint8List.fromList(img.encodeJpg(im, quality: 80)),
    originalWidth: 300,
    originalHeight: 400,
    exifOrientation: 1,
    exifCorrected: false,
    importedAt: DateTime.now(),
  );
}

void main() {
void markOnboarded() {
  File('${Directory.systemTemp.path}/.onboarded').writeAsStringSync('1');
}

  testWidgets('排版步骤：选择相纸后显示排版结果并可切到导出', (tester) async {
    tester.view.physicalSize = const Size(900, 1600);
    tester.view.devicePixelRatio = 1.0;
    addTearDown(tester.view.reset);

    markOnboarded();
    final item = _item();
    final container = ProviderContainer(overrides: [
      artifactStoreProvider.overrideWithValue(InMemoryArtifactStore()),
      importPickerProvider.overrideWithValue(_FakePicker()),
      importServiceProvider.overrideWithValue(_FakeImport(item)),
      faceAnalyzerProvider.overrideWithValue(_FakeAna()),
      segmenterProvider.overrideWithValue(_FakeSeg()),
    ]);
    addTearDown(container.dispose);

    await tester.pumpWidget(UncontrolledProviderScope(
      container: container,
      child: const IDPhotoApp(),
    ));

    // 导入 → 保存 → 主页 → 裁剪（自动构图）→ 保存 → 主页 → 排版。
    await tester.tap(find.text('导入照片'));
    await tester.pumpAndSettle();
    await tester.ensureVisible(find.text('裁剪'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('裁剪'));
    await tester.pumpAndSettle();
    expect(
      container.read(cropStateProvider).rects[item.id],
      isNotNull,
      reason: '裁剪步骤应自动生成裁框',
    );
    await tester.ensureVisible(find.text('确定并保存'));
    await tester.pumpAndSettle();
    await tester.tap(find.text('确定并保存'));
    await tester.pumpAndSettle();
    // 等保存 SnackBar 消失，避免遮挡底部按钮栏。
    await tester.pump(const Duration(seconds: 5));
    await tester.pumpAndSettle();
    await tester.tap(find.text('排版'));
    await tester.pumpAndSettle();

    expect(find.text('选择相纸'), findsOneWidget);
    expect(find.text('6 寸'), findsWidgets);
    // 默认 6 寸纸：一寸照自动排版并显示每页数量。
    expect(find.textContaining('每页'), findsOneWidget);
    expect(find.text('完成'), findsOneWidget);

    // 切换到 5 寸。
    await tester.tap(find.text('5 寸').first);
    await tester.pumpAndSettle();
    await tester.pumpAndSettle();
    expect(container.read(printStateProvider).paperId, 'photo5');
    // 5 寸纸一寸照：每页 8 张。
    expect(find.textContaining('每页 8 张'), findsOneWidget);
  });
}
