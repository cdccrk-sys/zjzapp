import 'dart:typed_data';

import 'package:idphoto_studio/domain/artifacts/artifact_store.dart';

/// 内存版产物存储：避免 widget test（FakeAsync）中真实文件 IO 永不完成。
class InMemoryArtifactStore implements ArtifactStore {
  final Map<String, Map<ArtifactKind, Uint8List>> _data = {};

  @override
  Future<Map<String, Set<ArtifactKind>>> savedKindsAll() async =>
      _data.map((k, v) => MapEntry(k, v.keys.toSet()));

  @override
  Future<List<ArtifactKind>> savedKinds(String itemId) async =>
      _data[itemId]?.keys.toList() ?? const [];

  @override
  Future<Uint8List?> load(String itemId, ArtifactKind kind) async =>
      _data[itemId]?[kind];

  @override
  Future<bool> exists(String itemId, ArtifactKind kind) async =>
      _data[itemId]?.containsKey(kind) ?? false;

  @override
  Future<String> pathFor(String itemId, ArtifactKind kind) async => 'mem://$itemId/${kind.key}';

  @override
  Future<void> save(String itemId, ArtifactKind kind, Uint8List bytes) async {
    _data.putIfAbsent(itemId, () => {})[kind] = bytes;
  }

  @override
  Future<void> deleteAll(String itemId) async {
    _data.remove(itemId);
  }
}
